import os
from microsoft.fabric.hls.hds.claims_data_ingestions.json.core.process_json_files import Process_JSON
from pyspark.sql import SparkSession
from typing import Callable
from microsoft.fabric.hls.hds.global_constants.global_constants import GlobalConstants as GC
from microsoft.fabric.hls.hds.global_constants.logging_constants import LoggingConstants as LC
from microsoft.fabric.hls.hds.claims_data_ingestions.json.utils.constants import JSONClaimsIngestionConstants as C
from microsoft.fabric.hls.hds.utils.business_events_ingestion_handler import BusinessEventsIngestion
from microsoft.fabric.hls.hds.utils.utils import Utils, FolderPath
from microsoft.fabric.hls.hds.utils.mssparkutils_client_base import MSSparkUtilsClientBase
from microsoft.fabric.hls.hds.services.base_runnable_service import BaseRunnableService
from microsoft.fabric.hls.hds.data_models.execution_metadata import ExecutionMetadata, ExecutionDataType
from microsoft.fabric.hls.hds.errors.claims_json_ingestion_service_failed_error import ClaimsJSONIngestionFailedError

class ClaimsJSONIngestionService(BaseRunnableService):
    """
    This class represents the service for ingesting JSON files into a lakehouse.
    """

    def __init__(self, 
                 spark: SparkSession,
                 workspace_name: str,
                 solution_name: str,
                 admin_lakehouse_name: str,
                 inline_params: dict = None,
                 one_lake_endpoint: str = GC.DEFAULT_ONE_LAKE_ENDPOINT,
                 mssparkutils_client: MSSparkUtilsClientBase = None) -> None:
        """
        Initializes a new instance of the ClaimsJSONIngestionService class.

        Args:
            - spark (SparkSession): The Spark session.
            - workspace_name (str): The name of the workspace.
            - solution_name (str): The name of the solution.
            - admin_lakehouse_name (str): The lakehouse name of where the administration configurations are located
            - inline_params (dict): Inline parameters that will overwrite and take precedence over the parameters in the administration lakehouse configuration
            - one_lake_endpoint (str): The one lake endpoint. Default is `onelake.dfs.fabric.microsoft.com`
            - mssparksutils_client (MSSparkUtilsClientBase): The mssparkutils client
        Returns:
            None
        """
        self.spark: SparkSession = spark
        self.workspace_name = workspace_name
        self.solution_name = solution_name
        self.one_lake_endpoint = one_lake_endpoint
        self.mssparkutils_client = mssparkutils_client
        

        super().__init__(spark=spark,
                         workspace_name=workspace_name,
                         solution_name=solution_name,
                         admin_lakehouse_name=admin_lakehouse_name,
                         inline_params=inline_params,
                         one_lake_endpoint=one_lake_endpoint,
                         mssparkutils_client=mssparkutils_client)
        
    def _setup(self) -> None:
        """
        Setup method for the ClaimsJSONIngestionService
        """
        self.target_lakehouse_name = self.source_lakehouse_name = self.parameter_service.get_foundation_config_value(GC.BRONZE_LAKEHOUSE_ID_KEY)
                
        self.config_files_root_path = FolderPath.get_fabric_workload_files_root_path(
            workspace_name=self.workspace_name,
            one_lake_endpoint=self.one_lake_endpoint,
            solution_name=self.solution_name
        )
        
        self.lakehouse_files_root_path = FolderPath.get_fabric_files_path(
            workspace_name=self.workspace_name,
            one_lake_endpoint=self.one_lake_endpoint,
            lakehouse_name=self.target_lakehouse_name
        )
        
        try:
            self.checkpoint_path = os.path.join(
                self.parameter_service.get_foundation_config_value(
                GC.CLAIMS_CHECKPOINT_PATH_KEY,
                FolderPath.get_fabric_workload_files_checkpoint_folder_path(
                    root_path=self.config_files_root_path,
                    checkpoint_folder_name=f"{GC.CLAIMS_JSON_FOLDER}"
                )
                ),C.JSON_DROP_FOLDER_TO_DELTA_TABLES_CHECKPOINT_FOLDER)            
            
            self.json_files_drop_path = self.parameter_service.get_activity_config_value(
                GC.JSON_FILES_DROP_PATH_KEY,
                os.path.join(self.lakehouse_files_root_path, GC.PROCESS_FOLDER, GC.CLAIMS_FOLDER, GC.JSON_FOLDER)
            )
            self.business_events_ingestion_service = BusinessEventsIngestion(
                spark = self.spark,
                workspace_name = self.workspace_name,
                one_lake_endpoint = self.one_lake_endpoint,
                lakehouse_name = self.admin_lakehouse_name,
                solution_name = self.solution_name,
                parameter_service = self.parameter_service
                )
        
            
            self.json_files_config_path = self.parameter_service.get_activity_config_value(
                GC.JSON_FILES_CONFIG_PATH_KEY,
                f"{self.config_files_root_path}/{GC.CLAIMS_JSON_FILES_CONFIG_PATH}/"
            )
            
            self.target_tables_path = self.parameter_service.get_activity_config_value(
                GC.TARGET_TABLES_PATH_KEY,
                FolderPath.get_fabric_tables_path(
                    workspace_name=self.workspace_name,
                    one_lake_endpoint=self.one_lake_endpoint,
                    lakehouse_name=self.target_lakehouse_name
                )
            )
            self.max_files_per_trigger = int(self.parameter_service.get_activity_config_value(
                GC.MAX_FILES_PER_TRIGGER_KEY,
                C.JSON_MAX_FILES_PER_TRIGGER
            ))
    
        except Exception as ex:
            self._logger.error(LC.SETUP_ERROR_MSG.format(error_msg=str(ex)))
            raise ClaimsJSONIngestionFailedError(str(ex))
       
    def _setup_execution_metadata(self) -> ExecutionMetadata:
        return ExecutionMetadata(
            sourceType=ExecutionDataType.file,
            sourcePath=self.json_files_drop_path,
            targetType=ExecutionDataType.deltaTable,
            targetPath=self.target_tables_path,
            sourceLakehouseName=self.mssparkutils_client.get_lakehouse(self.source_lakehouse_name).get("displayName"),
            sourceLakehouseIdentifier=self.mssparkutils_client.get_lakehouse(self.source_lakehouse_name).get("id"),
            targetLakehouseName=self.mssparkutils_client.get_lakehouse(self.target_lakehouse_name).get("displayName"),
            targetLakehouseIdentifier=self.mssparkutils_client.get_lakehouse(self.target_lakehouse_name).get("id"),
        )

    def _get_internal_activity_name(self) -> str:
        return GC.JSON_FILES_DELTA_TABLES_INGESTION_ACTIVITY_NAME

    def _register_custom_accumulators(self) -> None:
        self.execution_metrics_collector.register_accumulator(
            accumulator_activity_id=self._get_validation_metrics_accumulator_activity_id(),
            initial_state=self._get_validation_metrics_initial_state()
        )

    def _execute(self, **kwargs) -> None:
        """
        Wrap for the service's core execution logic.
        """
        self._ingest_logic()

    def _ingest_logic(self) -> None:
        """
        Actual ingestion logic moved here.
        """
        self._logger.info(LC.JSON_PROCESS_START_INFO_MSG.format(process_name=C.JSON_INGESTION_PROCESS_NAME, state= C.JSON_PROCESSING_STARTED))  
                          
        JSONFileProcesser = Process_JSON(
            self.spark,
            self.json_files_drop_path,
            self.lakehouse_files_root_path,
            self.target_tables_path,
            self.business_events_ingestion_service,
            self.mssparkutils_client,
            collect_metrics_fn=self.collect_target_delta_table_operation_summary_metrics,
            execution_metrics_collector=self.execution_metrics_collector,
            execution_metrics_accumulator_id=self.get_execution_metrics_accumulator_activity_id()
        )
        JSONFileProcesser.process_json_files(self.json_files_config_path, self.checkpoint_path, self.max_files_per_trigger)
        
        self._logger.info(LC.JSON_PROCESS_START_INFO_MSG.format(process_name=C.JSON_INGESTION_PROCESS_NAME, state= C.JSON_PROCESSING_COMPLETED))