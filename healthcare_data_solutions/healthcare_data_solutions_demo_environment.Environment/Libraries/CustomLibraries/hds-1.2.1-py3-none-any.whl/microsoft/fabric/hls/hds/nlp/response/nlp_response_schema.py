# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# --------------------------------------------------------------------------
from pyspark.sql.types import StringType, StructType, StructField, IntegerType, FloatType, BooleanType, ArrayType, TimestampType


class NLPResponseSchema:
    """
    This module defines the NLPResponseSchema class, which represents the structure
    of responses from the Azure Text Analytics for Health API.

    The NLPResponseSchema class contains methods to create and retrieve the
    response schema as a PySpark StructType.
    """

    def __init__(self):
        """Initializes the NLPResponseSchema instance by creating the struct."""
        self.struct = self._create_struct()

    @staticmethod
    def _create_struct():
        """
        Creates the struct representing an array of responses from the Azure Text 
        Analytics for Health API.

        This method defines the nested structs for error, warning, data source, assertion, entity,
        role, entity relation, and statistics information. It then constructs the final struct,
        which represents an array of responses containing these nested structs.

        Returns:
            ArrayType(StructType): The response schema as a PySpark ArrayType containing StructType.
        """
        # Nested struct for error information
        error_info_struct = StructType([
            StructField("code", StringType(), True),
            StructField("message", StringType(), True)
        ])

        # Nested struct for warning information
        warning_info_struct = StructType([
            StructField("code", StringType(), True),
            StructField("message", StringType(), True),
        ])

        # Nested struct for data source information
        data_source_info_struct = StructType([
            StructField("entity_id", StringType(), True),
            StructField("name", StringType(), True)
        ])

        # Nested struct for assertion information
        assertion_info_struct = StructType([
            StructField("conditionality", StringType(), True),
            StructField("certainty", StringType(), True),
            StructField("association", StringType(), True)
        ])

        # Nested struct for entity information
        entity_info_struct = StructType([
            StructField("offset", IntegerType(), True),
            StructField("length", IntegerType(), True),
            StructField("text", StringType(), True),
            StructField("category", StringType(), True),
            StructField("confidence_score", FloatType(), True),
            StructField("data_sources", ArrayType(
                data_source_info_struct), True),
            StructField("assertion", assertion_info_struct, True)
        ])

        # Nested struct for role information
        role_info_struct = StructType([
            StructField("name", StringType(), False),
            StructField("entity", StructType([
                StructField("offset", IntegerType(), True),
                StructField("length", IntegerType(), True),
                StructField("text", StringType(), True)
            ]), False)
        ])

        # Nested struct for entity relation information
        entity_relation_info_struct = StructType([
            StructField("relation_type", StringType(), True),
            StructField("roles", ArrayType(role_info_struct), True)
        ])

        # Nested struct for statistics information
        statistics_info_struct = StructType([
            StructField("character_count", IntegerType(), True),
            StructField("transaction_count", IntegerType(), True)
        ])

        # Create the final struct representing an array of responses
        nlp_response_struct = StructType([
            StructField("id", StringType(), True),
            StructField("error", error_info_struct, True),
            StructField("is_error", BooleanType(), False),
            StructField("warnings", ArrayType(warning_info_struct), True),
            StructField("entities", ArrayType(entity_info_struct), True),
            StructField("entity_relations", ArrayType(
                entity_relation_info_struct), True),
            StructField("statistics", statistics_info_struct, True),
            StructField("nlp_last_executed", TimestampType(), True),
            StructField("fhir_bundle", StringType(), True)
        ])

        return ArrayType(nlp_response_struct)

    def get_struct(self):
        """
        Retrieves the response schema as a PySpark StructType.

        Returns:
            ArrayType(StructType): The response schema as a PySpark ArrayType containing StructType.
        """
        return self.struct

    def __str__(self):
        """
        Returns a string representation of the response schema.

        Returns:
            str: A string representation of the NLPResponseSchema instance.
        """
        return str(self.struct)
