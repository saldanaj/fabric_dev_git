import json
from pandas import DataFrame
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, explode_outer, struct, to_json, lit
from microsoft.fabric.hls.hds.claims_data_ingestions.json.utils.constants import JSONClaimsIngestionConstants as C
from microsoft.fabric.hls.hds.global_constants.logging_constants import LoggingConstants as LC
from pyspark.sql.types import MapType, StringType, StructType

class ClaimsJSONProcessor:
    
    @staticmethod
    def explode_columns(df, config, _logger):
        """Dynamically explode columns based on configuration."""
        df_exploded = df
        explode_columns = config["explode_columns"]
        for column in explode_columns:
            try:
                # Get the last part of the column path for the new column name
                exploded_col = column.split('.')[-1]
                
                # For nested fields, check if the field exists using schema
                if '.' in column:
                    parent_col = column.split('.')[0]
                    child_field = column.split('.')[1]
                    
                    # First check if parent column exists
                    if parent_col not in df_exploded.columns:
                        continue
                    
                    # Check if child field exists in parent column schema
                    try:
                        # Get the schema of the parent column
                        parent_schema = df_exploded.schema[parent_col].dataType
                        
                        # Check if child field exists in parent schema
                        if hasattr(parent_schema, 'fieldNames') and child_field not in parent_schema.fieldNames():
                            _logger.info(LC.JSON_CHILD_FIELD_NOT_FOUND_INFO_MSG.format(child_field=child_field, column=column))
                            continue
                    except Exception as schema_err:
                        _logger.error(LC.JSON_SCHEMA_CHECK_ERROR_INFO_MSG.format(column=column, schema_err=schema_err))
                        continue
                # For non-nested columns, just check if column exists
                elif column not in df_exploded.columns:
                    _logger.info(LC.JSON_COLUMN_NOT_FOUND_INFO_MSG.format(column=column))
                    continue
                
                df_exploded = df_exploded.withColumn(exploded_col, explode_outer(col(column)))
                # Ensure the file path column remains intact
                df_exploded = df_exploded.withColumn(C.FILE_PATH_COLUMN_NAME, col(C.FILE_PATH_COLUMN_NAME))
            except Exception as e:
                _logger.error(f"Error exploding column '{column}': {str(e)}", exc_info=True)
                continue
        return df_exploded
    @staticmethod
    def rename_columns(df, parent_name):
        """Extract field names from a StructType column and alias them."""
        if parent_name in df.schema.fieldNames():
            data_type = df.schema[parent_name].dataType
            if isinstance(data_type, StructType):
                struct_fields = data_type.fieldNames()
                return [
                    col(f"{parent_name}.{field}").alias(f"{parent_name}_{field}")
                    for field in struct_fields
                ]
            else:
                return []  # Return empty list for non-struct types
        return []  # Return empty list if parent_name doesn't exist
    @staticmethod
    def flatten_structure(df_exploded, config):
        """Flatten the structure by selecting all columns with prefixed aliases."""
        common_segments = config["include_segments"]
        # Select columns that are common segments
        selected_columns = [
            col(segment).alias(segment) for segment in common_segments if segment in df_exploded.columns
        ]

        # Dynamically rename nested fields
        additional_columns = []
        for parent in config["renamed_to"]:
            additional_columns.extend(ClaimsJSONProcessor.rename_columns(df_exploded, parent))

        df_flattened = df_exploded.select(*selected_columns, *additional_columns, C.FILE_PATH_COLUMN_NAME)
        return df_flattened

    @staticmethod
    def drop_unused_columns(df, columns_to_drop):
        """Drop the specified columns from the DataFrame."""
        return df.drop(*columns_to_drop)
    
    @staticmethod
    def Transform_JSON(df: DataFrame, namespace: str, file_type: str, config, _logger, spark):
        try:
            try:
                df_exploded = ClaimsJSONProcessor.explode_columns(df, config, _logger)
            except Exception as e:
                _logger.error(f"Error in explode_columns: {str(e)}")
                df_failed = df.withColumn(C.JSON_STRING_COLUMN_NAME, lit(None))

                return spark.createDataFrame([], StructType([])), df_failed

            # Flatten the DataFrame
            df_flattened = ClaimsJSONProcessor.flatten_structure(df_exploded, config)

            # Drop the original nested columns AFTER flattening.
            columns_to_drop = config.get("drop_columns",[])
            df_flattened = ClaimsJSONProcessor.drop_unused_columns(df_flattened, columns_to_drop)

            # Convert the flattened DataFrame into JSON strings
            df_json = df_flattened.select(
                to_json(struct(*[col for col in df_flattened.columns if col != C.FILE_PATH_COLUMN_NAME])).alias(C.JSON_STRING_COLUMN_NAME),
                col(C.FILE_PATH_COLUMN_NAME)
            )

            df_json = df_json.withColumn(C.SOURCE_SYSTEM_COLUMN_NAME, lit(namespace))
            df_json = df_json.withColumn(C.DATA_FORMAT_COLUMN_NAME, lit(file_type))

            df_failed = df_json.filter(col(C.JSON_STRING_COLUMN_NAME).isNull())
            df_success = df_json.filter(col(C.JSON_STRING_COLUMN_NAME).isNotNull())

            return df_success, df_failed

        except Exception as e:
            _logger.error(f"Error during JSON transformation: {str(e)}")
            raise  # Rethrow exception for debugging
