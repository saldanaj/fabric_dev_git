from typing import List, Set, Tuple

from rmt.core import logger
from rmt.core.core_exceptions import UpdateError, UpdateValueError
from rmt.core.data_management.abstract_authoring_data_reader import AbstractAuthoringDataReader
from rmt.core.data_management.abstract_authoring_mapping_reader import AbstractAuthoringMappingReader
from rmt.core.data_management.abstract_contributors_reader import AbstractContributorsReader
from rmt.core.data_management.abstract_repository_folder_table_data_reader import AbstractRepositoryFolderTableDataReader
from rmt.core.data_management.abstract_repository_folder_table_data_writer import AbstractRepositoryFolderTableDataWriter
from rmt.core.data_management.abstract_repository_folder_table_mapping_reader import AbstractRepositoryFolderTableMappingReader
from rmt.core.data_management.abstract_repository_folder_table_mapping_writer import AbstractRepositoryFolderTableMappingWriter
from rmt.core.data_management.authoring_data_adapter import AuthoringDataAdapter
from rmt.core.data_management.authoring_mapping_adapter import AuthoringMappingAdapter
from rmt.core.data_management.contributor import Contributor, ContributorType
from rmt.core.data_management.contributor_repository_updater import ContributorRepositoryUpdater
from rmt.core.data_management.primitive_types import TableName
from rmt.core.data_management.repository import Repository
from rmt.core.data_management.table_data import TableData
from rmt.core.data_management.table_mapping import TableMapping
from rmt.core.data_management.tables_validator import TablesValidator


class RepositoryUpdater:
    """
    This class support the user story of updating
    the repository folder (=staging as currently apear in API, just different terminology)
    The class is responsible for updating the repository folder with the data and mapping of the customer contributor
    as read from the authoring data and mapping files (the csv files)
    for each given table data of customer it will override the data of the customer for that table in repository folder
    same for mapping. note we are only writing customer data and mapping to the repository folder
    if a customer authoring data for some table is same as the customer data for that table in repository
    it will not update the repository folder.same for mapping.
    if a customer authoring data or mapping for some table is not valid it will not update the repository folder at all
    and write an error to the log
    for the user to be able to follow errors and fix them we want to collect as much errors as we can
    and not stop at the first error.so first checking authoring data and mapping and then write all errors
    if all authoring data and mapping is valid then continue read from repository folder the data and mapping
    for the tables which appear in the authoring data and mapping, from all contributors to the repository class
    which represents the repository folder.
    then update the repository class with the customer data and mapping and get what was actually changed
    then validate the tables that was changed (with all data and mapping from all contributors)
    and if valid write the those tables data and mapping to the repository folder
    validations (as explained above are done first on the authoring data and mapping and then with all data and mapping from all contributors in the repository folder)
    1. each table data has unique keys and unique names
    2. each table mapping has unique source values across all target keys (no same source value for different target keys)
    3. each mapping target key must exist in the table data keys
    4. each data key from some contributor must be in the range of the contributor keys
    5. each contributor name in the authoring data and mapping must be a valid contributor name
    (the authoring data and mapping contains data and mapping from all contributors only for the user to follow, when we read we ignore
    authoring data and mapping from other contributors than the customer contributor, still we validate the contributors names
    in the authoring data and mapping to make sure the data or mapping is not corrupted)
    """
    @staticmethod
    def update_repository_folder_reference_data(
        authoring_data_reader: AbstractAuthoringDataReader,
        authoring_mapping_reader: AbstractAuthoringMappingReader,
        repository_contributors_reader: AbstractContributorsReader,
        repository_folder_table_mapping_reader: AbstractRepositoryFolderTableMappingReader,
        repository_folder_table_data_reader: AbstractRepositoryFolderTableDataReader,
        repository_folder_table_mapping_writer: AbstractRepositoryFolderTableMappingWriter,
        repository_folder_table_data_writer: AbstractRepositoryFolderTableDataWriter,
    ):
        # read contributors
        contributors = repository_contributors_reader.read()

        for contributor in contributors:
            if contributor.name == ContributorType.Customer.name:
                customer_contributor = contributor
                break
        if customer_contributor is None:
            logger.error("Customer contributor not found")
            return

        authoring_valid = True
        # read authoring table mapping
        try:
            customer_table_mapping_list, mapping_authoring_errors = RepositoryUpdater._get_customer_table_mapping_list(authoring_mapping_reader,
                                                                                                                       customer_contributor,
                                                                                                                       contributors)
            for error in mapping_authoring_errors:
                logger.error(f"{error}")
        except ValueError as e:
            logger.error(f"Error reading customer mapping authoring: {e}")
            authoring_valid = False

        # read authoring table data
        try:
            customer_table_data_list, data_authroing_errors = RepositoryUpdater._get_customer_table_date_list(authoring_data_reader,
                                                                                                              customer_contributor,
                                                                                                              contributors)
            for error in data_authroing_errors:
                logger.error(f"{error}")
        except ValueError as e:
            logger.error(f"Error reading customer data authoring: {e}")
            authoring_valid = False

        # return if not any authoring is not valid
        if not authoring_valid:
            raise UpdateError("No data was updated. Validation errors found.")

        # create repository and read data and mapping of the relevant tables from repository folder to repository class
        repository = RepositoryUpdater._get_repository_with_tables_data_and_mapping(
            contributors, repository_folder_table_mapping_reader, repository_folder_table_data_reader
        )

        # complete table data and mapping list of customer from repository (for deleted tables)
        customer_table_data_list = RepositoryUpdater._complete_table_data_list_of_contributor_from_repository(
            customer_contributor, repository, customer_table_data_list
        )

        customer_table_mapping_list = RepositoryUpdater._complete_table_mapping_list_of_contributor_from_repository(
            customer_contributor, repository, customer_table_mapping_list
        )

        # update repository with the customer data and mapping (and get what was updated)
        customer_repository_updater = ContributorRepositoryUpdater(repository, customer_contributor)
        updated_table_mapping_list = customer_repository_updater.set_table_mapping_list(customer_table_mapping_list)
        updated_table_data_list = customer_repository_updater.set_table_data_list(customer_table_data_list)

        # get union of updated table names
        updated_tables_names = RepositoryUpdater._get_table_names(updated_table_data_list, updated_table_mapping_list)

        # validate updated tables and if valid, write to updated data and mapping to repository folder
        tables_validator = TablesValidator(repository)
        if tables_validator.validate_tables(updated_tables_names) and len(mapping_authoring_errors + data_authroing_errors) == 0:
            logger.info("Validation passed. Updating repository folder with the updated data and mapping.")
            repository_folder_table_mapping_writer.write(customer_contributor.name, updated_table_mapping_list)
            repository_folder_table_data_writer.write(customer_contributor.name, updated_table_data_list)
        else:
            if tables_validator.validation_errors:
                for error in tables_validator.validation_errors:
                    logger.error(f"{error}")
            raise UpdateError("No data was updated. Validation errors found.")

    @staticmethod
    def _get_table_names(table_data_list: List[TableData], table_mapping_list: List[TableMapping]) -> Set[TableName]:
        return set([table_data.table_name for table_data in table_data_list] +
                   [table_mapping.table_name for table_mapping in table_mapping_list])

    @staticmethod
    def _get_customer_table_date_list(authoring_data_reader: AbstractAuthoringDataReader, customer_contributor: Contributor,
                                      contributors: Set[Contributor]) -> Tuple[List[TableData], List[UpdateValueError]]:
        authoring_data_entries, read_errors = authoring_data_reader.read()
        authoring_data_adapter = AuthoringDataAdapter(contributors)
        table_data_list, convert_errors = authoring_data_adapter.get_table_data_for_contributor(authoring_data_entries, customer_contributor)
        return table_data_list, read_errors + convert_errors

    @staticmethod
    def _get_customer_table_mapping_list(authoring_mapping_reader: AbstractAuthoringMappingReader, customer_contributor: Contributor,
                                         contributors: Set[Contributor]) -> Tuple[List[TableMapping], List[UpdateValueError]]:
        authoring_mapping_entries, read_errors = authoring_mapping_reader.read()
        authoring_mapping_adapter = AuthoringMappingAdapter(contributors)
        table_mapping_list, convert_errors = authoring_mapping_adapter.get_table_mapping_for_contributor(authoring_mapping_entries, customer_contributor)
        return table_mapping_list, read_errors + convert_errors

    @staticmethod
    def _complete_table_data_list_of_contributor_from_repository(customer_contributor: Contributor, repository: Repository,
                                                                 table_data_list: List[TableData]) -> List[TableData]:

        repository_table_names = repository.get_data_table_names_for_contributor(customer_contributor)
        authoring_table_names = set([table_data.table_name for table_data in table_data_list])
        for table_name in repository_table_names:
            if table_name not in authoring_table_names:
                table_data = TableData(table_name)
                table_data_list.append(table_data)
        return table_data_list

    @staticmethod
    def _complete_table_mapping_list_of_contributor_from_repository(customer_contributor: Contributor, repository: Repository,
                                                                    table_mapping_list: List[TableMapping]) -> List[TableMapping]:

        repository_table_names = repository.get_mapping_table_names_for_contributor(customer_contributor)
        authoring_table_names = set([table_mapping.table_name for table_mapping in table_mapping_list])
        for table_name in repository_table_names:
            if table_name not in authoring_table_names:
                table_mapping = TableMapping(table_name)
                table_mapping_list.append(table_mapping)
        return table_mapping_list

    @staticmethod
    def _get_repository_with_tables_data_and_mapping(
        contributors: Set[Contributor],
        repository_folder_table_mapping_reader: AbstractRepositoryFolderTableMappingReader,
        repository_folder_table_data_reader: AbstractRepositoryFolderTableDataReader,
    ) -> Repository:
        repository = Repository(contributors)

        for contributor in contributors:
            table_data_list = repository_folder_table_data_reader.read(contributor.name)
            repository.add_table_data_list(contributor, table_data_list)

            table_mapping_list = repository_folder_table_mapping_reader.read(contributor.name)
            repository.add_table_mapping_list(contributor, table_mapping_list)

        return repository

# SIG # Begin Windows Authenticode signature block
# MIIoQwYJKoZIhvcNAQcCoIIoNDCCKDACAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQse8BENmB6EqSR2hd
# JGAGggIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAPPnc97VdFCRNP
# 1CDymv+wG2webwvwjfz78SE6ClLzZ6CCDXYwggX0MIID3KADAgECAhMzAAADrzBA
# DkyjTQVBAAAAAAOvMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjMxMTE2MTkwOTAwWhcNMjQxMTE0MTkwOTAwWjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDOS8s1ra6f0YGtg0OhEaQa/t3Q+q1MEHhWJhqQVuO5amYXQpy8MDPNoJYk+FWA
# hePP5LxwcSge5aen+f5Q6WNPd6EDxGzotvVpNi5ve0H97S3F7C/axDfKxyNh21MG
# 0W8Sb0vxi/vorcLHOL9i+t2D6yvvDzLlEefUCbQV/zGCBjXGlYJcUj6RAzXyeNAN
# xSpKXAGd7Fh+ocGHPPphcD9LQTOJgG7Y7aYztHqBLJiQQ4eAgZNU4ac6+8LnEGAL
# go1ydC5BJEuJQjYKbNTy959HrKSu7LO3Ws0w8jw6pYdC1IMpdTkk2puTgY2PDNzB
# tLM4evG7FYer3WX+8t1UMYNTAgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQURxxxNPIEPGSO8kqz+bgCAQWGXsEw
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzUwMTgyNjAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAISxFt/zR2frTFPB45Yd
# mhZpB2nNJoOoi+qlgcTlnO4QwlYN1w/vYwbDy/oFJolD5r6FMJd0RGcgEM8q9TgQ
# 2OC7gQEmhweVJ7yuKJlQBH7P7Pg5RiqgV3cSonJ+OM4kFHbP3gPLiyzssSQdRuPY
# 1mIWoGg9i7Y4ZC8ST7WhpSyc0pns2XsUe1XsIjaUcGu7zd7gg97eCUiLRdVklPmp
# XobH9CEAWakRUGNICYN2AgjhRTC4j3KJfqMkU04R6Toyh4/Toswm1uoDcGr5laYn
# TfcX3u5WnJqJLhuPe8Uj9kGAOcyo0O1mNwDa+LhFEzB6CB32+wfJMumfr6degvLT
# e8x55urQLeTjimBQgS49BSUkhFN7ois3cZyNpnrMca5AZaC7pLI72vuqSsSlLalG
# OcZmPHZGYJqZ0BacN274OZ80Q8B11iNokns9Od348bMb5Z4fihxaBWebl8kWEi2O
# PvQImOAeq3nt7UWJBzJYLAGEpfasaA3ZQgIcEXdD+uwo6ymMzDY6UamFOfYqYWXk
# ntxDGu7ngD2ugKUuccYKJJRiiz+LAUcj90BVcSHRLQop9N8zoALr/1sJuwPrVAtx
# HNEgSW+AKBqIxYWM4Ev32l6agSUAezLMbq5f3d8x9qzT031jMDT+sUAoCw0M5wVt
# CUQcqINPuYjbS1WgJyZIiEkBMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGiMwghofAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAAOvMEAOTKNNBUEAAAAAA68wDQYJYIZIAWUDBAIB
# BQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIKGTMbJjYacIJRhZiKy+/k5U
# 1oNCi8gpmPFFg8Ot4W0LMEIGCisGAQQBgjcCAQwxNDAyoBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEB
# BQAEggEAmwxuKT4s3vULQUrORk0f4C3BNn5FBVzk8qNlYhpvNugGpl+T402EGWRg
# fmZDk9QBW89VLdrjeB0yEnDTRodIaSpQFSNcdyDZeri6mE8Bjcvz9YO0TbVhqyPk
# 0RFoUKSRWUDKLe3TCQBM6ShBenHNfdQ1/qfHaAhuJ2QAxadGzixRGmSCSG6YHkho
# R5R67LPfFbOxh/6XqWg626JD731t4DfBbvi5x6Uboovx7Afbol08IR9cNF1XoWiW
# rDZlY/2K+rPm/hwGU3up6ESfyHMwJqho7pzGP2z9tTD4t+K5ZocYiT+QLOpTNA0D
# Yen13ygOgl2Q2eK3RXroNYvulIFDVKGCF60wghepBgorBgEEAYI3AwMBMYIXmTCC
# F5UGCSqGSIb3DQEHAqCCF4YwgheCAgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFaBgsq
# hkiG9w0BCRABBKCCAUkEggFFMIIBQQIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFl
# AwQCAQUABCAIUpcpSL7QPU7axy0zlSFx/Hwbo1xqiDyRtnXmXsdVVgIGZr38n3Xu
# GBMyMDI0MDgxNTEzMzYzNy43MDVaMASAAgH0oIHZpIHWMIHTMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQgSXJl
# bGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJzAlBgNVBAsTHm5TaGllbGQgVFNTIEVT
# TjozNjA1LTA1RTAtRDk0NzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# U2VydmljZaCCEfswggcoMIIFEKADAgECAhMzAAAB91ggdQTK+8L0AAEAAAH3MA0G
# CSqGSIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9u
# MRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRp
# b24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4XDTI0
# MDcyNTE4MzEwNloXDTI1MTAyMjE4MzEwNlowgdMxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9w
# ZXJhdGlvbnMgTGltaXRlZDEnMCUGA1UECxMeblNoaWVsZCBUU1MgRVNOOjM2MDUt
# MDVFMC1EOTQ3MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNl
# MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA0OdHTBNom6/uXKaEKP9r
# PITkT6QxF11tjzB0Nk1byDpPrFTHha3hxwSdTcr8Y0a3k6EQlwqy6ROz42e0R5eD
# W+dCoQapipDIFUOYp3oNuqwX/xepATEkY17MyXFx6rQW2NcWUJW3Qo2AuJ0HOtbl
# SpItQZPGmHnGqkt/DB45Fwxk6VoSvxNcQKhKETkuzrt8U6DRccQm1FdhmPKgDzgc
# fDPM5o+GnzbiMu6y069A4EHmLMmkecSkVvBmcZ8VnzFHTDkGLdpnDV5FXjVObAgb
# SM0cnqYSGfRp7VGHBRqyoscvR4bcQ+CV9pDjbJ6S5rZn1uA8hRhj09Hs33HRevt4
# oWAVYGItgEsG+BrCYbpgWMDEIVnAgPZEiPAaI8wBGemE4feEkuz7TAwgkRBcUzLg
# Q4uvPqRD1A+Jkt26+pDqWYSn0MA8j0zacQk9q/AvciPXD9It2ez+mqEzgFRRsJGL
# tcf9HksvK8Jsd6I5zFShlqi5bpzf1Y4NOiNOh5QwW1pIvA5irlal7qFhkAeeeZqm
# op8+uNxZXxFCQG3R3s5pXW89FiCh9rmXrVqOCwgcXFIJQAQkllKsI+UJqGq9rmRA
# BJz5lHKTFYmFwcM52KWWjNx3z6odwz2h+sxaxewToe9GqtDx3/aU+yqNRcB8w0tS
# XUf+ylN4uk5xHEpLpx+ZNNsCAwEAAaOCAUkwggFFMB0GA1UdDgQWBBTfRqQzP3m9
# PZWuLf1p8/meFfkmmDAfBgNVHSMEGDAWgBSfpxVdAF5iXYP05dJlpxtTNRnpcjBf
# BgNVHR8EWDBWMFSgUqBQhk5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3Bz
# L2NybC9NaWNyb3NvZnQlMjBUaW1lLVN0YW1wJTIwUENBJTIwMjAxMCgxKS5jcmww
# bAYIKwYBBQUHAQEEYDBeMFwGCCsGAQUFBzAChlBodHRwOi8vd3d3Lm1pY3Jvc29m
# dC5jb20vcGtpb3BzL2NlcnRzL01pY3Jvc29mdCUyMFRpbWUtU3RhbXAlMjBQQ0El
# MjAyMDEwKDEpLmNydDAMBgNVHRMBAf8EAjAAMBYGA1UdJQEB/wQMMAoGCCsGAQUF
# BwMIMA4GA1UdDwEB/wQEAwIHgDANBgkqhkiG9w0BAQsFAAOCAgEAN0ajafILeL6S
# QIMIMAXM1Qd6xaoci2mOrpR8vKWyyTsL3b83A7XGLiAbQxTrqnXvVWWeNst5YQD8
# saO+UTgOLJdTdfUADhLXoK+RlwjfndimIJT9MH9tUYXLzJXKhZM09ouPwNsrn8YO
# LIpdAi5TPyN8Cl11OGZSlP9r8JnvomW00AoJ4Pl9rlg0G5lcQknAXqHa9nQdWp1Z
# xXqNd+0JsKmlR8tcANX33ClM9NnaClJExLQHiKeHUUWtqyLMl65TW6wRM7XlF7Y+
# PTnC8duNWn4uLng+ON/Z39GO6qBj7IEZxoq4o3avEh9ba43UU6TgzVZaBm8VaA0w
# SwUe/pqpTOYFWN62XL3gl/JC2pzfIPxP66XfRLIxafjBVXm8KVDn2cML9IvRK02s
# 941Y5+RR4gSAOhLiQQ6A03VNRup+spMa0k+XTPAi+2aMH5xa1Zjb/K8u9f9M05U0
# /bUMJXJDP++ysWpJbVRDiHG7szaca+r3HiUPjQJyQl2NiOcYTGV/DcLrLCBK2zG5
# 03FGb04N5Kf10XgAwFaXlod5B9eKh95PnXKx2LNBgLwG85anlhhGxxBQ5mFsJGkB
# n0PZPtAzZyfr96qxzpp2pH9DJJcjKCDrMmZziXazpa5VVN36CO1kDU4ABkSYTXOM
# 8RmJXuQm7mUF3bWmj+hjAJb4pz6hT5UwggdxMIIFWaADAgECAhMzAAAAFcXna54C
# m0mZAAAAAAAVMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZp
# Y2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0yMTA5MzAxODIyMjVaFw0zMDA5MzAxODMy
# MjVaMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNV
# BAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMIICIjANBgkqhkiG9w0B
# AQEFAAOCAg8AMIICCgKCAgEA5OGmTOe0ciELeaLL1yR5vQ7VgtP97pwHB9KpbE51
# yMo1V/YBf2xK4OK9uT4XYDP/XE/HZveVU3Fa4n5KWv64NmeFRiMMtY0Tz3cywBAY
# 6GB9alKDRLemjkZrBxTzxXb1hlDcwUTIcVxRMTegCjhuje3XD9gmU3w5YQJ6xKr9
# cmmvHaus9ja+NSZk2pg7uhp7M62AW36MEBydUv626GIl3GoPz130/o5Tz9bshVZN
# 7928jaTjkY+yOSxRnOlwaQ3KNi1wjjHINSi947SHJMPgyY9+tVSP3PoFVZhtaDua
# Rr3tpK56KTesy+uDRedGbsoy1cCGMFxPLOJiss254o2I5JasAUq7vnGpF1tnYN74
# kpEeHT39IM9zfUGaRnXNxF803RKJ1v2lIH1+/NmeRd+2ci/bfV+AutuqfjbsNkz2
# K26oElHovwUDo9Fzpk03dJQcNIIP8BDyt0cY7afomXw/TNuvXsLz1dhzPUNOwTM5
# TI4CvEJoLhDqhFFG4tG9ahhaYQFzymeiXtcodgLiMxhy16cg8ML6EgrXY28MyTZk
# i1ugpoMhXV8wdJGUlNi5UPkLiWHzNgY1GIRH29wb0f2y1BzFa/ZcUlFdEtsluq9Q
# BXpsxREdcu+N+VLEhReTwDwV2xo3xwgVGD94q0W29R6HXtqPnhZyacaue7e3Pmri
# Lq0CAwEAAaOCAd0wggHZMBIGCSsGAQQBgjcVAQQFAgMBAAEwIwYJKwYBBAGCNxUC
# BBYEFCqnUv5kxJq+gpE8RjUpzxD/LwTuMB0GA1UdDgQWBBSfpxVdAF5iXYP05dJl
# pxtTNRnpcjBcBgNVHSAEVTBTMFEGDCsGAQQBgjdMg30BATBBMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL0RvY3MvUmVwb3NpdG9y
# eS5odG0wEwYDVR0lBAwwCgYIKwYBBQUHAwgwGQYJKwYBBAGCNxQCBAweCgBTAHUA
# YgBDAEEwCwYDVR0PBAQDAgGGMA8GA1UdEwEB/wQFMAMBAf8wHwYDVR0jBBgwFoAU
# 1fZWy4/oolxiaNE9lJBb186aGMQwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDovL2Ny
# bC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljUm9vQ2VyQXV0XzIw
# MTAtMDYtMjMuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0cDov
# L3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNSb29DZXJBdXRfMjAxMC0w
# Ni0yMy5jcnQwDQYJKoZIhvcNAQELBQADggIBAJ1VffwqreEsH2cBMSRb4Z5yS/yp
# b+pcFLY+TkdkeLEGk5c9MTO1OdfCcTY/2mRsfNB1OW27DzHkwo/7bNGhlBgi7ulm
# ZzpTTd2YurYeeNg2LpypglYAA7AFvonoaeC6Ce5732pvvinLbtg/SHUB2RjebYIM
# 9W0jVOR4U3UkV7ndn/OOPcbzaN9l9qRWqveVtihVJ9AkvUCgvxm2EhIRXT0n4ECW
# OKz3+SmJw7wXsFSFQrP8DJ6LGYnn8AtqgcKBGUIZUnWKNsIdw2FzLixre24/LAl4
# FOmRsqlb30mjdAy87JGA0j3mSj5mO0+7hvoyGtmW9I/2kQH2zsZ0/fZMcm8Qq3Uw
# xTSwethQ/gpY3UA8x1RtnWN0SCyxTkctwRQEcb9k+SS+c23Kjgm9swFXSVRk2XPX
# fx5bRAGOWhmRaw2fpCjcZxkoJLo4S5pu+yFUa2pFEUep8beuyOiJXk+d0tBMdrVX
# VAmxaQFEfnyhYWxz/gq77EFmPWn9y8FBSX5+k77L+DvktxW/tM4+pTFRhLy/AsGC
# onsXHRWJjXD+57XQKBqJC4822rpM+Zv/Cuk0+CQ1ZyvgDbjmjJnW4SLq8CdCPSWU
# 5nR0W2rRnj7tfqAxM328y+l7vzhwRNGQ8cirOoo6CGJ/2XBjU02N7oJtpQUQwXEG
# ahC0HVUzWLOhcGbyoYIDVjCCAj4CAQEwggEBoYHZpIHWMIHTMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQgSXJl
# bGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJzAlBgNVBAsTHm5TaGllbGQgVFNTIEVT
# TjozNjA1LTA1RTAtRDk0NzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# U2VydmljZaIjCgEBMAcGBSsOAwIaAxUAb28KDG/xXbNBjmM7/nqw3bgrEOaggYMw
# gYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYD
# VQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQsF
# AAIFAOpoeyIwIhgPMjAyNDA4MTUxMzAzMzBaGA8yMDI0MDgxNjEzMDMzMFowdDA6
# BgorBgEEAYRZCgQBMSwwKjAKAgUA6mh7IgIBADAHAgEAAgIApzAHAgEAAgIQSjAK
# AgUA6mnMogIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAowCAIB
# AAIDB6EgoQowCAIBAAIDAYagMA0GCSqGSIb3DQEBCwUAA4IBAQBHgRYHwsV1yw74
# uj/A/ZkQUrnjRcZQE3MZ0FRL+BwfNpUkfs+wZ/pPA4pvOUHVS/e88xmKiZ1IDCKm
# +NX59CCpzlWcNdCLmV8zuAWoVkk9b3w+C2g2IDQ+Or1zSJ3OoubYQVq3Hajq7tI4
# Fd426IzLKgoM2nd4mJwzfzzCCdZxbZaZ45PixbdmrAoG/3cOMFVp6ZNvz4GAuD3o
# tjgOfHjvO7bYfSwhmg+4Kuh8CIQBY6NQr1ZfR8E3xtsSj5GvjojDjCNkHToFkKFe
# 0gcTQ2HpPmNfUxhmr9fFBb42pgpiel6tHpnOI4DIJf9NOjezGcOBT5w7baRQ6kii
# Vue7oIbTMYIEDTCCBAkCAQEwgZMwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldh
# c2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBD
# b3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIw
# MTACEzMAAAH3WCB1BMr7wvQAAQAAAfcwDQYJYIZIAWUDBAIBBQCgggFKMBoGCSqG
# SIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG9w0BCQQxIgQgAgr6vZ1hGMHh
# xqQZ7NGTMkr+AoYj0cjuLPEUCKzRwgwwgfoGCyqGSIb3DQEJEAIvMYHqMIHnMIHk
# MIG9BCAh2pjaa3ca0ecYuhu60uYHP/IKnPbedbVQJ5SoIH5Z4jCBmDCBgKR+MHwx
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1p
# Y3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAB91ggdQTK+8L0AAEAAAH3
# MCIEIPZ/pRlYFDavxumFZUcuCYd+4bHXnBrOC4RQg6+SZUVKMA0GCSqGSIb3DQEB
# CwUABIICAEHtEsqHB31EbxMrB1qsQmnZKu1CsGqcW7QymhWFwJhJPs4/MDub1zkH
# pvFE6Lbop1lxJM0vF/FNHbjjuxpQaDKCgBN1V66b8JPXuI7NVVlT4RCmI5VtHTSQ
# 2DZYJy1BTtM0Jd4M0TOirI9AQQfqJttuBRJknhuwmcxfg4mXVAGaZe0X9V85Wg8N
# 0lF3qdaIwftgCdqW2J95PyQtYxa7GJs3SJxArEzwLnnwtFKqzprJLEh3dk3VwB2t
# JrxehjPCUVz+LoxIo701l3xodxQyxqh/ahcvFKm6bZX/uPDccFz8W7G0SaHZaPNW
# PRM6kPxGUVgRqXUrjWiAhMsREMSPoxskpa2A6BVl4iNCzO9zfl0dHo3kW2d+CcRo
# 5hJjrljjMveWHPx5VPklTp2QWXX8NLZV3TireyVtHPsNGT45I6rB1mYsOvipvbOF
# EFD7FL1tKfdnoz/UBZDSrU9d1HlaQpJG0HO8T/IM1K2G6+0AO6XA7hVp1ylwX7hp
# MAe9CjUVTVNwePwyYNqbaIMd1Rm1AactFZfDP87+s74tXLg4zbIOZkqX81NqH+AJ
# ZQQUREAwx1lJ5jBof6ZEsQAXkoV8x2Jp82s3uLHvmAN52onOmdCOEHLLQj7KVdeY
# BLpdN9tYBvfdD8sqSonINBf5lNt8Ix48oqTa3NPZxXqMAGYkeb2e
# SIG # End Windows Authenticode signature block