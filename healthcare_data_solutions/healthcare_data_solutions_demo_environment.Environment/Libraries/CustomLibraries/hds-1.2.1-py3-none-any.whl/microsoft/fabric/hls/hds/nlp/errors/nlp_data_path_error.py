# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# --------------------------------------------------------------------------
class NLPDataPathError(Exception):
    """
    Exception raised for errors when reading data from an invalid or inaccessible path.

    This exception is raised when there are issues with the file system or data paths used
    during the NLP pipeline execution, such as incorrect paths, inaccessible directories, or
    insufficient permissions to read or write data.

    Attributes:
        message -- explanation of the error
    """

    def __init__(self, message="Unable to read data from the specified path."):
        self.message = message
        super().__init__(self.message)
