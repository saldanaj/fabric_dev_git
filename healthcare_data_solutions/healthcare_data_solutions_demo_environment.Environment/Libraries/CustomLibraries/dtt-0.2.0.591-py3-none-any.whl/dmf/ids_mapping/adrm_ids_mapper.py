import os
from typing import Optional, Tuple

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F
from pyspark.sql.types import LongType, StringType, StructField, StructType

from dmf.model.common.data_access_definition import DataAccessDefinition, DataSourceTypeEnum
from dmf.logging import Logger
from dmf.transformations.reader.reader import Reader
from dmf.transformations.reader.reader_factory import ReaderFactory
from dmf.utils.dataframe_utils import DataFrameUtils
from dmf.utils.global_constants import GlobalConstants
from dmf.utils.logging_utils import SyntheticId, Timed


@SyntheticId
class AdrmIdsMapper:
    DATA_FORMAT = "DELTA"
    SCHEMA = StructType([
        StructField(GlobalConstants.INTERNAL_ID_COLUMN_NAME, StringType(), False),
        StructField(GlobalConstants.EXTERNAL_ID_COLUMN_NAME, StringType(), False),
        StructField(GlobalConstants.ADRM_ID_COLUMN_NAME, LongType(), False),
        StructField(GlobalConstants.FEED_ID_COLUMN_NAME, StringType(), False)
    ])

    @Timed(Logger)
    def map(self,
            spark: SparkSession,
            given_df: DataFrame,
            feed_id: str,
            internal_id_column_name: str,
            external_id_column_name: Optional[str],
            id_mapping_table_name: str,
            id_mapping_table_db_name: Optional[str],
            id_mapping_tables_location: str,
            id_mapping_table_entity_type: DataSourceTypeEnum,
            fast=False):

        Logger.info(
            f"ID Mapper [{self.id}] Mapping IDs (id_mapping_table_name='{id_mapping_table_name}', type='{id_mapping_table_entity_type}', "
            f"internal_id_column='{internal_id_column_name}', external_id_column='{external_id_column_name}')")
        should_cache_given_df = not DataFrameUtils.is_dataframe_cached(given_df)

        if should_cache_given_df:
            Logger.info(f"Caching input DataFrame for table {id_mapping_table_name} as it is not cached yet")
            given_df.cache()

        if not external_id_column_name:
            external_id_column_name = AdrmIdsMapper._dummy_external_id_column_name(internal_id_column_name)
            given_df = given_df.dropDuplicates([internal_id_column_name]).\
                select("*", F.lit("").cast(StringType()).alias(external_id_column_name))
        else:
            given_df = given_df.dropDuplicates([internal_id_column_name, external_id_column_name])
            self._validate_all_external_ids_contain_values(given_df, external_id_column_name)
            self._validate_all_ids_are_unique(given_df, internal_id_column_name)
            self._validate_all_ids_are_unique(given_df, external_id_column_name)

        # Cast ID columns just in case they are not strings
        given_df = given_df. \
            select("*",
                   F.col(internal_id_column_name).cast(StringType()).alias(internal_id_column_name + '_temp'),
                   F.col(external_id_column_name).cast(StringType()).alias(external_id_column_name + '_temp')). \
            drop(internal_id_column_name). \
            drop(external_id_column_name). \
            withColumnRenamed(internal_id_column_name + '_temp', internal_id_column_name). \
            withColumnRenamed(external_id_column_name + '_temp', external_id_column_name)

        if id_mapping_table_entity_type == DataSourceTypeEnum.TABLE:
            if id_mapping_table_db_name is None:
                raise ValueError(
                    "id_mapping_table_db_name must be specified when id_mapping_table_entity_type is TABLE")
            AdrmIdsMapper._create_id_mapping_table(spark, id_mapping_table_db_name, id_mapping_table_name,
                                                   id_mapping_tables_location)
            mapping_table_owner = id_mapping_table_db_name
        elif id_mapping_table_entity_type == DataSourceTypeEnum.STORAGE:
            mapping_table_owner = AdrmIdsMapper.specific_table_location(id_mapping_tables_location,
                                                                        id_mapping_table_name)
        else:
            raise ValueError(f"Invalid value for mapping_entity_type: {id_mapping_table_entity_type}")

        reader: Reader = ReaderFactory.get_instance(DataAccessDefinition(data_source_type=id_mapping_table_entity_type,
                                                                         data_source_id=id_mapping_table_name,
                                                                         data_source_owner_id=mapping_table_owner,
                                                                         data_format=AdrmIdsMapper.DATA_FORMAT
                                                                         ))

        id_mapping_table_df = reader.read(spark)
        if not id_mapping_table_df:
            id_mapping_table_df = DataFrameUtils.create_empty_df(spark=spark, schema=AdrmIdsMapper.SCHEMA)

        (id_mapping_column_in_use, data_id_column_in_use) = AdrmIdsMapper._get_id_columns_in_use(
            id_mapping_table_df,
            internal_id_column_name,
            external_id_column_name)
        given_data_with_unmapped_ids_in_current_feed_df = \
            AdrmIdsMapper._get_unmapped_ids_in_current_feed(given_df, id_mapping_table_df, id_mapping_column_in_use,
                                                            data_id_column_in_use,
                                                            feed_id)

        # if and ID mapping does not exist in the current feed, it is required to check if it has already been mapped
        # in other feeds and if it was then that mapped value should be used
        remaining_unmapped_ids_df, mapped_ids_from_other_feeds_df = \
            AdrmIdsMapper._map_ids_from_other_feeds(given_data_with_unmapped_ids_in_current_feed_df,
                                                    id_mapping_table_df,
                                                    internal_id_column_name,
                                                    external_id_column_name,
                                                    id_mapping_column_in_use,
                                                    data_id_column_in_use,
                                                    feed_id)

        new_mapped_df = \
            AdrmIdsMapper._create_id_mapping(remaining_unmapped_ids_df,
                                             id_mapping_table_df,
                                             internal_id_column_name,
                                             external_id_column_name,
                                             feed_id,
                                             fast,
                                             id_mapping_table_name)

        AdrmIdsMapper._save_mappings(spark,
                                     mapped_ids_from_other_feeds_df.unionByName(new_mapped_df),
                                     id_mapping_tables_location, id_mapping_table_name)

        if not should_cache_given_df:
            given_df.unpersist(blocking=True)

    @staticmethod
    def specific_table_location(root: str, table_name: str):
        return os.path.join(root, table_name)

    @staticmethod
    def _should_map_to_ids_from_another_feed(internal_id_column_name: str, external_id_column_name: str):
        return AdrmIdsMapper._dummy_external_id_column_name(internal_id_column_name) != external_id_column_name

    @staticmethod
    def _dummy_external_id_column_name(internal_id_column_name: str) -> str:
        return internal_id_column_name + "_ext"

    @staticmethod
    def _create_id_mapping_table(spark: SparkSession, db_name: str, id_mapping_table_name: str,
                                 id_mapping_tables_location: str):

        table_location = os.path.join(id_mapping_tables_location, id_mapping_table_name)
        sql_str = f"""
                create external table if not exists {db_name}.{id_mapping_table_name} \
                ( \
                    {GlobalConstants.INTERNAL_ID_COLUMN_NAME} STRING, \
                    {GlobalConstants.EXTERNAL_ID_COLUMN_NAME} STRING, \
                    {GlobalConstants.ADRM_ID_COLUMN_NAME} BIGINT, \
                    {GlobalConstants.FEED_ID_COLUMN_NAME} STRING \
                ) \
                USING {AdrmIdsMapper.DATA_FORMAT} \
                PARTITIONED BY ({GlobalConstants.FEED_ID_COLUMN_NAME}) \
                LOCATION '{table_location}'
            """

        spark.sql(sql_str)

    @staticmethod
    def _validate_all_external_ids_contain_values(df: DataFrame, external_id_column_name):

        if (df.filter(F.col(external_id_column_name).isNull() | (F.col(external_id_column_name) == F.lit('')))
                .limit(1)
                .count() > 0):
            raise ValueError(f"Column '{external_id_column_name}' is only partially filled with real values. "
                             f"Please either fix the data so all entries have a value in the '{external_id_column_name}' "
                             f"column or remove the '{external_id_column_name}' column.")

    @staticmethod
    def _create_id_mapping(unmapped_ids_df: DataFrame, id_mapping_table_df: DataFrame,
                           internal_id_column_name: str, external_id_column_name: str, feed_id: str,
                           fast: bool, id_mapping_table_name: str) -> DataFrame:

        AdrmIdsMapper._validate_mapping_creation_allowed(
            AdrmIdsMapper._get_id_mapping_table_current_feed_df(
                id_mapping_table_df,
                feed_id),
            internal_id_column_name,
            external_id_column_name,
            unmapped_ids_df,
            id_mapping_table_name)

        calculated_long_id_column_name = "calc_long_id"

        max_adrm_id = id_mapping_table_df.select(F.max(GlobalConstants.ADRM_ID_COLUMN_NAME)).collect()[0][0]

        if not max_adrm_id:
            max_adrm_id = 0

        summed_columns = ['max_adrm_id', 'const_one', 'long_id']

        expression = '+'.join(summed_columns)

        ids_to_map = unmapped_ids_df.select(internal_id_column_name, external_id_column_name) \
            .filter(F.col(internal_id_column_name).isNotNull()) \
            .filter(F.col(external_id_column_name).isNotNull())
        if fast:
            generated_ids_df: DataFrame = ids_to_map \
                .select("*", F.lit(max_adrm_id).alias("max_adrm_id"), F.lit(1).alias("const_one"),
                        F.monotonically_increasing_id().alias("long_id")) \
                .select("*", F.expr(expression).alias(calculated_long_id_column_name))
        else:
            if DataFrameUtils.is_not_empty(ids_to_map):
                generated_ids_df: DataFrame = ids_to_map \
                    .select("*",
                            F.lit(max_adrm_id).alias("max_adrm_id"),
                            F.lit(1).alias("const_one")) \
                    .rdd.zipWithUniqueId().toDF() \
                    .select("*", F.col('_1.*'), F.col('_2').alias("long_id")) \
                    .select("*", F.expr(expression).alias(calculated_long_id_column_name))
            else:
                generated_ids_df: DataFrame = ids_to_map \
                    .select("*", F.lit(None).cast(LongType()).alias(calculated_long_id_column_name))

        return generated_ids_df \
            .select(F.col(internal_id_column_name).alias(GlobalConstants.INTERNAL_ID_COLUMN_NAME),
                    F.col(external_id_column_name).alias(GlobalConstants.EXTERNAL_ID_COLUMN_NAME),
                    F.col(calculated_long_id_column_name).alias(GlobalConstants.ADRM_ID_COLUMN_NAME),
                    F.lit(feed_id).alias(GlobalConstants.FEED_ID_COLUMN_NAME))

    @staticmethod
    def _validate_mapping_creation_allowed(id_mapping_table_df: DataFrame,
                                           internal_id_column_name: str,
                                           external_id_column_name: str,
                                           unmapped_ids_df: DataFrame,
                                           id_mapping_table_name: str):
        def _mapping_table_has_values_in_external_id_column(id_mapping_table_df: DataFrame) -> bool:
            return (id_mapping_table_df.
                    filter(F.col(GlobalConstants.EXTERNAL_ID_COLUMN_NAME).isNotNull() &
                           (F.col(GlobalConstants.EXTERNAL_ID_COLUMN_NAME) != F.lit(""))).limit(1).count() == 1)

        def _current_data_has_no_values_in_external_id_column(df: DataFrame, external_id_column_name: str) -> bool:
            return (df.filter(F.col(external_id_column_name).isNotNull() &
                              (F.col(external_id_column_name) != F.lit(""))).limit(1).count() == 0)

        if (_mapping_table_has_values_in_external_id_column(id_mapping_table_df) and
                _current_data_has_no_values_in_external_id_column(unmapped_ids_df, external_id_column_name)):
            unrecognized_ids_df = \
                unmapped_ids_df.join(id_mapping_table_df,
                                     id_mapping_table_df[GlobalConstants.INTERNAL_ID_COLUMN_NAME] ==
                                     unmapped_ids_df[internal_id_column_name],
                                     "anti")
            if unrecognized_ids_df.limit(1).count() == 1:
                raise ValueError(f"Unable to execute IDs mapping for table {id_mapping_table_name}."
                                 f"Reason: Current data set contains more IDs in column {internal_id_column_name} than"
                                 f"can be processed correctly.")

    @staticmethod
    def _get_id_mapping_table_current_feed_df(id_mapping_table_df: DataFrame, feed_id: str) -> DataFrame:
        return id_mapping_table_df.where(f"{GlobalConstants.FEED_ID_COLUMN_NAME} == '{feed_id}'")

    @staticmethod
    def _map_ids_from_other_feeds(unmapped_ids_in_current_feed_df: DataFrame,
                                  id_mapping_table_df: DataFrame,
                                  internal_id_column_name: str,
                                  external_id_column_name: str,
                                  id_mapping_column_in_use: str,
                                  data_id_column_in_use: str,
                                  feed_id: str) -> Tuple[DataFrame, DataFrame]:
        if not AdrmIdsMapper._should_map_to_ids_from_another_feed(internal_id_column_name, external_id_column_name):
            return (
                unmapped_ids_in_current_feed_df,
                unmapped_ids_in_current_feed_df.sparkSession.createDataFrame(data=[], schema=AdrmIdsMapper.SCHEMA)
            )

        id_mapping_table_other_feeds_df = id_mapping_table_df. \
            where(f"{GlobalConstants.FEED_ID_COLUMN_NAME} != '{feed_id}'")

        attempted_mapped_ids_from_other_feeds_df = \
            AdrmIdsMapper._join_with_existing_ids(unmapped_ids_in_current_feed_df, id_mapping_table_other_feeds_df,
                                                  id_mapping_column_in_use, data_id_column_in_use)

        unmapped_ids_from_other_feeds_df = attempted_mapped_ids_from_other_feeds_df.filter(
            f"{GlobalConstants.ADRM_ID_COLUMN_NAME} is null"). \
            select(unmapped_ids_in_current_feed_df.columns)

        mapped_ids_from_other_feeds_df = attempted_mapped_ids_from_other_feeds_df. \
            filter(f"{GlobalConstants.ADRM_ID_COLUMN_NAME} is not null"). \
            select(F.col(internal_id_column_name).alias(GlobalConstants.INTERNAL_ID_COLUMN_NAME),
                   F.col(external_id_column_name).alias(GlobalConstants.EXTERNAL_ID_COLUMN_NAME),
                   F.col(GlobalConstants.ADRM_ID_COLUMN_NAME),
                   F.lit(feed_id).alias(GlobalConstants.FEED_ID_COLUMN_NAME))

        return (unmapped_ids_from_other_feeds_df, mapped_ids_from_other_feeds_df)

    @staticmethod
    def _get_unmapped_ids_in_current_feed(source_df: DataFrame, id_mapping_table_df: DataFrame,
                                          id_mapping_column_in_use: str, data_id_column_in_use: str,
                                          feed_id: str) -> DataFrame:
        id_mapping_table_current_feed_df = AdrmIdsMapper._get_id_mapping_table_current_feed_df(id_mapping_table_df,
                                                                                               feed_id)

        attempted_mapped_ids_in_current_feed_df = AdrmIdsMapper._join_with_existing_ids(source_df,
                                                                                        id_mapping_table_current_feed_df,
                                                                                        id_mapping_column_in_use,
                                                                                        data_id_column_in_use)

        return attempted_mapped_ids_in_current_feed_df.filter(
            f"{GlobalConstants.ADRM_ID_COLUMN_NAME} is null") \
            .select(*source_df.columns)

    @staticmethod
    def _save_mappings(spark: SparkSession, df: DataFrame, id_mapping_tables_location: str, id_mapping_table_name: str):
        location = AdrmIdsMapper.specific_table_location(id_mapping_tables_location, id_mapping_table_name)

        df. \
            write. \
            mode("append"). \
            format(AdrmIdsMapper.DATA_FORMAT). \
            partitionBy(GlobalConstants.FEED_ID_COLUMN_NAME). \
            save(location)

    @staticmethod
    def _join_with_existing_ids(unmapped_ids: DataFrame, mapping_table_df: DataFrame,
                                id_mapping_column_in_use: str, data_id_column_in_use: str) -> DataFrame:
        return unmapped_ids.join(mapping_table_df,
                                 on=[unmapped_ids[data_id_column_in_use] == mapping_table_df[id_mapping_column_in_use]],
                                 how="left"
                                 ).drop(GlobalConstants.INTERNAL_ID_COLUMN_NAME,
                                        GlobalConstants.EXTERNAL_ID_COLUMN_NAME)

    @staticmethod
    def is_external_id_mapped(mapping_df: DataFrame) -> bool:
        return not mapping_df.filter(
            (F.col(GlobalConstants.EXTERNAL_ID_COLUMN_NAME) != "") &
            (F.col(GlobalConstants.EXTERNAL_ID_COLUMN_NAME).isNotNull())
        ).limit(1).isEmpty()

    @staticmethod
    def _get_id_columns_in_use(mapping_table_df: DataFrame, internal_id_column_name: str, external_id_column_name) -> \
            Tuple[str, str]:
        if AdrmIdsMapper.is_external_id_mapped(mapping_table_df):
            return (GlobalConstants.EXTERNAL_ID_COLUMN_NAME, external_id_column_name)
        else:
            return (GlobalConstants.INTERNAL_ID_COLUMN_NAME, internal_id_column_name)

    @staticmethod
    def get_mapping_table_name(target_table_name: str) -> str:
        return target_table_name.upper() + GlobalConstants.ID_MAPPING_TABLE_NAME_SUFFIX

    @staticmethod
    def _validate_all_ids_are_unique(df: DataFrame, ids_column_name: str):
        # This method validates that all ids are unique
        # Group by the id column and count occurrences
        duplicate_count_df = df.groupBy(ids_column_name).agg(F.count(ids_column_name).alias('count'))

        # Filter to find ids with more than one occurrence
        duplicate_ids = duplicate_count_df.filter(F.col('count') > 1)

        # If any duplicates are found, raise an exception
        if duplicate_ids.count() > 0:
            raise ValueError(f"Column '{ids_column_name}' contains duplicate values. "
                             f"Please ensure all values are unique.")

# SIG # Begin Windows Authenticode signature block
# MIIoLAYJKoZIhvcNAQcCoIIoHTCCKBkCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQse8BENmB6EqSR2hd
# JGAGggIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCALfMUYkCZlm9qu
# 1YnvRJRKnK6E1OJSfqNeaORPhXSWxKCCDXYwggX0MIID3KADAgECAhMzAAADrzBA
# DkyjTQVBAAAAAAOvMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjMxMTE2MTkwOTAwWhcNMjQxMTE0MTkwOTAwWjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDOS8s1ra6f0YGtg0OhEaQa/t3Q+q1MEHhWJhqQVuO5amYXQpy8MDPNoJYk+FWA
# hePP5LxwcSge5aen+f5Q6WNPd6EDxGzotvVpNi5ve0H97S3F7C/axDfKxyNh21MG
# 0W8Sb0vxi/vorcLHOL9i+t2D6yvvDzLlEefUCbQV/zGCBjXGlYJcUj6RAzXyeNAN
# xSpKXAGd7Fh+ocGHPPphcD9LQTOJgG7Y7aYztHqBLJiQQ4eAgZNU4ac6+8LnEGAL
# go1ydC5BJEuJQjYKbNTy959HrKSu7LO3Ws0w8jw6pYdC1IMpdTkk2puTgY2PDNzB
# tLM4evG7FYer3WX+8t1UMYNTAgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQURxxxNPIEPGSO8kqz+bgCAQWGXsEw
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzUwMTgyNjAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAISxFt/zR2frTFPB45Yd
# mhZpB2nNJoOoi+qlgcTlnO4QwlYN1w/vYwbDy/oFJolD5r6FMJd0RGcgEM8q9TgQ
# 2OC7gQEmhweVJ7yuKJlQBH7P7Pg5RiqgV3cSonJ+OM4kFHbP3gPLiyzssSQdRuPY
# 1mIWoGg9i7Y4ZC8ST7WhpSyc0pns2XsUe1XsIjaUcGu7zd7gg97eCUiLRdVklPmp
# XobH9CEAWakRUGNICYN2AgjhRTC4j3KJfqMkU04R6Toyh4/Toswm1uoDcGr5laYn
# TfcX3u5WnJqJLhuPe8Uj9kGAOcyo0O1mNwDa+LhFEzB6CB32+wfJMumfr6degvLT
# e8x55urQLeTjimBQgS49BSUkhFN7ois3cZyNpnrMca5AZaC7pLI72vuqSsSlLalG
# OcZmPHZGYJqZ0BacN274OZ80Q8B11iNokns9Od348bMb5Z4fihxaBWebl8kWEi2O
# PvQImOAeq3nt7UWJBzJYLAGEpfasaA3ZQgIcEXdD+uwo6ymMzDY6UamFOfYqYWXk
# ntxDGu7ngD2ugKUuccYKJJRiiz+LAUcj90BVcSHRLQop9N8zoALr/1sJuwPrVAtx
# HNEgSW+AKBqIxYWM4Ev32l6agSUAezLMbq5f3d8x9qzT031jMDT+sUAoCw0M5wVt
# CUQcqINPuYjbS1WgJyZIiEkBMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGgwwghoIAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAAOvMEAOTKNNBUEAAAAAA68wDQYJYIZIAWUDBAIB
# BQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIOTlIASvxtEqo5fcEGoFXdaq
# 9hjA+vOqlmomHuJN2hOFMEIGCisGAQQBgjcCAQwxNDAyoBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEB
# BQAEggEAN6cm0KclluX749deeZ6t260N+QYxpXJzKEvKj2lQEEIaG9t7R0INRnVz
# qF+vNAv6obfV3ffJ4N7EO/OdTomzCAKzfF/tgP2f7ReqaGywO00saJtQmgBDcy5r
# xVf6KGMCAjXaduoqtz9hITBM7skMF0QAgl+hhBZ+LzbRWpq8c/K7bANWBCARtukS
# C2s/bGBraCTKIOFFJiTodt/k4vaQ0hcspMSmpcBzWY1plU/8XbxHZtuL+vs/O8mG
# kaJWHfHJZ3oboLxdZU6dJ6HchgfmcXLaNfnQDLcb5Hhh/8piDZ1S2WL636etHHPb
# R5t2kj2U5G4wOINw+QwEpMOzf5wIPKGCF5YwgheSBgorBgEEAYI3AwMBMYIXgjCC
# F34GCSqGSIb3DQEHAqCCF28wghdrAgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFSBgsq
# hkiG9w0BCRABBKCCAUEEggE9MIIBOQIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFl
# AwQCAQUABCBjLKlPumUyd5dr4CwCywSc4raRENpFcKyiP5cDpsNXTgIGZr3xE9f6
# GBMyMDI0MDgxNTEzMzUzOC44OTdaMASAAgH0oIHRpIHOMIHLMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1l
# cmljYSBPcGVyYXRpb25zMScwJQYDVQQLEx5uU2hpZWxkIFRTUyBFU046OTIwMC0w
# NUUwLUQ5NDcxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2Wg
# ghHsMIIHIDCCBQigAwIBAgITMwAAAecujy+TC08b6QABAAAB5zANBgkqhkiG9w0B
# AQsFADB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYD
# VQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDAeFw0yMzEyMDYxODQ1
# MTlaFw0yNTAzMDUxODQ1MTlaMIHLMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2Fz
# aGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENv
# cnBvcmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1lcmljYSBPcGVyYXRpb25z
# MScwJQYDVQQLEx5uU2hpZWxkIFRTUyBFU046OTIwMC0wNUUwLUQ5NDcxJTAjBgNV
# BAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2UwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQDCV58v4IuQ659XPM1DtaWMv9/HRUC5kdiEF89YBP6/
# Rn7kjqMkZ5ESemf5Eli4CLtQVSefRpF1j7S5LLKisMWOGRaLcaVbGTfcmI1vMRJ1
# tzMwCNIoCq/vy8WH8QdV1B/Ab5sK+Q9yIvzGw47TfXPE8RlrauwK/e+nWnwMt060
# akEZiJJz1Vh1LhSYKaiP9Z23EZmGETCWigkKbcuAnhvh3yrMa89uBfaeHQZEHGQq
# dskM48EBcWSWdpiSSBiAxyhHUkbknl9PPztB/SUxzRZjUzWHg9bf1mqZ0cIiAWC0
# EjK7ONhlQfKSRHVLKLNPpl3/+UL4Xjc0Yvdqc88gOLUr/84T9/xK5r82ulvRp2A8
# /ar9cG4W7650uKaAxRAmgL4hKgIX5/0aIAsbyqJOa6OIGSF9a+DfXl1LpQPNKR79
# 2scF7tjD5WqwIuifS9YUiHMvRLjjKk0SSCV/mpXC0BoPkk5asfxrrJbCsJePHSOE
# blpJzRmzaP6OMXwRcrb7TXFQOsTkKuqkWvvYIPvVzC68UM+MskLPld1eqdOOMK7S
# bbf2tGSZf3+iOwWQMcWXB9gw5gK3AIYK08WkJJuyzPqfitgubdRCmYr9CVsNOuW+
# wHDYGhciJDF2LkrjkFUjUcXSIJd9f2ssYitZ9CurGV74BQcfrxjvk1L8jvtN7mul
# IwIDAQABo4IBSTCCAUUwHQYDVR0OBBYEFM/+4JiAnzY4dpEf/Zlrh1K73o9YMB8G
# A1UdIwQYMBaAFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMF8GA1UdHwRYMFYwVKBSoFCG
# Tmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY3Jvc29mdCUy
# MFRpbWUtU3RhbXAlMjBQQ0ElMjAyMDEwKDEpLmNybDBsBggrBgEFBQcBAQRgMF4w
# XAYIKwYBBQUHMAKGUGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY2Vy
# dHMvTWljcm9zb2Z0JTIwVGltZS1TdGFtcCUyMFBDQSUyMDIwMTAoMSkuY3J0MAwG
# A1UdEwEB/wQCMAAwFgYDVR0lAQH/BAwwCgYIKwYBBQUHAwgwDgYDVR0PAQH/BAQD
# AgeAMA0GCSqGSIb3DQEBCwUAA4ICAQB0ofDbk+llWi1cC6nsfie5Jtp09o6b6ARC
# pvtDPq2KFP+hi+UNNP7LGciKuckqXCmBTFIhfBeGSxvk6ycokdQr3815pEOaYWTn
# HvQ0+8hKy86r1F4rfBu4oHB5cTy08T4ohrG/OYG/B/gNnz0Ol6v7u/qEjz48zXZ6
# ZlxKGyZwKmKZWaBd2DYEwzKpdLkBxs6A6enWZR0jY+q5FdbV45ghGTKgSr5ECAOn
# LD4njJwfjIq0mRZWwDZQoXtJSaVHSu2lHQL3YHEFikunbUTJfNfBDLL7Gv+sTmRi
# DZky5OAxoLG2gaTfuiFbfpmSfPcgl5COUzfMQnzpKfX6+FkI0QQNvuPpWsDU8sR+
# uni2VmDo7rmqJrom4ihgVNdLaMfNUqvBL5ZiSK1zmaELBJ9a+YOjE5pmSarW5sGb
# n7iVkF2W9JQIOH6tGWLFJS5Hs36zahkoHh8iD963LeGjZqkFusKaUW72yMj/yxTe
# GEDOoIr35kwXxr1Uu+zkur2y+FuNY0oZjppzp95AW1lehP0xaO+oBV1XfvaCur/B
# 5PVAp2xzrosMEUcAwpJpio+VYfIufGj7meXcGQYWA8Umr8K6Auo+Jlj8IeFS6lSv
# KhqQpmdBzAMGqPOQKt1Ow3ZXxehK7vAiim3ZiALlM0K546k0sZrxdZPgpmz7O8w9
# gHLuyZAQezCCB3EwggVZoAMCAQICEzMAAAAVxedrngKbSZkAAAAAABUwDQYJKoZI
# hvcNAQELBQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAw
# DgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24x
# MjAwBgNVBAMTKU1pY3Jvc29mdCBSb290IENlcnRpZmljYXRlIEF1dGhvcml0eSAy
# MDEwMB4XDTIxMDkzMDE4MjIyNVoXDTMwMDkzMDE4MzIyNVowfDELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRp
# bWUtU3RhbXAgUENBIDIwMTAwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoIC
# AQDk4aZM57RyIQt5osvXJHm9DtWC0/3unAcH0qlsTnXIyjVX9gF/bErg4r25Phdg
# M/9cT8dm95VTcVrifkpa/rg2Z4VGIwy1jRPPdzLAEBjoYH1qUoNEt6aORmsHFPPF
# dvWGUNzBRMhxXFExN6AKOG6N7dcP2CZTfDlhAnrEqv1yaa8dq6z2Nr41JmTamDu6
# GnszrYBbfowQHJ1S/rboYiXcag/PXfT+jlPP1uyFVk3v3byNpOORj7I5LFGc6XBp
# Dco2LXCOMcg1KL3jtIckw+DJj361VI/c+gVVmG1oO5pGve2krnopN6zL64NF50Zu
# yjLVwIYwXE8s4mKyzbnijYjklqwBSru+cakXW2dg3viSkR4dPf0gz3N9QZpGdc3E
# XzTdEonW/aUgfX782Z5F37ZyL9t9X4C626p+Nuw2TPYrbqgSUei/BQOj0XOmTTd0
# lBw0gg/wEPK3Rxjtp+iZfD9M269ewvPV2HM9Q07BMzlMjgK8QmguEOqEUUbi0b1q
# GFphAXPKZ6Je1yh2AuIzGHLXpyDwwvoSCtdjbwzJNmSLW6CmgyFdXzB0kZSU2LlQ
# +QuJYfM2BjUYhEfb3BvR/bLUHMVr9lxSUV0S2yW6r1AFemzFER1y7435UsSFF5PA
# PBXbGjfHCBUYP3irRbb1Hode2o+eFnJpxq57t7c+auIurQIDAQABo4IB3TCCAdkw
# EgYJKwYBBAGCNxUBBAUCAwEAATAjBgkrBgEEAYI3FQIEFgQUKqdS/mTEmr6CkTxG
# NSnPEP8vBO4wHQYDVR0OBBYEFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMFwGA1UdIARV
# MFMwUQYMKwYBBAGCN0yDfQEBMEEwPwYIKwYBBQUHAgEWM2h0dHA6Ly93d3cubWlj
# cm9zb2Z0LmNvbS9wa2lvcHMvRG9jcy9SZXBvc2l0b3J5Lmh0bTATBgNVHSUEDDAK
# BggrBgEFBQcDCDAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMC
# AYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBTV9lbLj+iiXGJo0T2UkFvX
# zpoYxDBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20v
# cGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcmwwWgYI
# KwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNydDANBgkqhkiG
# 9w0BAQsFAAOCAgEAnVV9/Cqt4SwfZwExJFvhnnJL/Klv6lwUtj5OR2R4sQaTlz0x
# M7U518JxNj/aZGx80HU5bbsPMeTCj/ts0aGUGCLu6WZnOlNN3Zi6th542DYunKmC
# VgADsAW+iehp4LoJ7nvfam++Kctu2D9IdQHZGN5tggz1bSNU5HhTdSRXud2f8449
# xvNo32X2pFaq95W2KFUn0CS9QKC/GbYSEhFdPSfgQJY4rPf5KYnDvBewVIVCs/wM
# nosZiefwC2qBwoEZQhlSdYo2wh3DYXMuLGt7bj8sCXgU6ZGyqVvfSaN0DLzskYDS
# PeZKPmY7T7uG+jIa2Zb0j/aRAfbOxnT99kxybxCrdTDFNLB62FD+CljdQDzHVG2d
# Y3RILLFORy3BFARxv2T5JL5zbcqOCb2zAVdJVGTZc9d/HltEAY5aGZFrDZ+kKNxn
# GSgkujhLmm77IVRrakURR6nxt67I6IleT53S0Ex2tVdUCbFpAUR+fKFhbHP+Crvs
# QWY9af3LwUFJfn6Tvsv4O+S3Fb+0zj6lMVGEvL8CwYKiexcdFYmNcP7ntdAoGokL
# jzbaukz5m/8K6TT4JDVnK+ANuOaMmdbhIurwJ0I9JZTmdHRbatGePu1+oDEzfbzL
# 6Xu/OHBE0ZDxyKs6ijoIYn/ZcGNTTY3ugm2lBRDBcQZqELQdVTNYs6FwZvKhggNP
# MIICNwIBATCB+aGB0aSBzjCByzELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjElMCMGA1UECxMcTWljcm9zb2Z0IEFtZXJpY2EgT3BlcmF0aW9uczEn
# MCUGA1UECxMeblNoaWVsZCBUU1MgRVNOOjkyMDAtMDVFMC1EOTQ3MSUwIwYDVQQD
# ExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloiMKAQEwBwYFKw4DAhoDFQCz
# cgTnGasSwe/dru+cPe1NF/vwQ6CBgzCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1w
# IFBDQSAyMDEwMA0GCSqGSIb3DQEBCwUAAgUA6mhvlDAiGA8yMDI0MDgxNTEyMTQx
# MloYDzIwMjQwODE2MTIxNDEyWjB2MDwGCisGAQQBhFkKBAExLjAsMAoCBQDqaG+U
# AgEAMAkCAQACAUMCAf8wBwIBAAICEqAwCgIFAOppwRQCAQAwNgYKKwYBBAGEWQoE
# AjEoMCYwDAYKKwYBBAGEWQoDAqAKMAgCAQACAwehIKEKMAgCAQACAwGGoDANBgkq
# hkiG9w0BAQsFAAOCAQEAVoId/SqYi2uI8FU2e2fCbtjs9CfTRUCfBNOfrA+pRnYF
# OkSKmkottGOmKIeuPqBmT0aair2QPP8g/cP6w9bTS+qikW+v282YDsaxLfrwwMyt
# CmsKzs0s5ijlxsvaDhnblnlgdlPgExXYqUAfv7ZHxwKsTxgUu2bbvw2PFM+XJRbF
# y9xDueV6WwWftLCiKLqXbdKlRQQCjZoL5Xs82NKk7O3E6Uec4dYoN1nX+IT2RGw1
# OCjsY1Pomz2fMQku0pPSgcw8bOaJEHeie3fdhFafnU8CnI4oJs4fTeQyVokisByB
# eN/BDjUh4S+N0JHhU2CSF0MO9VoK2xyiMtooU3teLjGCBA0wggQJAgEBMIGTMHwx
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1p
# Y3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAB5y6PL5MLTxvpAAEAAAHn
# MA0GCWCGSAFlAwQCAQUAoIIBSjAaBgkqhkiG9w0BCQMxDQYLKoZIhvcNAQkQAQQw
# LwYJKoZIhvcNAQkEMSIEIDVoBvUm6twc3rWUoCdgxFoYzu0loVYIade6GKAy/eJb
# MIH6BgsqhkiG9w0BCRACLzGB6jCB5zCB5DCBvQQg5TZdDXZqhv0N4MVcz1QUd4Rf
# vgW/QAG9AwbuoLnWc60wgZgwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0Eg
# MjAxMAITMwAAAecujy+TC08b6QABAAAB5zAiBCBq67pL8DlDKAqnMPNJcASIuxv0
# 3F1BKDx66VPk0UxJ0jANBgkqhkiG9w0BAQsFAASCAgCiAmvOA3MoP5G8yeGtGwFj
# DelXkTzZ1XNQeTGUKl8ZEa0iEA4J2g4hpAPvJwYSjE73sb8NFgbWup4y7vHrVDA5
# sR9JjgeNJdVgxb0KjN+Eweqn/fxe2JnY4c67bdHdxN4+rUZbm9J/3ibaIPLaKAHH
# gNXPRpIRycnu/qshe6qBSsLoYaURpamEmi5Jl33QgTGC55AO2FsbY8tJshTt8WHI
# 7u5cp/eHrwDd0PCYCZeHyLVH87PKgr6wjIuntLH+GatN/+s+LaF995RFeBv6INXa
# MQEDPdgObx236rJnUvQlgP0d9Zc8wuH8+jMGpQHnpjIVjsQ3ioSugmbGk1ejEpTW
# Ad0S+KSQIbwMi50SjrG0SaC1pfHqomDI2CLR+7A5JfLjHp4/5vV/pIXA8yy57EAP
# EkfdxWd1QRdxOBmJj8oF2tvJHhX6WOG+xtisyzKISN87P6J+zrdyUb+ogSXrGV6k
# pXSDRFfFSXt9x7fDFpKXOvO9MReMq3A/UZvhcO94urE8GGaoutZNHLkkUa/rN7OB
# 82aSe6wp5E2FgtxVIs8C9xiwgXO7cr+ZRvazmnktwsH258vZl+xyMdV79OljVT/X
# 2uW8KDNxdPzTai5lqHGRgVNuf3PMjPQ7TVEgn3Sxa2gNH3zOIV7zQnt2a+oeI8Cj
# xIAFc7JpXULsazXy+KMjtw==
# SIG # End Windows Authenticode signature block