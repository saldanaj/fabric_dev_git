
import os
import json
from datetime import datetime
from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.functions import input_file_name, col
from typing import Callable
from microsoft.fabric.hls.hds.claims_data_ingestions.json.utils.claims_json_processor import ClaimsJSONProcessor
from microsoft.fabric.hls.hds.claims_data_ingestions.cms_cclf.utils.utils import add_new_literal_column_for_input_value, move_file_to_folder
from microsoft.fabric.hls.hds.claims_data_ingestions.json.utils.constants import JSONClaimsIngestionConstants as C
from microsoft.fabric.hls.hds.claims_data_ingestions.json.utils.json_utils import JSONUtils
from microsoft.fabric.hls.hds.global_constants.global_constants import GlobalConstants
from microsoft.fabric.hls.hds.utils.dataExtractor import DataExtractor
from microsoft.fabric.hls.hds.utils.dataframe_utils import append_to_delta_table_using_path
from microsoft.fabric.hls.hds.utils.logging_helper import LoggingHelper
from microsoft.fabric.hls.hds.utils.mssparkutils_client_base import MSSparkUtilsClientBase
from microsoft.fabric.hls.hds.utils.utils import Utils as CommonUtils, FolderPath
from microsoft.fabric.hls.hds.global_constants.logging_constants import LoggingConstants as LC
from microsoft.fabric.hls.hds.utils.business_events_ingestion_handler import BusinessEventsIngestion
import uuid

from microsoft.fabric.hls.hds.utils.business_events_ingestion_handler import BusinessEventsIngestion
import uuid


class Process_JSON:
    """
    Class for processing json files 
    """
    def __init__(self, 
                 spark: SparkSession,
                 json_files_drop_path: str,
                 lakehouse_files_root_path: str,
                 target_delta_tables_path: str,
                 business_events_ingestion_service: BusinessEventsIngestion,
                 mssparkutils_client: MSSparkUtilsClientBase = None,
                 collect_metrics_fn: Callable = None,
                 execution_metrics_collector = None,
                 execution_metrics_accumulator_id: str = "",
                 ) -> None:
        """
        Initializes a new instance of the Process_JSON class.

        Args:
            spark (SparkSession): The Spark session.
            json_files_drop_path (str): The path where JSON files will be dropped.
            lakehouse_files_root_path (str): The root path of the lakehouse files.
            target_delta_tables_path (str): The path to the target Delta tables.
            mssparkutils_client (MSSparkUtilsClientBase, optional): The MSSparkUtils client. Default is None.

        Returns:
            None
        """
        
        self.spark: SparkSession = spark
        self.json_files_drop_path = json_files_drop_path
        
        self.lakehouse_files_root_path = lakehouse_files_root_path
        self.target_delta_tables_path = target_delta_tables_path
        self._mssparkutils_client = CommonUtils.get_mssparkutils_client(mssparkutils_client)
        self._logger = LoggingHelper.get_generic_logger(self.spark, self.__class__.__name__, GlobalConstants.LOGGING_LEVEL)  
        self.failed_files_path = os.path.join(self.lakehouse_files_root_path, 
                                              GlobalConstants.FAILED_FOLDER,
                                              GlobalConstants.CLAIMS_FOLDER,
                                              GlobalConstants.JSON_FOLDER, 
                                              datetime.now().strftime("%Y/%m/%d"))
        self._collect_metrics_fn = collect_metrics_fn
        self._execution_metrics_collector = execution_metrics_collector
        self._execution_metrics_accumulator_id = execution_metrics_accumulator_id
        self._json_utils = JSONUtils(self.spark)        
        self.business_events_ingestion_service = business_events_ingestion_service
        self.claims_json_schema = {}
        self.claim_type_structure_configs = {}
        
    def process_json_files(self, json_files_config_path: str, checkpoint_path: str, max_files_per_trigger: int):
        """
        Process all json files saving it to the Delta table.
        """
        
        self.checkpoint_path = checkpoint_path
        self.config_directory = json_files_config_path
        self.json_files_mapping_path = os.path.join(json_files_config_path,C.CLAIM_FILEMAPPING_CONFIG_NAME)
          # Load claim types configuration if it exists        
        self.claims_json_schema = self._json_utils.load_claim_file_mapping_config(self.json_files_mapping_path)
        if(self.claims_json_schema is None or "claimTypes" not in self.claims_json_schema):
            self._logger.error(LC.JSON_FILE_MAPPING_CONFIG_NOT_FOUND_ERR_MSG)
            return None
        
        # Pre-load all structure configurations for each claim type
        self._logger.info(LC.JSON_PRELOADING_STRUCTURE_CONFIGS_INFO_MSG)
        self.claim_type_structure_configs = {}
        
        if self.claims_json_schema and "claimTypes" in self.claims_json_schema:
            for claim_type in self.claims_json_schema.get("claimTypes", []):
                claim_type_name = claim_type.get("name", "unknown")
                structure_config = self._json_utils.load_claim_type_structure_config(self.config_directory, claim_type)
                self.claim_type_structure_configs[claim_type_name] = structure_config
                
        # Process files for each namespace
        for namespace in self._json_utils.get_namespaces(self._mssparkutils_client, self.json_files_drop_path):
            namespace_path = os.path.join(self.json_files_drop_path, namespace)
            namespace_checkpoint_path = os.path.join(self.checkpoint_path, namespace)     

            # Retrieve filetypes three levels down
            for file_type, file_path in self._json_utils.get_filetypes(self._mssparkutils_client, namespace_path):
                
                try:   
                    if not list(self._mssparkutils_client.fs_ls(file_path)):
                        self._logger.info(LC.EMPTY_PROCESS_PATH.format(process_path = file_path))
                        continue
                      # Check for claim type specific config
                    claim_type_config = self._json_utils.get_claim_type_config(file_type, self.claims_json_schema)
                      # If claim type config exists, use pre-loaded structure config. 
                    if claim_type_config:
                        claim_type_name = claim_type_config.get("name")
                        if claim_type_name in self.claim_type_structure_configs:
                            self.file_config = self.claim_type_structure_configs[claim_type_name]
                        else:
                            self._logger.info(LC.JSON_NO_PRELOADED_CONFIG_INFO_MSG.format(claim_type_name=claim_type_name))
                            self.file_config = self._json_utils.load_claim_type_structure_config(self.config_directory, claim_type_config)
                    else:
                        message = LC.JSON_CLAIM_TYPE_CONFIG_NOT_FOUND_ERR_MSG.format(file_type=file_type)
                        self._logger.error(message)
                        business_event_id = str(uuid.uuid4())
                        new_row = self.business_events_ingestion_service.create_new_business_event_row(id=business_event_id, activityName=C.CLAIMS_DELTA_TABLE_INGESTION_NOTEBOOK, 
                        targetTableName=C.JSON_DELTA_TABLE_NAME,targetLakehouseName=GlobalConstants.DEFAULT_BRONZE_LAKEHOUSE_NAME,   
                        sourceFilePath=json_files_config_path, sourceLakehouseName=GlobalConstants.DEFAULT_BRONZE_LAKEHOUSE_NAME, severity=GlobalConstants.ERROR, eventType=C.BE_EVENT_TYPE_FAILED_FILES, 
                        message=message, active=True
                        )
                        self.business_events_ingestion_service.insert_business_events([new_row])
                
                        return None
                    
                    self.extractor = DataExtractor(self.spark)
                    df_stream = self.extractor.read_json_files_to_df_stream(
                            file_path,
                            max_files_per_trigger
                        )
                except Exception as e:
                    self._logger.error(
                    LC.JSON_SPARK_STREAM_READ_ERR_MSG.format(drop_folder = file_path, error_msg = str(e)))
                    raise 
                if df_stream is None: return
                df_stream = add_new_literal_column_for_input_value(df_stream, C.FILE_PATH_COLUMN_NAME, input_file_name()) 
                df_stream = add_new_literal_column_for_input_value(df_stream, C.SOURCE_SYSTEM_COLUMN_NAME, namespace) 
                df_stream = add_new_literal_column_for_input_value(df_stream, C.DATA_FORMAT_COLUMN_NAME, file_type) 
                query = (df_stream.writeStream.format("delta")
                    .trigger(availableNow=True)
                    .option("checkpointLocation", checkpoint_path)
                    .foreachBatch(lambda df, batch_id: self.process_json_files_batch_records(df, C.FAILED_NUM_RETRIES, namespace, file_type))
                    .start())
                query.awaitTermination()
                
        return None

    def process_json_files_batch_records(self, df: DataFrame, num_retries: int, namespace: str, file_type: str):
        total_records = df.count()

        if total_records == 0:
            self._logger.info(LC.JSON_NO_NEW_FILE_FOUND_INFO_MSG)
            return

        if num_retries < 0:
            if total_records > 0:
                try:
                    for row in df.collect():
                        move_file_to_folder(
                            row.filePath, 
                            os.path.join(self.failed_files_path, namespace, os.path.basename(row.filePath)), 
                            self._mssparkutils_client
                        )                   
                except Exception as e:
                    self._logger.error(LC.FAILED_FILES_NOT_MOVED_ERR_MSG.format(error_msg=str(e)))
            return

        if total_records > 0:
            try:
                self._logger.info(LC.JSON_CLAIMS_RECORDS_FOUND_MSG.format(records_num=total_records))
                
                if "_corrupt_record" in df.columns:
                    df_corrupt = df.where(col("_corrupt_record").isNotNull())
                    df_clean = df.where(col("_corrupt_record").isNull())
                else:
                    df_corrupt = self.spark.createDataFrame([], df.schema)
                    df_clean = df

                # Apply transformation only on valid records
                df_success, df_failed = ClaimsJSONProcessor.Transform_JSON(df_clean, namespace, file_type, self.file_config, self._logger, self.spark)

                if df_failed.count() > 0:
                    
                    business_events_failed = []
                    try:
                        failed_file_paths = df_failed.select("filePath").distinct().collect()   
                        for row in failed_file_paths:  
                            move_file_to_folder(
                                row.filePath, 
                                os.path.join(self.failed_files_path, namespace), 
                                self._mssparkutils_client
                            )
                            try:
                                be_row = self.business_events_ingestion_service.create_new_business_event_row(
                                    id=str(uuid.uuid4()),
                                    activityName =    C.CLAIMS_DELTA_TABLE_INGESTION_NOTEBOOK,
                                    targetFilePath=   os.path.join(self.failed_files_path, namespace,os.path.basename(row.filePath)),
                                    sourceLakehouseName=self.lakehouse_files_root_path,  
                                    targetLakehouseName=self.target_delta_tables_path,   
                                    sourceFilePath=   row.filePath,                  
                                    targetTableName= C.JSON_DELTA_TABLE_NAME,                 
                                    severity=GlobalConstants.ERROR,                      
                                    eventType= C.BE_EVENT_TYPE_FAILED_FILES,                        
                                    message= LC.BE_FAILED_FILE_MESSAGE.format(file_path = row.filePath),                                )
                                business_events_failed.append(be_row)                                
                    
                            except Exception as e:
                                self._logger.error(LC.JSON_FAILED_CREATE_BUSINESS_EVENT_MSG.format(file_path=row.filePath, error_msg=e))

                        if business_events_failed:
                            try:
                                self.business_events_ingestion_service.insert_business_events(business_events_failed)
                            except Exception as e:
                                self._logger.error(LC.JSON_FAILED_INSERT_BUSINESS_EVENTS_MSG.format(error_msg=e))
                        self._logger.error(LC.JSON_TRANSFORMATION_FAILED_ROWS_MSG.format(num_rows=len(failed_file_paths)))


                    except Exception as e:
                        self._logger.error(LC.FAILED_FILES_NOT_MOVED_ERR_MSG.format(error_msg=str(e)))
            
                if df_corrupt.count() > 0:
                    
                    try:
                        corrupt_file_paths = df_corrupt.select("filePath").distinct().collect()   
                        business_events_corrupt = []
                        for row in corrupt_file_paths:  
                            move_file_to_folder(
                                row.filePath, 
                                os.path.join(self.failed_files_path, namespace), 
                                self._mssparkutils_client
                            )
                            try:
                                be_row = self.business_events_ingestion_service.create_new_business_event_row(
                                    id=str(uuid.uuid4()),
                                    activityName =    C.CLAIMS_DELTA_TABLE_INGESTION_NOTEBOOK,
                                    targetFilePath=   os.path.join(self.failed_files_path, namespace,os.path.basename(row.filePath)),
                                    sourceLakehouseName=GlobalConstants.DEFAULT_BRONZE_LAKEHOUSE_NAME,  
                                    targetLakehouseName=GlobalConstants.DEFAULT_BRONZE_LAKEHOUSE_NAME,   
                                    sourceFilePath=   row.filePath,                  
                                    targetTableName= C.JSON_DELTA_TABLE_NAME,                 
                                    severity=GlobalConstants.ERROR,                      
                                    eventType= C.BE_EVENT_TYPE_FAILED_FILES,                        
                                    message= LC.BE_FAILED_CORRUPT_FILE_MESSAGE.format(file_path = row.filePath),                                                                            )
                                business_events_corrupt.append(be_row)
                                
                    
                            except Exception as e:
                                self._logger.error(LC.JSON_FAILED_CREATE_BUSINESS_EVENT_MSG.format(file_path=row.filePath, error_msg=e))

                        if business_events_corrupt:
                            try:
                                self.business_events_ingestion_service.insert_business_events(business_events_corrupt)
                            except Exception as e:
                                self._logger.error(LC.JSON_FAILED_INSERT_BUSINESS_EVENTS_MSG.format(error_msg=e))
                        

                        self._logger.error(LC.JSON_TRANSFORMATION_FAILED_CORRUPT_FILES_MSG.format(num_files=len(corrupt_file_paths)))
                    except Exception as e:
                        self._logger.error(LC.FAILED_FILES_NOT_MOVED_ERR_MSG.format(error_msg=str(e)))
                number_of_df_success = df_success.count()
                
                if number_of_df_success > 0:

                    try:
                        append_to_delta_table_using_path(
                            df_to_process=df_success,
                            delta_table_path=os.path.join(self.target_delta_tables_path, C.JSON_DELTA_TABLE_NAME),
                            logger=self._logger,
                            collect_metrics_fn=self._collect_metrics_fn
                        )
                        # Track successful records
                        if self._execution_metrics_collector:
                            distinct_file_paths_df = df_success.select("filePath").distinct()
                            file_paths = [row.filePath for row in distinct_file_paths_df.collect()]                            
                            source_data_size_bytes = self._json_utils.get_total_file_size_bytes(self._mssparkutils_client,file_paths)

                            self._execution_metrics_collector.accumulate(
                            accumulator_activity_id=self._execution_metrics_accumulator_id,
                            metrics={
                                "numSourceRecords": number_of_df_success,
                                "sourceDataSizeBytes": source_data_size_bytes,
                                "numSourceFiles": distinct_file_paths_df.count(),
                            })
                                                                           
                    except Exception as ex:
                        self._logger.error(LC.JSON_ERROR_WRITING_TO_DELTA_TABLE_MSG.format(error_msg=str(ex)))
                        self.process_json_files_batch_records(df, num_retries - 1, namespace, file_type)
                        raise
                else:
                    self._logger.error(LC.JSON_NO_RECORDS_AFTER_TRANSFORMATION_MSG)            
            except Exception as ex:
                self._logger.error(LC.JSON_UNEXPECTED_ERROR_MSG.format(error_msg=str(ex)))
                raise    
