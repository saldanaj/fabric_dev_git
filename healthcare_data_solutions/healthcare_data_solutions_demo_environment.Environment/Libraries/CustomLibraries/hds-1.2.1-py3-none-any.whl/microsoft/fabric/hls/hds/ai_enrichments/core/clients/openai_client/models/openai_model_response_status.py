# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# --------------------------------------------------------------------------
from dataclasses import dataclass
from typing import Optional
from microsoft.fabric.hls.hds.ai_enrichments.core.clients.openai_client.models.openai_response_status import OpenAIResponseStatus

@dataclass
class OpenAIModelResponseStatus:
    """
    Status class represents the outcome of an operation with details about the result and any errors.

    Attributes:
        result (OpenAIResponseStatus): The result of the operation, default is OpenAIResponseStatus.SUCCESS.
        error_details (Optional[str]): Detailed information about any error that occurred, default is an empty string.
        error_type (Optional[str]): The type of error that occurred, default is an empty string.
    """
    result: OpenAIResponseStatus = OpenAIResponseStatus.SUCCESS
    error_details: Optional[str] = ""  
    error_type: Optional[str] = None
    retry_count: int = 0
    retriable: bool = None