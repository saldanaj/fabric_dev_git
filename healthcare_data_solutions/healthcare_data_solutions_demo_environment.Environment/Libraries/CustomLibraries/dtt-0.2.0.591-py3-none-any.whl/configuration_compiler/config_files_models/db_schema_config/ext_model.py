import json
from collections import defaultdict
from copy import deepcopy
from typing import Optional

from configuration_compiler.config_files_models.db_schema.ext_model import DBSchemaModel
from configuration_compiler.config_files_models.db_schema.model import (
    Column,
    FieldProperties,
    JoinPair,
    ModelItem,
    OriginDataTypeName,
    RelationShip,
)
from configuration_compiler.config_files_models.db_schema_config.model import (
    ConfigField,
    DBConfigExtra,
    ExcludedFields,
    PartitionField,
    PrimaryKey,
    RawDBConfigModel,
)
from configuration_compiler.config_files_models.semantics.ext_model import SemanticsModel


class DBConfigModel(RawDBConfigModel):
    @classmethod
    def from_str(cls, db_schema_config: str) -> "DBConfigModel":
        try:
            db_config_model = cls(**json.loads(db_schema_config))
        except json.JSONDecodeError as e:
            raise ValueError(f"Failed to parse DB schema config: {e}") from e
        db_config_model.verify_extra_config()
        db_config_model.verify_fields_are_present_in_config()
        return db_config_model

    @staticmethod
    def _filter_required_tables(db_schema: DBSchemaModel, required_tables: dict[str, ExcludedFields]) -> DBSchemaModel:
        if not required_tables:
            return db_schema
        db_schema.tables = [t for t in db_schema.tables if t.name in required_tables]
        return db_schema

    @staticmethod
    def _remove_fields(db_schema: DBSchemaModel, required_tables: dict[str, ExcludedFields]) -> None:
        if not required_tables:
            return
        excluded_columns: Optional[ExcludedFields] = None

        def should_keep(column: Column):
            return column.name not in excluded_columns.exclude

        for table_model in db_schema.tables:
            excluded_columns = required_tables.get(table_model.name)
            if not excluded_columns:
                continue
            existing_columns: list[Column] = table_model.storageDescriptor.columns
            table_model.storageDescriptor.columns = list(filter(should_keep, existing_columns))

    @staticmethod
    def _add_fields(
        db_schema: DBSchemaModel,
        fields_to_add: list[ConfigField],
        configuration: DBConfigExtra,
        ref_tables: list[str],
    ) -> None:
        if not fields_to_add:
            return

        fields_grouped_by_table = defaultdict(list)
        for field in fields_to_add:
            if not field.enabled:
                continue
            config_field: ConfigField = deepcopy(field)
            config_field.tables = []
            relevant_tables = DBConfigModel._parse_required_tables_for_added_fields(
                configuration, db_schema, field, ref_tables
            )
            for table_name in relevant_tables:
                fields_grouped_by_table[table_name].append(config_field)
        fields_grouped_by_table = dict(fields_grouped_by_table)

        for table_model in db_schema.tables:
            existing_columns: list = table_model.storageDescriptor.columns
            for config_field in fields_grouped_by_table.get(table_model.name, []):
                new_column = Column(
                    name=config_field.name,
                    originDataTypeName=OriginDataTypeName(
                        typeName=config_field.type,
                        isNullable=True,
                        properties=FieldProperties(
                            minValue=None,
                            maxValue=None,
                            description=config_field.description,
                            dateFormat=None,
                            timestampFormat=None,
                        ),
                        length=None,
                        scale=None,
                        precision=None,
                    ),
                )
                datatype_config: OriginDataTypeName = new_column.originDataTypeName
                if config_field.length is not None:
                    datatype_config.length = config_field.length
                if config_field.scale is not None:
                    datatype_config.scale = config_field.scale
                if config_field.precision is not None:
                    datatype_config.precision = config_field.precision
                existing_columns.append(new_column)

    @staticmethod
    def _parse_required_tables_for_added_fields(
        configuration: DBConfigExtra, db_schema: DBSchemaModel, field: ConfigField, ref_tables: list[str]
    ) -> list[str]:
        field_tables = field.tables
        if field_tables == ["*"]:
            if field.name not in (
                configuration.sourceTableField,
                configuration.modifiedOnTargetField,
            ):
                raise ValueError(
                    f"Table name ('*') in the dbSchemaConfig file is only supported for config field names, e.g., ModifiedDate "
                    f"{(configuration.sourceTableField, configuration.modifiedOnTargetField)}"
                )
            # reference tables are not not altered with '*'
            all_tables_names = [t.name for t in db_schema.tables if t.name not in ref_tables]
            relevant_tables = all_tables_names
        else:
            if "*" in field_tables:
                raise ValueError(
                    f"Invalid table name ('*') in dbSchemaConfig file for config field '{field.name}': in position: {field_tables.index('*')}"
                )
            relevant_tables = field_tables
        return relevant_tables

    @staticmethod
    def _add_partitions_fields(db_schema: DBSchemaModel, partition_fields_to_add: list[PartitionField]) -> None:
        if not partition_fields_to_add:
            return

        fields_grouped_by_table = defaultdict(list)
        for partition_field in partition_fields_to_add:
            if not partition_field.enabled:
                continue
            new_partition_field: PartitionField = deepcopy(partition_field)
            new_partition_field.tables = []
            for table_name in partition_field.tables:
                fields_grouped_by_table[table_name].append(partition_field)
        fields_grouped_by_table: dict[str, list[PartitionField]] = dict(fields_grouped_by_table)

        for table_model in db_schema.tables:
            existing_columns: list = table_model.storageDescriptor.columns
            if table_model.name in fields_grouped_by_table:
                for partition_field in fields_grouped_by_table[table_model.name]:
                    new_column = Column(
                        name=partition_field.name,
                        originDataTypeName=OriginDataTypeName(
                            typeName=partition_field.type,
                            isNullable=False,
                            properties=FieldProperties(
                                minValue=None,
                                maxValue=None,
                                description=partition_field.description,
                                dateFormat=None,
                                timestampFormat=None,
                            ),
                            length=None,
                            scale=None,
                            precision=None,
                        ),
                    )
                    existing_columns.append(new_column)

    @staticmethod
    def _remove_redundant_relations(db_schema: DBSchemaModel, required_tables: Optional[dict]) -> DBSchemaModel:
        if not required_tables:
            return db_schema
        for table_model in db_schema.tables:
            filtered_relationships = []
            for r in table_model.properties.relationships:
                to_entity = r.toEntity
                if to_entity in required_tables:
                    filtered_relationships.append(r)
            table_model.properties.relationships = filtered_relationships
        return db_schema

    def verify_fields_are_present_in_config(self):
        if not self.fields:
            return
        if not self.configuration:
            return

        fields_names = [field.name for field in self.fields if field.enabled]
        for field in [
            self.configuration.modifiedOnTargetField,
            self.configuration.sourceTableField,
        ]:
            if field is not None:
                if field not in fields_names:
                    raise ValueError(f"Field '{field}' is not present in the dbSchemaConfig file")

    @staticmethod
    def _update_primary_keys(db_schema: DBSchemaModel, primary_keys: list[PrimaryKey]) -> None:
        for primary_key in primary_keys:
            try:
                table_model: ModelItem = db_schema.tables_dict[primary_key.table]
            except KeyError as ke:
                raise ValueError(f"Table '{primary_key.table}' was not found in the target schema") from ke
            old_pks = table_model.properties.primaryKeys[:]  # copy
            new_pks = table_model.properties.primaryKeys[:]  # copy
            existing_fields = [column.name for column in table_model.storageDescriptor.columns]
            for key_to_remove in primary_key.config.remove:
                if key_to_remove not in old_pks:
                    raise ValueError(
                        f"PK field '{key_to_remove}' was not found in the target table '{primary_key.table}'[0]"
                    )
                new_pks.remove(key_to_remove)
            for key_to_add in primary_key.config.add:
                if key_to_add in old_pks:
                    raise ValueError(
                        f"PK field '{key_to_add}' is already present in the PK fields collection of the target table '{primary_key.table}'[1]"
                    )
                if key_to_add not in existing_fields:
                    raise ValueError(
                        f"PK field '{key_to_add}' was not found in the PK fields collection of the target table '{primary_key.table}'[2]"
                    )
                new_pks.append(key_to_add)
            for old_key, new_key in primary_key.config.replace.items():
                if old_key not in existing_fields:
                    raise ValueError(
                        f"PK field '{old_key}' was not found in the PK fields collection of the target table '{primary_key.table}'[3]"
                    )
                if old_key not in old_pks:
                    raise ValueError(
                        f"PK field '{old_key}' was not found in the PK fields collection of the target table '{primary_key.table}'[4]"
                    )
                if new_key not in existing_fields:
                    raise ValueError(
                        f"PK field '{new_key}' was not found in the PK fields collection of the target table '{primary_key.table}'[5]"
                    )
                new_pks.remove(old_key)
                new_pks.append(new_key)
            table_model.properties.primaryKeys = new_pks
            DBConfigModel._update_primary_keys_in_relationships(db_schema, primary_key, table_model)

    @staticmethod
    def _update_primary_keys_in_relationships(
        db_schema: DBSchemaModel, primary_key: PrimaryKey, table_model: ModelItem
    ):
        # update all fks that reference this table
        for old_key, new_key in primary_key.config.replace.items():
            pointing_join_pairs: list[JoinPair] = db_schema.get_pointing_fks_on_field(table_model.name, old_key)
            for join_pair in pointing_join_pairs:
                join_pair.toAttribute = new_key
        for key_to_remove in primary_key.config.remove:
            pointing_relationships: list[RelationShip] = db_schema.get_pointing_relationships_on_field(
                table_model.name, key_to_remove
            )
            for rel in pointing_relationships:
                rel.joinPairs = list(filter(lambda jp: jp.toAttribute != key_to_remove, rel.joinPairs))

    def adapt_schema(self, db_schema: DBSchemaModel, db_semantics: SemanticsModel | None) -> DBSchemaModel:
        db_schema = DBConfigModel._filter_required_tables(db_schema, self.tables)
        db_schema = DBConfigModel._remove_redundant_relations(db_schema, self.tables)
        DBConfigModel._remove_fields(db_schema, self.tables)
        ref_tables = [t.table for t in db_semantics.referenceTables] if db_semantics else []
        DBConfigModel._add_fields(db_schema, self.fields, self.configuration, ref_tables)
        DBConfigModel._update_primary_keys(db_schema, self.primaryKeys)
        DBConfigModel._add_partitions_fields(db_schema, self.partitionFields)
        return db_schema

    def verify_extra_config(self):
        if bool(self.configuration.modifiedOnTargetField) ^ bool(self.configuration.sourceTableField):
            raise ValueError(
                "Both modifiedOnTargetField and sourceTableField must be specified, or neither of them. In the DB target schema config file"
            )

# SIG # Begin Windows Authenticode signature block
# MIIoQgYJKoZIhvcNAQcCoIIoMzCCKC8CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQse8BENmB6EqSR2hd
# JGAGggIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCD0Mr7iU36GD/W6
# mS0WrUyGMg/dx9CWNJrDtpt1L+lyg6CCDXYwggX0MIID3KADAgECAhMzAAADrzBA
# DkyjTQVBAAAAAAOvMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjMxMTE2MTkwOTAwWhcNMjQxMTE0MTkwOTAwWjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDOS8s1ra6f0YGtg0OhEaQa/t3Q+q1MEHhWJhqQVuO5amYXQpy8MDPNoJYk+FWA
# hePP5LxwcSge5aen+f5Q6WNPd6EDxGzotvVpNi5ve0H97S3F7C/axDfKxyNh21MG
# 0W8Sb0vxi/vorcLHOL9i+t2D6yvvDzLlEefUCbQV/zGCBjXGlYJcUj6RAzXyeNAN
# xSpKXAGd7Fh+ocGHPPphcD9LQTOJgG7Y7aYztHqBLJiQQ4eAgZNU4ac6+8LnEGAL
# go1ydC5BJEuJQjYKbNTy959HrKSu7LO3Ws0w8jw6pYdC1IMpdTkk2puTgY2PDNzB
# tLM4evG7FYer3WX+8t1UMYNTAgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQURxxxNPIEPGSO8kqz+bgCAQWGXsEw
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzUwMTgyNjAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAISxFt/zR2frTFPB45Yd
# mhZpB2nNJoOoi+qlgcTlnO4QwlYN1w/vYwbDy/oFJolD5r6FMJd0RGcgEM8q9TgQ
# 2OC7gQEmhweVJ7yuKJlQBH7P7Pg5RiqgV3cSonJ+OM4kFHbP3gPLiyzssSQdRuPY
# 1mIWoGg9i7Y4ZC8ST7WhpSyc0pns2XsUe1XsIjaUcGu7zd7gg97eCUiLRdVklPmp
# XobH9CEAWakRUGNICYN2AgjhRTC4j3KJfqMkU04R6Toyh4/Toswm1uoDcGr5laYn
# TfcX3u5WnJqJLhuPe8Uj9kGAOcyo0O1mNwDa+LhFEzB6CB32+wfJMumfr6degvLT
# e8x55urQLeTjimBQgS49BSUkhFN7ois3cZyNpnrMca5AZaC7pLI72vuqSsSlLalG
# OcZmPHZGYJqZ0BacN274OZ80Q8B11iNokns9Od348bMb5Z4fihxaBWebl8kWEi2O
# PvQImOAeq3nt7UWJBzJYLAGEpfasaA3ZQgIcEXdD+uwo6ymMzDY6UamFOfYqYWXk
# ntxDGu7ngD2ugKUuccYKJJRiiz+LAUcj90BVcSHRLQop9N8zoALr/1sJuwPrVAtx
# HNEgSW+AKBqIxYWM4Ev32l6agSUAezLMbq5f3d8x9qzT031jMDT+sUAoCw0M5wVt
# CUQcqINPuYjbS1WgJyZIiEkBMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGiIwghoeAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAAOvMEAOTKNNBUEAAAAAA68wDQYJYIZIAWUDBAIB
# BQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIMJamEPkb8Km+6KyG6SE6spO
# KOiHfeVUmaIGz+4TQ7SFMEIGCisGAQQBgjcCAQwxNDAyoBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEB
# BQAEggEAG+EVYyg3tNeiUWUT6uS+9ZIe/0iz2vPzbLh2dQK5bbWSFd6onqzVnqdj
# yQhhzxJX6dwEohtxmwvOU587LLAvvyLbzcs30coTz2ndQCZO4k1/Wba6b1T6SIko
# VanZuzDkG7acC4qSlieCgJCnJsEbOtEFWvDfmw8tHVUB01u6rEJ8L2BPeyNZtFXr
# toQ12nTDdiSAQhQ2wJN0aGqWT1dliUfzqcZKH8Jsih/EfOj6gFq2idnQEO7GOJ41
# W6C//qx9b0YTohTYoDDSnJeOJEA1XbnXl+mrjD6R1foEqxFXjO5tRD1chigNrtOw
# zggnD6XeKm3O21U6fkEn/IXCaDF38aGCF6wwgheoBgorBgEEAYI3AwMBMYIXmDCC
# F5QGCSqGSIb3DQEHAqCCF4UwgheBAgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFaBgsq
# hkiG9w0BCRABBKCCAUkEggFFMIIBQQIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFl
# AwQCAQUABCCTvw+gtgo1MJIRylPOEwdhQMG9z1g4jFw1O11S+ZquYwIGZr38q3GT
# GBMyMDI0MDgxNTEzMzYxMS43MDlaMASAAgH0oIHZpIHWMIHTMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQgSXJl
# bGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJzAlBgNVBAsTHm5TaGllbGQgVFNTIEVT
# TjozMjFBLTA1RTAtRDk0NzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# U2VydmljZaCCEfowggcoMIIFEKADAgECAhMzAAAB+KOhJgwMQEj+AAEAAAH4MA0G
# CSqGSIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9u
# MRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRp
# b24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4XDTI0
# MDcyNTE4MzEwOFoXDTI1MTAyMjE4MzEwOFowgdMxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9w
# ZXJhdGlvbnMgTGltaXRlZDEnMCUGA1UECxMeblNoaWVsZCBUU1MgRVNOOjMyMUEt
# MDVFMC1EOTQ3MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNl
# MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAxR23pXYnD2BuODdeXs2C
# u/T5kKI+bAw8cbtN50Cm/FArjXyL4RTqMe6laQ/CqeMTxgckvZr1JrW0Mi4F15rx
# /VveGhKBmob45DmOcV5xyx7h9Tk59NAl5PNMAWKAIWf270SWAAWxQbpVIhhPWCnV
# V3otVvahEad8pMmoSXrT5Z7Nk1RnB70A2bq9Hk8wIeC3vBuxEX2E8X50IgAHsyaR
# 9roFq3ErzUEHlS8YnSq33ui5uBcrFOcFOCZILuVFVTgEqSrX4UiX0etqi7jUtKyp
# gIflaZcV5cI5XI/eCxY8wDNmBprhYMNlYxdmQ9aLRDcTKWtddWpnJtyl5e3gHuYo
# j8xuDQ0XZNy7ESRwJIK03+rTZqfaYyM4XSK1s0aa+mO69vo/NmJ4R/f1+KucBPJ4
# yUdbqJWM3xMvBwLYycvigI/WK4kgPog0UBNczaQwDVXpcU+TMcOvWP8HBWmWJQIm
# TZInAFivXqUaBbo3wAfPNbsQpvNNGu/12pg0F8O/CdRfgPHfOhIWQ0D8ALCY+Lsi
# wbzcejbrVl4N9fn2wOg2sDa8RfNoD614I0pFjy/lq1NsBo9V4GZBikzX7ZjWCRgd
# 1FCBXGpfpDikHjQ05YOkAakdWDT2bGSaUZJGVYtepIpPTAs1gd/vUogcdiL51o7s
# huHIlB6QSUiQ24XYhRbbQCECAwEAAaOCAUkwggFFMB0GA1UdDgQWBBS9zsZzz57Q
# lT5nrt/oitLv1OQ7tjAfBgNVHSMEGDAWgBSfpxVdAF5iXYP05dJlpxtTNRnpcjBf
# BgNVHR8EWDBWMFSgUqBQhk5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3Bz
# L2NybC9NaWNyb3NvZnQlMjBUaW1lLVN0YW1wJTIwUENBJTIwMjAxMCgxKS5jcmww
# bAYIKwYBBQUHAQEEYDBeMFwGCCsGAQUFBzAChlBodHRwOi8vd3d3Lm1pY3Jvc29m
# dC5jb20vcGtpb3BzL2NlcnRzL01pY3Jvc29mdCUyMFRpbWUtU3RhbXAlMjBQQ0El
# MjAyMDEwKDEpLmNydDAMBgNVHRMBAf8EAjAAMBYGA1UdJQEB/wQMMAoGCCsGAQUF
# BwMIMA4GA1UdDwEB/wQEAwIHgDANBgkqhkiG9w0BAQsFAAOCAgEAYfk8GzzpEVnG
# l7y6oXoytCb42Hx6TOA0+dkaBI36ftDE9tLubUa/xMbHB5rcNiRhFHZ93RefdPpc
# 4+FF0DAl5lP8xKAO+293RWPKDFOFIxgtZY08t8D9cSQpgGUzyw3lETZebNLEA17A
# /CTpA2F9uh8j84KygeEbj+bidWDiEfayoH2A5/5ywJJxIuLzFVHacvWxSCKoF9hl
# SrZSG5fXWS3namf4tt690UT6AGyWLFWe895coFPxm/m0UIMjjp9VRFH7nb3Ng2Q4
# gPS9E5ZTMZ6nAlmUicDj0NXAs2wQuQrnYnbRAJ/DQW35qLo7Daw9AsItqjFhbMcG
# 68gDc4j74L2KYe/2goBHLwzSn5UDftS1HZI0ZRsqmNHI0TZvvUWX9ajm6SfLBTEt
# oTo6gLOX0UD/9rrhGjdkiCw4SwU5osClgqgiNMK5ndk2gxFlDXHCyLp5qB6BoPpc
# 82RhO0yCzoP9gv7zv2EocAWEsqE5+0Wmu5uarmfvcziLfU1SY240OZW8ld4sS8fn
# ybn/jDMmFAhazV1zH0QERWEsfLSpwkOXaImWNFJ5lmcnf1VTm6cmfasScYtElpjq
# Z9GooCmk1XFApORPs/PO43IcFmPRwagt00iQSw+rBeIH00KQq+FJT/62SB70g9g/
# R8TS6k6b/wt2UWhqrW+Q8lw6Xzgex/YwggdxMIIFWaADAgECAhMzAAAAFcXna54C
# m0mZAAAAAAAVMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZp
# Y2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0yMTA5MzAxODIyMjVaFw0zMDA5MzAxODMy
# MjVaMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNV
# BAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMIICIjANBgkqhkiG9w0B
# AQEFAAOCAg8AMIICCgKCAgEA5OGmTOe0ciELeaLL1yR5vQ7VgtP97pwHB9KpbE51
# yMo1V/YBf2xK4OK9uT4XYDP/XE/HZveVU3Fa4n5KWv64NmeFRiMMtY0Tz3cywBAY
# 6GB9alKDRLemjkZrBxTzxXb1hlDcwUTIcVxRMTegCjhuje3XD9gmU3w5YQJ6xKr9
# cmmvHaus9ja+NSZk2pg7uhp7M62AW36MEBydUv626GIl3GoPz130/o5Tz9bshVZN
# 7928jaTjkY+yOSxRnOlwaQ3KNi1wjjHINSi947SHJMPgyY9+tVSP3PoFVZhtaDua
# Rr3tpK56KTesy+uDRedGbsoy1cCGMFxPLOJiss254o2I5JasAUq7vnGpF1tnYN74
# kpEeHT39IM9zfUGaRnXNxF803RKJ1v2lIH1+/NmeRd+2ci/bfV+AutuqfjbsNkz2
# K26oElHovwUDo9Fzpk03dJQcNIIP8BDyt0cY7afomXw/TNuvXsLz1dhzPUNOwTM5
# TI4CvEJoLhDqhFFG4tG9ahhaYQFzymeiXtcodgLiMxhy16cg8ML6EgrXY28MyTZk
# i1ugpoMhXV8wdJGUlNi5UPkLiWHzNgY1GIRH29wb0f2y1BzFa/ZcUlFdEtsluq9Q
# BXpsxREdcu+N+VLEhReTwDwV2xo3xwgVGD94q0W29R6HXtqPnhZyacaue7e3Pmri
# Lq0CAwEAAaOCAd0wggHZMBIGCSsGAQQBgjcVAQQFAgMBAAEwIwYJKwYBBAGCNxUC
# BBYEFCqnUv5kxJq+gpE8RjUpzxD/LwTuMB0GA1UdDgQWBBSfpxVdAF5iXYP05dJl
# pxtTNRnpcjBcBgNVHSAEVTBTMFEGDCsGAQQBgjdMg30BATBBMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL0RvY3MvUmVwb3NpdG9y
# eS5odG0wEwYDVR0lBAwwCgYIKwYBBQUHAwgwGQYJKwYBBAGCNxQCBAweCgBTAHUA
# YgBDAEEwCwYDVR0PBAQDAgGGMA8GA1UdEwEB/wQFMAMBAf8wHwYDVR0jBBgwFoAU
# 1fZWy4/oolxiaNE9lJBb186aGMQwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDovL2Ny
# bC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljUm9vQ2VyQXV0XzIw
# MTAtMDYtMjMuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0cDov
# L3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNSb29DZXJBdXRfMjAxMC0w
# Ni0yMy5jcnQwDQYJKoZIhvcNAQELBQADggIBAJ1VffwqreEsH2cBMSRb4Z5yS/yp
# b+pcFLY+TkdkeLEGk5c9MTO1OdfCcTY/2mRsfNB1OW27DzHkwo/7bNGhlBgi7ulm
# ZzpTTd2YurYeeNg2LpypglYAA7AFvonoaeC6Ce5732pvvinLbtg/SHUB2RjebYIM
# 9W0jVOR4U3UkV7ndn/OOPcbzaN9l9qRWqveVtihVJ9AkvUCgvxm2EhIRXT0n4ECW
# OKz3+SmJw7wXsFSFQrP8DJ6LGYnn8AtqgcKBGUIZUnWKNsIdw2FzLixre24/LAl4
# FOmRsqlb30mjdAy87JGA0j3mSj5mO0+7hvoyGtmW9I/2kQH2zsZ0/fZMcm8Qq3Uw
# xTSwethQ/gpY3UA8x1RtnWN0SCyxTkctwRQEcb9k+SS+c23Kjgm9swFXSVRk2XPX
# fx5bRAGOWhmRaw2fpCjcZxkoJLo4S5pu+yFUa2pFEUep8beuyOiJXk+d0tBMdrVX
# VAmxaQFEfnyhYWxz/gq77EFmPWn9y8FBSX5+k77L+DvktxW/tM4+pTFRhLy/AsGC
# onsXHRWJjXD+57XQKBqJC4822rpM+Zv/Cuk0+CQ1ZyvgDbjmjJnW4SLq8CdCPSWU
# 5nR0W2rRnj7tfqAxM328y+l7vzhwRNGQ8cirOoo6CGJ/2XBjU02N7oJtpQUQwXEG
# ahC0HVUzWLOhcGbyoYIDVTCCAj0CAQEwggEBoYHZpIHWMIHTMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQgSXJl
# bGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJzAlBgNVBAsTHm5TaGllbGQgVFNTIEVT
# TjozMjFBLTA1RTAtRDk0NzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# U2VydmljZaIjCgEBMAcGBSsOAwIaAxUAtkQt/ebWSQ5DnG+aKRzPELCFE9GggYMw
# gYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYD
# VQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQsF
# AAIFAOpoey4wIhgPMjAyNDA4MTUxMzAzNDJaGA8yMDI0MDgxNjEzMDM0MlowczA5
# BgorBgEEAYRZCgQBMSswKTAKAgUA6mh7LgIBADAGAgEAAgEeMAcCAQACAg7aMAoC
# BQDqacyuAgEAMDYGCisGAQQBhFkKBAIxKDAmMAwGCisGAQQBhFkKAwKgCjAIAgEA
# AgMHoSChCjAIAgEAAgMBhqAwDQYJKoZIhvcNAQELBQADggEBAIG5BFQYWeUnwDLP
# bXNdS54NKTvSiBuhl4a8MedMNmFZoa8YRBdw5k/xHWy4CowhjzplavZfJkttmYES
# K00ymoNHYGGd8+8iKwDIz84bGQ4ShBBO31d2iE7E3XV1aGTD6MXijwXQS46a9mL6
# zOPCrkLkv2Uhdfxn59OF9e7i7gxQTFQj8LZXWw68pJ0V+miHHhw70ghbr4h8/4AD
# Pi/2lmdpcLBMpEdMgJh8pq+ythI0DBQDisdq+C8z/erKafuWcc3t5+9669Z+yNgC
# UW1VOWkskknXsng+Ns688KBeoxv7Mp4SFBDb2FwRQonayaKIMLIzOwVd1/Eto1Om
# 8TBVigMxggQNMIIECQIBATCBkzB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2Fz
# aGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENv
# cnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAx
# MAITMwAAAfijoSYMDEBI/gABAAAB+DANBglghkgBZQMEAgEFAKCCAUowGgYJKoZI
# hvcNAQkDMQ0GCyqGSIb3DQEJEAEEMC8GCSqGSIb3DQEJBDEiBCC/GKPjfqxIW/Kb
# uPbTiys1ajUPihuXSNiI/0dtT/ZoljCB+gYLKoZIhvcNAQkQAi8xgeowgecwgeQw
# gb0EIO/MM/JfDVSQBQVi3xtHhR2Mz3RC/nGdVqIoPcjRnPdaMIGYMIGApH4wfDEL
# MAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1v
# bmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWlj
# cm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAH4o6EmDAxASP4AAQAAAfgw
# IgQgJRT7hi9Uo9p9cjdlSED3xSk1BH+v3C7zam0lnDsHJVcwDQYJKoZIhvcNAQEL
# BQAEggIAj4z7GFPeEyIt7Z3MJzQTlVaSs6OFjIpvqTdRD35uCOFsMNKpS2puExuK
# 8uaecEEhQYAlYPRunAV5Md+HGOCOewUIXuL8XNIctHdfxNZA8UfLsOrD1BHCtqxh
# 3EmcLRD++8Dtx2Rv77/RHAjNwHgvNKb9COshiRW8XUwvrNDW0zPyHkhTf2xZelWF
# 4hJr98iGjEX5W2WhMVp3Hebcoo+kNg565WIkEH7eZsuqDEpgAkbVRHB4BRwOb6lx
# xQRvQMvX1HraEBsPdD38wKAVHHv5i4w0KnltgvUgjTbxxTzN7la3ULEGBO70ecHC
# tSbIpnN6xIb/n61uuX150Lo379JQd5tI7AHGRuDqn0nsEFi1Jj4bzdP5XlsedlXC
# pnVe2FPygmAR/cfRXMq/X8dogGuaGkOkG8SGUbvYO+GHF2MasSj7804Bi97CVjqp
# s+iuXNN+Q/KelN+f6xS5+2RoinqMLwpyJ4fu2Es3Ts3sNOAA4rD0joMNWXbF5mJ7
# EknCtbR0ZQFpUQncpYANe4Nrv3Apr3L5mp+YuOcC3ZgTpgvnjPF2KzyS538VjAv/
# SZL+irjaajfZUbDBw5IATL9RaBMMRgfx5o6adSY6BUw4Ab5+X8n4WkXjg1JaMzsy
# qeiSPmpLxiTzTQvWOTFcC+opio0v7F5eXohHgueaAzkWKdoJvLM=
# SIG # End Windows Authenticode signature block