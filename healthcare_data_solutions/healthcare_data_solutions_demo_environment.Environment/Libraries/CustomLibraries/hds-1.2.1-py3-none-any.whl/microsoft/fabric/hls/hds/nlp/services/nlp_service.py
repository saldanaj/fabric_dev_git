# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# --------------------------------------------------------------------------
from typing import Dict
from pyspark import StorageLevel
from pyspark.sql import DataFrame, functions as F
from pyspark.sql.utils import AnalysisException, ParseException
from pyspark.sql.window import Window
from azure.core.credentials import AzureKeyCredential
from azure.ai.textanalytics import TextAnalyticsClient
from azure.core.pipeline.policies import RetryPolicy
from microsoft.fabric.hls.hds.nlp.response.nlp_response_schema import NLPResponseSchema
from microsoft.fabric.hls.hds.global_constants.global_constants import GlobalConstants
from microsoft.fabric.hls.hds.nlp.constants import NLPConstants as C
from microsoft.fabric.hls.hds.global_constants.logging_constants import LoggingConstants as LC
from microsoft.fabric.hls.hds.nlp.errors.nlp_analysis_error import NLPAnalysisError
from microsoft.fabric.hls.hds.utils.data_manager_logger import DataManagerLogger
from microsoft.fabric.hls.hds.nlp.nlp_udf import ta4hbundle_udf


class NLPService:
    """
    This module contains the NLPService class, which provides functionality for
    processing text data using the Azure Text Analytics for Health API.
    """

    def __init__(
        self,
        nlp_endpoint: str,
        nlp_password: str,
        nlp_column_mappings: Dict[str, str],
        data_manager_logger: DataManagerLogger,
        **kwargs,
    ):
        """
        Initialize the NLPService instance with endpoint and password.
        :param nlp_endpoint: Text Analytics for Health API endpoint
        :param nlp_password: Text Analytics for Health API password
        :param nlp_column_mappings: Mapping of the dataframe column with the
                unstructured text to analyze
        :param retry_policy: Optional parameter to specify the retry policy to use
        :param model_version: Optional parameter to indicate which model will be
                used for scoring, e.g. "latest", "2019-10-01". Defaults to "latest"
        :param fhir_version: The FHIR Spec version that the result will use to
                format the fhir_bundle on the result object. For additional
                information see https://www.hl7.org/fhir/overview.html.The only
                acceptable values to pass in are None and "4.0.1". The default value is None.
        :param enable_text_analytics_logs: Optional parameter to enable logging. Defaults to False.
        """
        self.nlp_password: str = nlp_password
        self.nlp_endpoint: str = nlp_endpoint
        self.nlp_column_mappings = nlp_column_mappings
        self._logger = data_manager_logger
        self.model_version = kwargs.get(
            "model_version", C.DEFAULT_TEXT_ANALYTICS_MODEL_VERSION
        )
        self.fhir_version = kwargs.get(
            "fhir_version", C.DEFAULT_TEXT_ANALYTICS_FHIR_VERSION
        )
        self.enable_text_analytics_logs = kwargs.get("enable_text_analytics_logs", GlobalConstants.ENABLE_TEXT_ANALYTICS_LOGS)
        self.retry_policy = (
            kwargs.get("retry_policy") or self.__create_default_retry_policy()
        )
        self.text_analytics_client = self.__create_text_analytics_client()

    def __create_text_analytics_client(self):
        """
        Create a TextAnalyticsClient instance with endpoint, password, and retry policy.
        :return: TextAnalyticsClient instance
        """
        return TextAnalyticsClient(
            endpoint=self.nlp_endpoint,
            credential=AzureKeyCredential(self.nlp_password),
            retry_policy=self.retry_policy,
            logging_enable=self.enable_text_analytics_logs,
        )

    def __create_default_retry_policy(self) -> RetryPolicy:
        """
        Create the default retry policy.
        :return: RetryPolicy instance with default settings
        """
        return RetryPolicy(
            total_retries=C.DEFAULT_RETRY_POLICY_TOTAL_RETRIES,
            backoff_factor=C.DEFAULT_RETRY_POLICY_BACKOFF_FACTOR,
            # HTTP status codes to retry on
            retry_on_status_codes=C.DEFAULT_RETRY_POLICY_STATUS_CODES,
            retry_on_exceptions=[ConnectionError],  # Exceptions to retry on
        )

    def batch_data(self, input_df: DataFrame, batch_size: int) -> DataFrame:
        """
        Batch the input DataFrame to optimize API calls.

        :param df: input DataFrame
        :param batch_size: size of the batch
        :return: batched DataFrame
        """
        if not isinstance(input_df, DataFrame) or input_df.count() == 0:
            raise ValueError(LC.INVALID_BATCHING_INPUT_DF_ERR_MSG)

        if not isinstance(batch_size, int) or batch_size <= 0:
            raise ValueError(LC.INVALID_BATCHING_INPUT_BATCH_SIZE_ERR_MSG)

        # Ensure batch_size is not greater than DEFAULT_BATCH_SIZE. Currently, the maximum batch size is 15.
        batch_size = min(batch_size, C.DEFAULT_BATCH_SIZE)

        id_column = self.nlp_column_mappings[C.DEFAULT_NLP_COLUMNS_NAMING_ID_KEY]
        text_column = self.nlp_column_mappings[C.DEFAULT_NLP_COLUMNS_NAMING_TEXT_KEY]
        last_updated_column = self.nlp_column_mappings[
            C.DEFAULT_NLP_COLUMNS_NAMING_LAST_UPDATED_KEY
        ]

        input_df_count = input_df.count()
        # Calculate total number of batches needed
        num_batches = input_df_count // batch_size + (
            1 if input_df_count % batch_size > 0 else 0
        )

        # Add a partition column to input_df to enable partitioning for sequential ordering
        input_df = input_df.withColumn("partition_col", F.lit(1))

        # Add a row number column to input_df to enable sorting
        window_spec = Window.partitionBy("partition_col").orderBy(
            id_column, last_updated_column
        )
        input_df = input_df.withColumn("row_num", F.row_number().over(window_spec) - 1)

        # Add a batch number column to input_df based on the total number of batches needed
        input_df = input_df.withColumn("batch_num", F.col("row_num") % num_batches)

        # Group rows by batch_num and aggregate them into a single struct column
        batched_df = input_df.groupBy("batch_num").agg(
            F.collect_list(F.expr(f"struct({id_column}, {text_column})")).alias("docs")
        )

        self._logger.info(
            message=f"{LC.FINAL_BATCHED_DATAFRAME_INFO_MSG} {batched_df.count()}"
        )

        return batched_df

    def get_optimal_partitions(
        self, batched_df: DataFrame, default_parallelism: int
    ) -> int:
        """
        Evaluates the optimal number of partitions based on the batched DataFrame size and the provided default parallelism.

        :param batched_df: the batched DataFrame
        :param default_parallelism: default parellism/number of nodes available in the cluster.
        :return: the optimal number of partitions
        """
        batched_df_count = batched_df.count()

        if default_parallelism <= 0:
            # The evaluation will be sequential
            optimal_partitions = 1
        else:
            if batched_df_count <= default_parallelism:
                optimal_partitions = batched_df_count
            else:
                optimal_partitions = default_parallelism

        # Make sure that we do not exceed our default max to avoid rate limit errors
        optimal_partitions = min(optimal_partitions, C.DEFAULT_MAX_PARALLELISM)

        return optimal_partitions

    def repartition_data(
        self, input_df: DataFrame, default_parallelism: int
    ) -> DataFrame:
        """
        Repartition the input DataFrame to optimize parallelism.

        :param df: input DataFrame
        :param default_parallelism: default parallelism/number of nodes available in the cluster to use for repartitioning
        :return: repartitioned DataFrame
        """
        if not isinstance(input_df, DataFrame) or input_df.count() == 0:
            raise ValueError(LC.INVALID_REPARTITION_INPUT_DF_ERR_MSG)
        optimal_partitions = self.get_optimal_partitions(
            batched_df=input_df, default_parallelism=default_parallelism
        )

        input_df = input_df.repartition(optimal_partitions)
        self._logger.info(f"{LC.FINAL_REPARTITION_INFO_MSG} {optimal_partitions}")

        return input_df

    # pylint: disable=too-many-function-args
    def reorder_dataframe(
        self, analyzed_df: DataFrame, source_df: DataFrame
    ) -> DataFrame:
        """
        Reorder the DataFrame after the analysis to match the input schema.

        :param input_df: input DataFrame
        :return: reordered DataFrame
        """
        id_column = self.nlp_column_mappings[C.DEFAULT_NLP_COLUMNS_NAMING_ID_KEY]
        result_column = self.nlp_column_mappings[
            C.DEFAULT_NLP_COLUMNS_NAMING_RESULT_KEY
        ]
        timestamp_column = self.nlp_column_mappings[
            C.DEFAULT_NLP_COLUMNS_NAMING_LAST_UPDATED_KEY
        ]

        analyzed_df = analyzed_df.select(
            "batch_num", F.explode("results").alias(result_column)
        )
        analyzed_df = (
            analyzed_df.withColumn(id_column, F.col(f"{result_column}.{id_column}"))
            .withColumn("is_error", F.col(f"{result_column}.is_error"))
            .drop(F.col("batch_num"))
        )
        
        self._logger.info(
            message=f"{LC.ANALYZED_DATAFRAME_REORDERING_INFO_MSG} {analyzed_df.count()}"
        )
        
        # Join the source DataFrame with the analyzed DataFrame on both "id" and columns
        reordered_df = source_df.join(analyzed_df, on=[id_column], how="inner")

        reordered_df.orderBy(F.col(f"{timestamp_column}"))

        self._logger.info(
            message=f"{LC.FINAL_REORDER_ANALYZED_DATAFRAME_INFO_MSG} {reordered_df.count()}"
        )

        analyzed_df.unpersist()
        return reordered_df

    @staticmethod
    def register_udf(
        text_analytics_client: TextAnalyticsClient,
        nlp_column_mappings: Dict[str, str],
        model_version: str,
        fhir_version: str,
    ):
        """
        Register the Text Analytics for Health UDF.

        :return: UDF
        """
        response_schema = NLPResponseSchema()
        bundle_schema = response_schema.get_struct()

        return F.udf(
            lambda batched_docs: ta4hbundle_udf(
                text_analytics_client=text_analytics_client,
                nlp_column_mappings=nlp_column_mappings,
                model_version=model_version,
                fhir_version=fhir_version,
                batched_docs=batched_docs,
            ),
            bundle_schema,
        )

    def __run_analytics(self, input_df: DataFrame):
        """
        Run the Text Analytics for Health on the input DataFrame.

        :param df: input DataFrame
        :return: DataFrame with analysis results
        """
        # Register the UDF
        nlp_udf = self.register_udf(
            text_analytics_client=self.text_analytics_client,
            nlp_column_mappings=self.nlp_column_mappings,
            model_version=self.model_version,
            fhir_version=self.fhir_version,
        )

        # Bind the UDF to the input DataFrame
        input_df = (
            input_df.withColumn("results", nlp_udf(F.col("docs")))
            .persist(StorageLevel.MEMORY_AND_DISK)
        )

        self._logger.info(
            message=f"{LC.FINAL_ANALYZED_DATAFRAME_INFO_MSG} {input_df.count()}"
        )

        return input_df

    # pylint: disable=broad-exception-caught
    def analyze(
        self,
        source_df: DataFrame,
        default_parallelism: int,
        batch_size: int = C.DEFAULT_BATCH_SIZE,
    ) -> DataFrame:
        """
        Analyze the input DataFrame with the Text Analytics for Health API.

        :param source_df: input DataFrame with the unstructured text
        :param batch_size: size of the batch for API calls
        :param default_parallelism: The default parallelism or the number of nodes in our cluster
        :return: analyzed DataFrame
        """
        if not isinstance(source_df, DataFrame) or source_df.count() == 0:
            raise NLPAnalysisError(message=LC.INVALID_NLP_ANALYSIS_INPUT_DF_ERR_MSG)
        try:
            # Batch the data
            batched_df = self.batch_data(input_df=source_df, batch_size=batch_size)

            # Repartition the data
            repartitioned_df = self.repartition_data(
                input_df=batched_df, default_parallelism=default_parallelism
            )

            # Run the Text Analytics for Health API on the batched and repartitioned dataframe
            analyzed_df = self.__run_analytics(input_df=repartitioned_df)

            # Reorder/unbatch the DataFrame to match the input schema of individual text records per row
            reordered_df = self.reorder_dataframe(
                analyzed_df=analyzed_df, source_df=source_df
            )
            
            reordered_df = reordered_df.persist(StorageLevel.MEMORY_AND_DISK)
            
            return reordered_df
        except ValueError as ex:
            raise NLPAnalysisError(
                message=f"{LC.NLP_SERVICE_VALUE_ERR_MSG} {str(ex)}"
            ) from ex
        except ParseException as ex:
            raise NLPAnalysisError(
                message=f"{LC.NLP_SERVICE_PARSE_ERR_MSG} {str(ex)}"
            ) from ex
        except AnalysisException as ex:
            raise NLPAnalysisError(
                message=f"{LC.NLP_SERVICE_ANALYSIS_ERR_MSG} {str(ex)}"
            ) from ex
        except Exception as ex:
            raise NLPAnalysisError(
                message=f"{LC.NLP_SERVICE_UNEXPECTED_ERR_MSG} {str(ex)}"
            ) from ex
