# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# --------------------------------------------------------------------------
"""
Module with a class containing constants used through out the json claims data ingestion package
"""
class JSONClaimsIngestionConstants:
    """
    Constants related to JSON (Claims Data Ingestion) module.
    """
    JSON_DROP_FOLDER_TO_DELTA_TABLES_CHECKPOINT_FOLDER = "json_drop_folder_to_delta_tables"
    JSON_MAX_FILES_PER_TRIGGER = 1000
    FAILED_NUM_RETRIES = 3
    MAX_RECORDS_PER_NDJSON = 1000
    JSON_DELTA_TABLE_NAME = 'ClaimsJSON'
    RESOURCE_STRING_COLUMN = "jsonString"
    FHIR_CLAIM_ELEMENT = "Claim"
    JSON_FILE_CONFIG_NAME = 'json_schema_config.json'
    JSON_FHIRMAPPING_FILE_CONFIG_NAME ='json_fhir_mapping_config.json'
    JSON_TO_FHIR_CHECKPOINT_FOLDER = 'json_to_fhir'
    FHIR_CLAIMS_RES_NAME = 'claim'
    FHIR_NAMESPACE = 'Fabric.HDS'
    AVRO_SCHEMA_FILE_EXT = '.avsc'
    SOURCE_SYSTEM_COLUMN_NAME = "sourceSystem"
    DATA_FORMAT_COLUMN_NAME = 'dataFormat'
    FILE_PATH_COLUMN_NAME = "filePath"
    JSON_STRING_COLUMN_NAME = "jsonString"
    ERROR_MSG_COLUMN_NAME = "errorMessage"
    CREATEDDATETIME_COLUMN_NAME = "createdDatetime"
    JSON_PROCESSING_STARTED = "started for json files"
    JSON_PROCESSING_COMPLETED = "completed for json files"
    JSON_INGESTION_PROCESS_NAME = "Ingestion"
    JSON_TO_FHIR_MAPPING_FILE_NAME = "json_fhir_mapping.json"
    CLAIM_UNIQUE_IDENTIFIER = "Loop2300_CLM_ClaimInformation.PatientControlNumber_01"
    GROUP_BY_ELEMENTS = {
        'Claim': [CLAIM_UNIQUE_IDENTIFIER,SOURCE_SYSTEM_COLUMN_NAME]
    }
    FHIR_CLAIM_ELEMENT="Claim"
    CLAIMS_DELTA_TABLE_INGESTION_NOTEBOOK = "msft_claims_extract_bronze_ingestion"

    BE_EVENT_TYPE_FAILED_FILES = "Class:Process_JSON. Method: Process_JSON. Step: processing_failed_rows."
    BE_EVENT_TYPE_FAILED_FILES_NON_RETRIABLE_ERRORS = "Class:MetadataExtractionOrchestrator. Method: _process_dcm_files. Step: NON_RETRIABLE_ERRORS."    # Loop fields for nested JSON
    LOOP_PARENT_FIELD = 'Loop2300_Loop2400'
    LOOP_EXPLODED_FIELD = 'Loop2400'
    
    # Configuration file paths
    CLAIM_FILEMAPPING_CONFIG_NAME = 'json_file_mapping.json'

