# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# --------------------------------------------------------------------------
class NLPFlatteningError(Exception):
    """
    Exception raised for errors when flattening NLP results.

    This exception is raised when there is a failure during the NLP results flattening process,
    such as invalid data structure, incorrect column names, or issues encountered
    while applying the transformation.

    Attributes:
        message (str): explanation of the error
    """

    def __init__(self, message="NLP results flattening failed."):
        self.message = message
        super().__init__(self.message)