import os
from typing import List, Tuple, Dict, Optional
from microsoft.fabric.hls.hds.utils.fhir_converter_helper import FHIRConverter
from microsoft.fabric.hls.hds.utils.logging_helper import LoggingHelper
from microsoft.fabric.hls.hds.claims_data_ingestions.json.utils.constants import JSONClaimsIngestionConstants as C
from microsoft.fabric.hls.hds.global_constants.global_constants import GlobalConstants
from microsoft.fabric.hls.hds.global_constants.logging_constants import LoggingConstants as LC
from microsoft.fabric.hls.hds.utils.mssparkutils_client_base import MSSparkUtilsClientBase
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import col, from_json, to_json
from pyspark.sql.types import StructType
import json

class JSONUtils:
    def __init__(self, spark):
        """
        Initializes an instance of the JSONUtils class.

        Args:
            spark (SparkSession): The active Spark session to use for data processing.
        """
        self.spark = spark
        self._logger = LoggingHelper.get_generic_logger(
            self.spark, self.__class__.__name__, GlobalConstants.LOGGING_LEVEL
        )
        
    def get_filetypes(self,mssparkutils_client, base_source_path: str) -> List[str]:
        """
        Retrieves filetypes located three levels down from the base source path.

        Expected structure:
            base_source_path (e.g., /Files/Process/Claims/JSON/namespace)
                └── yyyy (year)
                    └── mm (month)
                        └── dd (day)
                            └── filetype

        Args:
            mssparkutils_client: The mssparkutils client.
            base_source_path (str): The base source path.

        Returns:
            List[str]: List of filetype directories.
        """
        filetypes = []

        try:
            # Navigate Year level
            for year_entry in mssparkutils_client.fs_ls(base_source_path):
                if year_entry.isDir and year_entry.name.isdigit() and len(year_entry.name) == 4:
                    year_path = os.path.join(base_source_path, year_entry.name)

                    # Navigate Month level
                    for month_entry in mssparkutils_client.fs_ls(year_path):
                        if month_entry.isDir and month_entry.name.isdigit() and len(month_entry.name) == 2:
                            month_path = os.path.join(year_path, month_entry.name)

                            # Navigate Day level
                            for day_entry in mssparkutils_client.fs_ls(month_path):
                                if day_entry.isDir and day_entry.name.isdigit() and len(day_entry.name) == 2:
                                    day_path = os.path.join(month_path, day_entry.name)

                                    # Collect filetypes
                                    for filetype_entry in mssparkutils_client.fs_ls(day_path):
                                        if filetype_entry.isDir:
                                            filetypes.append((filetype_entry.name, os.path.join(day_path, filetype_entry.name)))
        except Exception as e:
            self._logger.error(f"Error accessing path {base_source_path}: {e}")
 
        return filetypes
   
    def get_total_file_size_bytes(self,mssparkutils_client, file_paths):
        """
        Given a list of file paths, return the total size in bytes.
        """
        total_size = 0
        for file_path in file_paths:
            try:
                file_info = mssparkutils_client.fs_ls(file_path)
                if file_info and hasattr(file_info[0], 'size'):
                    total_size += file_info[0].size
            except Exception as e:
                self._logger.warning(f"Could not get size for {file_path}: {e}")
        return total_size

    @staticmethod
    def get_namespaces(mssparkutils_client: MSSparkUtilsClientBase, base_source_path: str, namespace: str = None) -> List[str]:
        """
        This method is used to get all the namespaces/source systems for which ingestion need to run
        If a namespace is explicitly passed then return that otherwise 
        all first level folder names under base_source_path

        Args:
            mssparkutils_client (MSSparkUtilsClientBase): mssparkutils client
            base_source_path (str): base source path
            namespace(str): the namespace explicitly passed to run ingestion on

        Returns:
            List[str]: list of namespaces/source systems
        """
        if namespace:
            return [namespace]
        
        namespaces = []
        for entry in mssparkutils_client.fs_ls(base_source_path):
            if entry.isDir:
                namespaces.append(entry.name)     
        return namespaces
    
    def extract_json(self, df: DataFrame) -> Tuple[DataFrame, List[tuple]]:
        """
        Extracts JSON strings and associated metadata columns from the given DataFrame.
        Returns the DataFrame with selected columns and a list of parsed JSON tuples.

        Args:
            df (DataFrame): The input DataFrame containing the data.

        Returns:
            Tuple[DataFrame, List[tuple]]: A tuple containing the DataFrame with selected columns and a list of parsed JSON tuples.
        """
        self._logger.info(LC.PROCESSING_JSON_CONTENT.format(df.count()))
        
        try:
            df_selected = df.select(
                C.RESOURCE_STRING_COLUMN,
                C.SOURCE_SYSTEM_COLUMN_NAME,
                C.DATA_FORMAT_COLUMN_NAME,
                C.CREATEDDATETIME_COLUMN_NAME
            )
            
            
            resource_jsons = df_selected.rdd.map(
                lambda row: (
                    json.loads(row[C.RESOURCE_STRING_COLUMN]),
                    row[C.SOURCE_SYSTEM_COLUMN_NAME],
                    row[C.DATA_FORMAT_COLUMN_NAME],
                    row[C.CREATEDDATETIME_COLUMN_NAME]
                )
            ).collect()
            
            return df_selected, resource_jsons
            
        except Exception as e:
            self._logger.error(LC.JSON_ERROR_PARSING_DATA_MSG.format(error_msg=str(e)))
            raise

    def convert_and_process_json(
        self,
        df: DataFrame,
        mapping_config: dict,
        spark_schema: StructType,
        fhir_convertor: FHIRConverter,
        max_records_per_ndjson: int,
        fhir_namespace: str,
        output_path: str,
        mssparkutils_client: MSSparkUtilsClientBase,
        df_groupby_and_agg_func=None
    ) -> DataFrame:
        """
        Parses JSON, flattens, aggregates, splits to NDJSON, and writes files.

        Args:
            df (DataFrame): The input DataFrame containing the data.
            mapping_config (dict): The mapping configuration for the conversion.
            spark_schema (StructType): The Spark schema for the data.
            fhir_convertor (FHIRConverter): The FHIR converter instance.
            max_records_per_ndjson (int): The maximum number of records per NDJSON file.
            fhir_namespace (str): The FHIR namespace for the output.
            output_path (str): The output path for the NDJSON files.
            mssparkutils_client (MSSparkUtilsClientBase): The MSSparkUtils client.
            df_groupby_and_agg_func (callable, optional): Custom function for grouping and aggregation.
                If None, uses fhir_convertor._df_groupby_and_agg method.

        Returns:
            DataFrame: The DataFrame containing the aggregated FHIR data.
        """
        self._logger.info(f"Starting JSON conversion process for namespace: {fhir_namespace}")
        
        # Ensure df is not empty
        if df is None or df.rdd.isEmpty():
            raise ValueError(LC.JSON_TO_FHIR_NO_DATA_AVAILABLE_ERR_MSG)

        # Infer schema from all JSON strings
        json_rdd = df.select(C.JSON_STRING_COLUMN_NAME).rdd.map(lambda r: r[C.JSON_STRING_COLUMN_NAME])
        if json_rdd.isEmpty():
            raise ValueError(LC.JSON_TO_FHIR_NO_JSON_DATA_ERR_MSG)
        
        inferred_schema = self.spark.read.json(json_rdd).schema

        parsed_df = df.withColumn(
            "data",
            from_json(col(C.JSON_STRING_COLUMN_NAME), inferred_schema)
        )
        flattened_df = parsed_df.select(
            "data.*",
            col(C.SOURCE_SYSTEM_COLUMN_NAME),
            C.DATA_FORMAT_COLUMN_NAME,
            C.CREATEDDATETIME_COLUMN_NAME
        )
        self._logger.info("JSON parsing and flattening completed")
        
        # Use the provided groupby and aggregation function or fallback to fhir_convertor's method
        if df_groupby_and_agg_func:
            aggregated_df = df_groupby_and_agg_func(flattened_df, C.FHIR_CLAIM_ELEMENT)
        else:
            aggregated_df = fhir_convertor._df_groupby_and_agg(flattened_df, C.FHIR_CLAIM_ELEMENT)
        claims_data = aggregated_df.withColumn(
            C.FHIR_CLAIM_ELEMENT,
            to_json(col(C.FHIR_CLAIM_ELEMENT))
        ).select(C.FHIR_CLAIM_ELEMENT)        
        explanationofbenefit_list = [
            json.dumps(
                FHIRConverter.cleanup_json(
                    json.loads(row[C.FHIR_CLAIM_ELEMENT]),
                    mapping_config
                )
            ) for row in claims_data.collect()
        ]
        data_split = fhir_convertor._split_ndjson_data(max_records_per_ndjson, explanationofbenefit_list)
        fhir_convertor._save_ndjson_files(fhir_namespace, output_path, mssparkutils_client, data_split)
        
        return aggregated_df
        
    # Methods for claim type configuration management
    
    def load_claim_file_mapping_config(self, config_file_path):
        """
        Load claim file mapping configuration from the given path.
        """
        try:
            # Try to read the config file
            file_content = self.spark.sparkContext.wholeTextFiles(config_file_path).collect()
            
            # Return None if no files are found
            if not file_content:
                return None
                
            # Parse the config file
            config_data = json.loads(file_content[0][1])
            
            return config_data
        except Exception as e:
            self._logger.error(f"Error loading claim file mapping config: {str(e)}")
            return None
    def get_claim_type_config(self, file_type: str, claims_json_schema: Dict) -> Optional[Dict]:
        """
        Find matching claim type configuration for the given file type.
        
        Args:
            file_type (str): The file type/folder name to find config for.
            claims_json_schema (Dict): The loaded claim types configuration.
            
        Returns:
            Optional[Dict]: Matching claim type configuration or None if not found.
        """
        if not claims_json_schema:
            return None
        
        # First try direct matching by name
        for claim_type in claims_json_schema.get("claimTypes", []):
            name = claim_type.get("name", "")
            if file_type and name and (file_type == name or file_type.startswith(name)):
                self._logger.info(f"Found matching claim type '{name}' for file type: {file_type} based on name")
                return claim_type
        
        # Then try matching by structure config name
        for claim_type in claims_json_schema.get("claimTypes", []):
            structure_config = claim_type.get("structureConfig", "")
            if structure_config and file_type:
                config_base_name = os.path.splitext(structure_config)[0]
                if config_base_name in file_type:
                    self._logger.info(f"Found matching claim type '{claim_type.get('name')}' for file type: {file_type} based on structureConfig")
                    return claim_type
        
        # Finally try matching by folder
        for claim_type in claims_json_schema.get("claimTypes", []):
            folder = claim_type.get("folder", "")
            if file_type and folder and (file_type == folder or file_type.startswith(folder) or folder in file_type):
                self._logger.info(f"Found matching claim type '{claim_type.get('name')}' for file type: {file_type} based on folder")
                return claim_type
                
        self._logger.info(f"No matching claim type found for file type: {file_type}")
        return None
    
    def load_claim_type_structure_config(self, rootpath: str, claim_type_config: Dict) -> Dict:
        """
        Load structure configuration for a specific claim type.
        
        Args:
            rootpath (str): Root path to config directory
            claim_type_config (Dict): The claim type configuration.
            
        Returns:
            Dict: Structure configuration for the claim type or empty dict if not found.
        """
        structure_config_path = claim_type_config.get("structureConfig")
        if not structure_config_path:
            self._logger.warning(f"No structure config path defined for claim type: {claim_type_config.get('name')}")
            return {}
            
        # If path is relative, join with config directory
        if not os.path.isabs(structure_config_path):
            structure_config_path = os.path.join(rootpath, structure_config_path)
            
        try:
            self._logger.info(f"Loading structure config from: {structure_config_path}")
            files = self.spark.sparkContext.wholeTextFiles(structure_config_path).collect()
            if files and len(files) > 0:
                config = json.loads(files[0][1])
                return config.get("config", {})
        except Exception as e:
            self._logger.warning(f"Failed to load structure config for claim type {claim_type_config.get('name')}: {str(e)}")
        return {}
    
    def load_claim_type_mapping_config(self, rootpath: str, claim_type_config: Dict) -> Dict:
        """
        Load FHIR mapping configuration for a specific claim type.
        
        Args:
            rootpath (str): Root path to config directory
            claim_type_config (Dict): The claim type configuration.
            
        Returns:
            Dict: Mapping configuration for the claim type or empty dict if not found.
        """
        mapping_config_path = claim_type_config.get("mappingConfig")
        if not mapping_config_path:
            self._logger.warning(f"No mapping config path defined for claim type: {claim_type_config.get('name')}")
            return {}
            
        # If path is relative, join with config directory
        if not os.path.isabs(mapping_config_path):
            mapping_config_path = os.path.join(rootpath, mapping_config_path)
            
        try:
            self._logger.info(f"Loading mapping config from: {mapping_config_path}")
            files = self.spark.sparkContext.wholeTextFiles(mapping_config_path).collect()
            if files and len(files) > 0:
                return json.loads(files[0][1])
        except Exception as e:
            self._logger.warning(f"Failed to load mapping config for claim type {claim_type_config.get('name')}: {str(e)}")
            
        return {}

