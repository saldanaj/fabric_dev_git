import traceback
from typing import List

from common.model.base_source_configuration import BaseSourceConfiguration
from pyspark.sql import SparkSession

import rmt.core.logger as logger
from rmt.app.authoring_files_generator import AuthoringFilesGenerator
from rmt.app.reference_tables_creator import ReferenceTablesCreator
from rmt.app.reference_values_mapper import ReferenceValuesMapper
from rmt.app.repository_updater import RepositoryUpdater
from rmt.contract.configuration.internal.rmt_spec_reader import RMTSpecReader
from rmt.core.core_exceptions import UpdateError
from rmt.file_model.data_export.authoring_data_file_writer import AuthoringDataFileWriter
from rmt.file_model.data_export.authoring_mapping_file_writer import AuthoringMappingFileWriter
from rmt.file_model.data_management.authoring_data_file_reader import AuthoringDataFileReader
from rmt.file_model.data_management.authoring_mapping_file_reader import AuthoringMappingFileReader
from rmt.file_model.data_management.contributors_json_reader import ContributorsFileReader
from rmt.file_model.data_management.data_management_context import DataManagementContext
from rmt.file_model.data_management.repository_folder import RepositoryFolder
from rmt.file_model.data_management.repository_folder_table_data_reader import RepositoryFolderTableDataReader
from rmt.file_model.data_management.repository_folder_table_data_writer import RepositoryFolderTableDataWriter
from rmt.file_model.data_management.repository_folder_table_mapping_reader import RepositoryFolderTableMappingReader
from rmt.file_model.data_management.repository_folder_table_mapping_writer import RepositoryFolderTableMappingWriter
from rmt.file_model.tables_creating.reference_tables_data_file_reader import ReferenceTablesDataFileReader
from rmt.file_model.values_mapping.mapping_definitions_file_reader import MappingDefinitionsFileReader
from rmt.filesystem.file_system_client import FileSystemClient
from rmt.runners.paths_parameters_handler import PathsParametersHandler
from rmt.source_processor.source_processor import SourceProcessor

REFERENCE_MAPPING_PATH = "REFERENCE_MAPPING"


class Runner:
    def __init__(
        self,
        spark: SparkSession,
        file_system_client: FileSystemClient,
        rmt_spec_path: str,
    ) -> None:
        self._spark = spark
        self._file_system_client = file_system_client
        logger.info("RMT execution started")
        logger.info(f"RMT Spec file: {rmt_spec_path}")
        self._rmt_spec = RMTSpecReader.read(rmt_spec_path, file_system_client)
        self._paths_parameters_handler = PathsParametersHandler(file_system_client, self._rmt_spec.source_domain)

    def create_reference_values_mapping(self,
                                        ordered_mapping_definitions_folders: List[str] = None,
                                        number_of_partition_files: int = -1,
                                        staging_reference_data_folder_path=None):

        try:
            logger.info(
                f"Running RMT to map values using mapping definitions.Input parameters:"
                f"ordered_mapping_definitions_folders: {ordered_mapping_definitions_folders}, "
                f"number_of_partition_files: {number_of_partition_files}"
                f"staging_reference_data_folder_path: {staging_reference_data_folder_path}"
            )

            mapping_folder_paths = self._paths_parameters_handler.get_mapping_folder_paths(ordered_mapping_definitions_folders, staging_reference_data_folder_path)

            logger.info(f"Mapping from the following folders: {mapping_folder_paths}")
            mapping_definitions_reader = MappingDefinitionsFileReader(
                self._file_system_client,
                mapping_folder_paths,
                self._rmt_spec.reference_tables,
            )
            ReferenceValuesMapper.create_reference_values_mapping(
                self._spark,
                self._rmt_spec.source_domain,
                mapping_definitions_reader,
                self._file_system_client.join_paths(
                    self._rmt_spec.secondary_lake_location, REFERENCE_MAPPING_PATH
                ),
                number_of_partition_files,
            )

            logger.info("RMT execution ended")

        except Exception as e:
            logger.error(f"RMT ends with error.{e}")
            logger.error(traceback.format_exc())
            raise

    def create_reference_data_tables(self,
                                     target_path: str,
                                     reference_tables_folders_paths: list[str] = None,
                                     staging_reference_data_folder_path=None):

        try:
            logger.info(
                f"Running RMT to create tables from data folders.Input parameters:"
                f"reference_tables_folders_paths: {reference_tables_folders_paths}, "
                f"staging_reference_data_folder_path: {staging_reference_data_folder_path}"
            )
            data_folder_paths = self._paths_parameters_handler.get_data_folder_paths(reference_tables_folders_paths, staging_reference_data_folder_path)

            logger.info(f"Creating reference tables from the following data folders {data_folder_paths}")
            file_reader = ReferenceTablesDataFileReader(
                self._file_system_client, data_folder_paths, set(self._rmt_spec.reference_tables.keys())
            )
            ReferenceTablesCreator.create_reference_data_tables(
                self._spark, target_path, self._rmt_spec.reference_tables, file_reader
            )

            logger.info("RMT execution ended")

        except Exception as e:
            logger.error(f"RMT ended with error.{e}")
            logger.error(traceback.format_exc())
            raise

    def update_staging_reference_data(self, authoring_folder_path,
                                      staging_reference_data_folder_path: str):
        try:
            logger.info(
                f"Running RMT to update staging folder.Input Parameters:"
                f"authoring_folder_path: {authoring_folder_path}, "
                f"staging_reference_data_folder_path: {staging_reference_data_folder_path}"
            )

            self._paths_parameters_handler.raise_error_if_folder_not_exist(staging_reference_data_folder_path)
            self._paths_parameters_handler.raise_error_if_folder_not_exist(authoring_folder_path)

            authoring_repository_folder = RepositoryFolder(self._file_system_client,
                                                           self._rmt_spec.source_domain,
                                                           authoring_folder_path)

            authoring_data_management_context = DataManagementContext(self._file_system_client,
                                                                      authoring_folder_path,
                                                                      authoring_repository_folder,
                                                                      self._rmt_spec.reference_tables)

            staging_repository_folder = RepositoryFolder(self._file_system_client,
                                                         self._rmt_spec.source_domain,
                                                         staging_reference_data_folder_path)

            staging_data_management_context = DataManagementContext(self._file_system_client,
                                                                    authoring_folder_path,
                                                                    staging_repository_folder,
                                                                    self._rmt_spec.reference_tables)

            authoring_data_reader = AuthoringDataFileReader(authoring_data_management_context)
            authoring_mapping_reader = AuthoringMappingFileReader(authoring_data_management_context)
            repository_contributors_reader = ContributorsFileReader(staging_data_management_context)
            repository_folder_table_mapping_reader = RepositoryFolderTableMappingReader(staging_data_management_context)
            repository_folder_table_data_reader = RepositoryFolderTableDataReader(staging_data_management_context)
            repository_folder_table_mapping_writer = RepositoryFolderTableMappingWriter(staging_data_management_context)
            repository_folder_table_data_writer = RepositoryFolderTableDataWriter(staging_data_management_context)

            RepositoryUpdater.update_repository_folder_reference_data(authoring_data_reader,
                                                                      authoring_mapping_reader,
                                                                      repository_contributors_reader,
                                                                      repository_folder_table_mapping_reader,
                                                                      repository_folder_table_data_reader,
                                                                      repository_folder_table_mapping_writer,
                                                                      repository_folder_table_data_writer)
            logger.info("RMT execution ended")

        except UpdateError as ue:
            logger.error(f"RMT ends with error.{ue}")
            raise
        except Exception as e:
            logger.error(f"RMT ended with error.{e}")
            logger.error(traceback.format_exc())
            raise

    def generate_reference_data_authoring_files(self, target_authoring_folder_path: str, staging_reference_data_folder_path: str):

        try:

            logger.info(
                f"Running RMT to generate authoring files.Input Parameters:"
                f"target_authoring_folder_path: {target_authoring_folder_path}, "
                f"staging_reference_data_folder_path: {staging_reference_data_folder_path}"
            )

            self._paths_parameters_handler.raise_error_if_folder_not_exist(staging_reference_data_folder_path)
            repository_folder = RepositoryFolder(self._file_system_client, self._rmt_spec.source_domain, staging_reference_data_folder_path)
            data_management_context = DataManagementContext(self._file_system_client, target_authoring_folder_path, repository_folder, self._rmt_spec.reference_tables)

            source_processors = self._create_source_processors(list(self._rmt_spec.source_configurations))

            repository_folder_data_reader = RepositoryFolderTableDataReader(data_management_context)
            repository_folder_mapping_reader = RepositoryFolderTableMappingReader(data_management_context)

            authoring_data_writer = AuthoringDataFileWriter(self._spark, data_management_context)
            authoring_mapping_writer = AuthoringMappingFileWriter(self._spark, data_management_context)

            repository_contributors_reader = ContributorsFileReader(data_management_context)

            mapping_definitions_file_reader = MappingDefinitionsFileReader(self._file_system_client,
                                                                           [str(value) for value in repository_folder.get_mapping_folder_paths().values()],
                                                                           self._rmt_spec.reference_tables)

            AuthoringFilesGenerator.generate_reference_data_authoring_files(self._spark,
                                                                            self._rmt_spec.source_domain,
                                                                            source_processors,
                                                                            mapping_definitions_file_reader,
                                                                            repository_contributors_reader,
                                                                            repository_folder_mapping_reader,
                                                                            repository_folder_data_reader,
                                                                            authoring_data_writer,
                                                                            authoring_mapping_writer)
        except Exception as e:
            logger.error(f"RMT ended with error.{e}")
            logger.error(traceback.format_exc())
            raise

    def _create_source_processors(self, source_configs: list[BaseSourceConfiguration]) -> List[SourceProcessor]:

        if not source_configs:
            raise ValueError("No source configs found")

        processors = []
        for source_config in source_configs:
            processor = SourceProcessor(self._spark, source_config)
            try:
                processor.validate()
                processors.append(processor)
            except Exception as e:
                logger.error(f"Validation failed for source configuration {source_config.source_name} with error: {e}")
                raise EnvironmentError(f"Validation failed for source configuration {source_config.source_name} "
                                       f"with error {e}") from e

        return processors

# SIG # Begin Windows Authenticode signature block
# MIIoQgYJKoZIhvcNAQcCoIIoMzCCKC8CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQse8BENmB6EqSR2hd
# JGAGggIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCArYoHciXYatfYu
# kthQdSTRqG64onVtc/z47fngQBPCUqCCDXYwggX0MIID3KADAgECAhMzAAADrzBA
# DkyjTQVBAAAAAAOvMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjMxMTE2MTkwOTAwWhcNMjQxMTE0MTkwOTAwWjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDOS8s1ra6f0YGtg0OhEaQa/t3Q+q1MEHhWJhqQVuO5amYXQpy8MDPNoJYk+FWA
# hePP5LxwcSge5aen+f5Q6WNPd6EDxGzotvVpNi5ve0H97S3F7C/axDfKxyNh21MG
# 0W8Sb0vxi/vorcLHOL9i+t2D6yvvDzLlEefUCbQV/zGCBjXGlYJcUj6RAzXyeNAN
# xSpKXAGd7Fh+ocGHPPphcD9LQTOJgG7Y7aYztHqBLJiQQ4eAgZNU4ac6+8LnEGAL
# go1ydC5BJEuJQjYKbNTy959HrKSu7LO3Ws0w8jw6pYdC1IMpdTkk2puTgY2PDNzB
# tLM4evG7FYer3WX+8t1UMYNTAgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQURxxxNPIEPGSO8kqz+bgCAQWGXsEw
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzUwMTgyNjAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAISxFt/zR2frTFPB45Yd
# mhZpB2nNJoOoi+qlgcTlnO4QwlYN1w/vYwbDy/oFJolD5r6FMJd0RGcgEM8q9TgQ
# 2OC7gQEmhweVJ7yuKJlQBH7P7Pg5RiqgV3cSonJ+OM4kFHbP3gPLiyzssSQdRuPY
# 1mIWoGg9i7Y4ZC8ST7WhpSyc0pns2XsUe1XsIjaUcGu7zd7gg97eCUiLRdVklPmp
# XobH9CEAWakRUGNICYN2AgjhRTC4j3KJfqMkU04R6Toyh4/Toswm1uoDcGr5laYn
# TfcX3u5WnJqJLhuPe8Uj9kGAOcyo0O1mNwDa+LhFEzB6CB32+wfJMumfr6degvLT
# e8x55urQLeTjimBQgS49BSUkhFN7ois3cZyNpnrMca5AZaC7pLI72vuqSsSlLalG
# OcZmPHZGYJqZ0BacN274OZ80Q8B11iNokns9Od348bMb5Z4fihxaBWebl8kWEi2O
# PvQImOAeq3nt7UWJBzJYLAGEpfasaA3ZQgIcEXdD+uwo6ymMzDY6UamFOfYqYWXk
# ntxDGu7ngD2ugKUuccYKJJRiiz+LAUcj90BVcSHRLQop9N8zoALr/1sJuwPrVAtx
# HNEgSW+AKBqIxYWM4Ev32l6agSUAezLMbq5f3d8x9qzT031jMDT+sUAoCw0M5wVt
# CUQcqINPuYjbS1WgJyZIiEkBMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGiIwghoeAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAAOvMEAOTKNNBUEAAAAAA68wDQYJYIZIAWUDBAIB
# BQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIChCbpAVkrIHH8Rk2g3IGAMA
# tk7RqE6xTtQ0OP24RvuLMEIGCisGAQQBgjcCAQwxNDAyoBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEB
# BQAEggEAfp7tUmAzxTlpaw/ZlrqxvGo1MmM4iWXrT3CyZBFt/0oT6/uHhbPHiSiY
# dRVIpLR3F0EsDalMMR5D2rVezJM3ki72n+ZoE+4ap9BBGUNve2nKBje4DbJxNI7U
# NyQ+NZUwL84SLG+9wR0CmCelmwnMwxYBF0drhmCxJBq+Qxk9JDJ3TbtAfpDRKALD
# kvgAWZX1TCLW7b4lbJDNorV1ky3xHPn5cYciD/Dp5tnmntE9o9yIflmB8CQdAV3J
# OWZU0Uf6BYki1YjBsiy8OhbNOXEUOFk5PhU3fyqCJTqf9HimfLfMRXml3QST3hl7
# du0/4dhqA9SXHujqkv89FkjGh0eHZ6GCF6wwgheoBgorBgEEAYI3AwMBMYIXmDCC
# F5QGCSqGSIb3DQEHAqCCF4UwgheBAgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFaBgsq
# hkiG9w0BCRABBKCCAUkEggFFMIIBQQIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFl
# AwQCAQUABCAN4AQll9rfDWcms8pMMZnvO9BFw1pwBMT6QXnlNQdNNAIGZr3/EFEN
# GBMyMDI0MDgxNTEzMzYxNS4zNThaMASAAgH0oIHZpIHWMIHTMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQgSXJl
# bGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJzAlBgNVBAsTHm5TaGllbGQgVFNTIEVT
# Tjo0MDFBLTA1RTAtRDk0NzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# U2VydmljZaCCEfowggcoMIIFEKADAgECAhMzAAAB/tCowns0IQsBAAEAAAH+MA0G
# CSqGSIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9u
# MRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRp
# b24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4XDTI0
# MDcyNTE4MzExOFoXDTI1MTAyMjE4MzExOFowgdMxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9w
# ZXJhdGlvbnMgTGltaXRlZDEnMCUGA1UECxMeblNoaWVsZCBUU1MgRVNOOjQwMUEt
# MDVFMC1EOTQ3MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNl
# MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAvLwhFxWlqA43olsE4PCe
# gZ4mSfsH2YTSKEYv8Gn3362Bmaycdf5T3tQxpP3NWm62YHUieIQXw+0u4qlay4AN
# 3IonI+47Npi9fo52xdAXMX0pGrc0eqW8RWN3bfzXPKv07O18i2HjDyLuywYyKA9F
# mWbePjahf9Mwd8QgygkPtwDrVQGLyOkyM3VTiHKqhGu9BCGVRdHW9lmPMrrUlPWi
# YV9LVCB5VYd+AEUtdfqAdqlzVxA53EgxSqhp6JbfEKnTdcfP6T8Mir0HrwTTtV2h
# 2yDBtjXbQIaqycKOb633GfRkn216LODBg37P/xwhodXT81ZC2aHN7exEDmmbiWss
# jGvFJkli2g6dt01eShOiGmhbonr0qXXcBeqNb6QoF8jX/uDVtY9pvL4j8aEWS49h
# KUH0mzsCucIrwUS+x8MuT0uf7VXCFNFbiCUNRTofxJ3B454eGJhL0fwUTRbgyCbp
# LgKMKDiCRub65DhaeDvUAAJT93KSCoeFCoklPavbgQyahGZDL/vWAVjX5b8Jzhly
# 9gGCdK/qi6i+cxZ0S8x6B2yjPbZfdBVfH/NBp/1Ln7xbeOETAOn7OT9D3UGt0q+K
# iWgY42HnLjyhl1bAu5HfgryAO3DCaIdV2tjvkJay2qOnF7Dgj8a60KQT9QgfJfwX
# nr3ZKibYMjaUbCNIDnxz2ykCAwEAAaOCAUkwggFFMB0GA1UdDgQWBBRvznuJ9SU2
# g5l/5/b+5CBibbHF3TAfBgNVHSMEGDAWgBSfpxVdAF5iXYP05dJlpxtTNRnpcjBf
# BgNVHR8EWDBWMFSgUqBQhk5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3Bz
# L2NybC9NaWNyb3NvZnQlMjBUaW1lLVN0YW1wJTIwUENBJTIwMjAxMCgxKS5jcmww
# bAYIKwYBBQUHAQEEYDBeMFwGCCsGAQUFBzAChlBodHRwOi8vd3d3Lm1pY3Jvc29m
# dC5jb20vcGtpb3BzL2NlcnRzL01pY3Jvc29mdCUyMFRpbWUtU3RhbXAlMjBQQ0El
# MjAyMDEwKDEpLmNydDAMBgNVHRMBAf8EAjAAMBYGA1UdJQEB/wQMMAoGCCsGAQUF
# BwMIMA4GA1UdDwEB/wQEAwIHgDANBgkqhkiG9w0BAQsFAAOCAgEAiT4NUvO2lw+0
# dDMtsBuxmX2o3lVQqnQkuITAGIGCgI+sl7ZqZOTDd8LqxsH4GWCPTztc3tr8AgBv
# sYIzWjFwioCjCQODq1oBMWNzEsKzckHxAzYo5Sze7OPkMA3DAxVq4SSR8y+TRC2G
# cOd0JReZ1lPlhlPl9XI+z8OgtOPmQnLLiP9qzpTHwFze+sbqSn8cekduMZdLyHJk
# 3Niw3AnglU/WTzGsQAdch9SVV4LHifUnmwTf0i07iKtTlNkq3bx1iyWg7N7jGZAB
# RWT2mX+YAVHlK27t9n+WtYbn6cOJNX6LsH8xPVBRYAIRVkWsMyEAdoP9dqfaZzwX
# GmjuVQ931NhzHjjG+Efw118DXjk3Vq3qUI1re34zMMTRzZZEw82FupF3viXNR3DV
# OlS9JH4x5emfINa1uuSac6F4CeJCD1GakfS7D5ayNsaZ2e+sBUh62KVTlhEsQRHZ
# RwCTxbix1Y4iJw+PDNLc0Hf19qX2XiX0u2SM9CWTTjsz9SvCjIKSxCZFCNv/zpKI
# lsHx7hQNQHSMbKh0/wwn86uiIALEjazUszE0+X6rcObDfU4h/O/0vmbF3BMR+45r
# AZMAETJsRDPxHJCo/5XGhWdg/LoJ5XWBrODL44YNrN7FRnHEAAr06sflqZ8eeV3F
# uDKdP5h19WUnGWwO1H/ZjUzOoVGiV3gwggdxMIIFWaADAgECAhMzAAAAFcXna54C
# m0mZAAAAAAAVMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZp
# Y2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0yMTA5MzAxODIyMjVaFw0zMDA5MzAxODMy
# MjVaMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNV
# BAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMIICIjANBgkqhkiG9w0B
# AQEFAAOCAg8AMIICCgKCAgEA5OGmTOe0ciELeaLL1yR5vQ7VgtP97pwHB9KpbE51
# yMo1V/YBf2xK4OK9uT4XYDP/XE/HZveVU3Fa4n5KWv64NmeFRiMMtY0Tz3cywBAY
# 6GB9alKDRLemjkZrBxTzxXb1hlDcwUTIcVxRMTegCjhuje3XD9gmU3w5YQJ6xKr9
# cmmvHaus9ja+NSZk2pg7uhp7M62AW36MEBydUv626GIl3GoPz130/o5Tz9bshVZN
# 7928jaTjkY+yOSxRnOlwaQ3KNi1wjjHINSi947SHJMPgyY9+tVSP3PoFVZhtaDua
# Rr3tpK56KTesy+uDRedGbsoy1cCGMFxPLOJiss254o2I5JasAUq7vnGpF1tnYN74
# kpEeHT39IM9zfUGaRnXNxF803RKJ1v2lIH1+/NmeRd+2ci/bfV+AutuqfjbsNkz2
# K26oElHovwUDo9Fzpk03dJQcNIIP8BDyt0cY7afomXw/TNuvXsLz1dhzPUNOwTM5
# TI4CvEJoLhDqhFFG4tG9ahhaYQFzymeiXtcodgLiMxhy16cg8ML6EgrXY28MyTZk
# i1ugpoMhXV8wdJGUlNi5UPkLiWHzNgY1GIRH29wb0f2y1BzFa/ZcUlFdEtsluq9Q
# BXpsxREdcu+N+VLEhReTwDwV2xo3xwgVGD94q0W29R6HXtqPnhZyacaue7e3Pmri
# Lq0CAwEAAaOCAd0wggHZMBIGCSsGAQQBgjcVAQQFAgMBAAEwIwYJKwYBBAGCNxUC
# BBYEFCqnUv5kxJq+gpE8RjUpzxD/LwTuMB0GA1UdDgQWBBSfpxVdAF5iXYP05dJl
# pxtTNRnpcjBcBgNVHSAEVTBTMFEGDCsGAQQBgjdMg30BATBBMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL0RvY3MvUmVwb3NpdG9y
# eS5odG0wEwYDVR0lBAwwCgYIKwYBBQUHAwgwGQYJKwYBBAGCNxQCBAweCgBTAHUA
# YgBDAEEwCwYDVR0PBAQDAgGGMA8GA1UdEwEB/wQFMAMBAf8wHwYDVR0jBBgwFoAU
# 1fZWy4/oolxiaNE9lJBb186aGMQwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDovL2Ny
# bC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljUm9vQ2VyQXV0XzIw
# MTAtMDYtMjMuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0cDov
# L3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNSb29DZXJBdXRfMjAxMC0w
# Ni0yMy5jcnQwDQYJKoZIhvcNAQELBQADggIBAJ1VffwqreEsH2cBMSRb4Z5yS/yp
# b+pcFLY+TkdkeLEGk5c9MTO1OdfCcTY/2mRsfNB1OW27DzHkwo/7bNGhlBgi7ulm
# ZzpTTd2YurYeeNg2LpypglYAA7AFvonoaeC6Ce5732pvvinLbtg/SHUB2RjebYIM
# 9W0jVOR4U3UkV7ndn/OOPcbzaN9l9qRWqveVtihVJ9AkvUCgvxm2EhIRXT0n4ECW
# OKz3+SmJw7wXsFSFQrP8DJ6LGYnn8AtqgcKBGUIZUnWKNsIdw2FzLixre24/LAl4
# FOmRsqlb30mjdAy87JGA0j3mSj5mO0+7hvoyGtmW9I/2kQH2zsZ0/fZMcm8Qq3Uw
# xTSwethQ/gpY3UA8x1RtnWN0SCyxTkctwRQEcb9k+SS+c23Kjgm9swFXSVRk2XPX
# fx5bRAGOWhmRaw2fpCjcZxkoJLo4S5pu+yFUa2pFEUep8beuyOiJXk+d0tBMdrVX
# VAmxaQFEfnyhYWxz/gq77EFmPWn9y8FBSX5+k77L+DvktxW/tM4+pTFRhLy/AsGC
# onsXHRWJjXD+57XQKBqJC4822rpM+Zv/Cuk0+CQ1ZyvgDbjmjJnW4SLq8CdCPSWU
# 5nR0W2rRnj7tfqAxM328y+l7vzhwRNGQ8cirOoo6CGJ/2XBjU02N7oJtpQUQwXEG
# ahC0HVUzWLOhcGbyoYIDVTCCAj0CAQEwggEBoYHZpIHWMIHTMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQgSXJl
# bGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJzAlBgNVBAsTHm5TaGllbGQgVFNTIEVT
# Tjo0MDFBLTA1RTAtRDk0NzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# U2VydmljZaIjCgEBMAcGBSsOAwIaAxUAhGNHD/a7Q0bQLWVG9JuGxgLRXseggYMw
# gYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYD
# VQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQsF
# AAIFAOpofZMwIhgPMjAyNDA4MTUxMzEzNTVaGA8yMDI0MDgxNjEzMTM1NVowczA5
# BgorBgEEAYRZCgQBMSswKTAKAgUA6mh9kwIBADAGAgEAAgESMAcCAQACAhNGMAoC
# BQDqac8TAgEAMDYGCisGAQQBhFkKBAIxKDAmMAwGCisGAQQBhFkKAwKgCjAIAgEA
# AgMHoSChCjAIAgEAAgMBhqAwDQYJKoZIhvcNAQELBQADggEBAD2+p79amETNboED
# KUTtYtjdSaIkj3+o0Rw5fIpJ0VwzF5sC0venbrWyKiyOg/FgsVnlRXjfvhEM5cHx
# teIPvdj2tNDZR1NYTI+LONutIc6wgrBLDBVR4yWtcBiqZ0fDKsimxCQo2JoPyaVb
# do13t3ToapsVFiylkC3TFPl3q3lL6xklyVt+yYR0pmCGYJoSlPYd4SQbe6azXzrr
# qVytD5IYaRiOawLixM2ynU4WmzjWaCM1K/NBnTCz5Vw1h/oW+WtJUIyVvqhI2Xgg
# k2qRQXd54B06beY95bi5x1gT6rEkg5zTw4PvRoL2CAjmyX6b88aKCZM9RoPwidCE
# MPT+wSUxggQNMIIECQIBATCBkzB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2Fz
# aGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENv
# cnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAx
# MAITMwAAAf7QqMJ7NCELAQABAAAB/jANBglghkgBZQMEAgEFAKCCAUowGgYJKoZI
# hvcNAQkDMQ0GCyqGSIb3DQEJEAEEMC8GCSqGSIb3DQEJBDEiBCDUnVgSKfoYoKPe
# U7XHGXw7MZOsQ5IXFT+IDFYsehGTYDCB+gYLKoZIhvcNAQkQAi8xgeowgecwgeQw
# gb0EIBGFzN38U8ifGNH3abaE9apz68Y4bX78jRa2QKy3KHR5MIGYMIGApH4wfDEL
# MAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1v
# bmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWlj
# cm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAH+0KjCezQhCwEAAQAAAf4w
# IgQgdWdutn14GqFBlicSIey/BxgSdeY86XJi59+imducX70wDQYJKoZIhvcNAQEL
# BQAEggIAjWO0MHlN8KWvbp8lxIrmMaKQCOm1UVj6XVUoosYDxKTeczCdftimzSpN
# BIdm+6h9ZuSlf71JlfbT28SyUzQaqM7pucgUVMRUGiU1VCDWGgI0MMjRtOWRmTwf
# NsEfR4gLEcxJi9DbsknMIEq+I0wGNFdanGKAuJs0Y0cTEOck5JI1izoOkMdmPrcS
# cu8q4xi1eKAAz6lmC3qSr49kWtvGX4Y1BHFf76PBSL0iYTcEiTdjnvcaxrzCEZ9U
# i3fXjzto3OP+nMC+8pgFO2YwmDMOqWFcBdqZIN9s2UeIDFa0QVMXuGjSxyqvxjOh
# rcCoKB5msvmyXb5U9EAHQc4ae04pfhkaCzeVB9ntYSRRqQ3XqHl/4Mzb26usJGoU
# QkEOc+JRkG6QmaYZiIpLmonx332dlbGtuUakzVZtFqBwP27XqTvqKsZO2M46ziiu
# oNdCtD8YArMMO4C3kinpTcPb0jKSn6rfEjKNTS6hL+3wts+Gmgx+opRj3UsAvi81
# pUNfktF7qujvauLoHM77OWE/aj6EZUXo/wWRrRcAbbURDE6ALHRGZJi7BL3hIPwI
# twnPHrxGVijVCzIPBskqthht/w61YvYj59GyJC7cv+Fcg8rm3BlVXpaiIZjRPcPG
# TzRmM5vXhywIcMI16k2xhT45YxSDvRSLkvud7yIGOn+b5cpsnQ4=
# SIG # End Windows Authenticode signature block