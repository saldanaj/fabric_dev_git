# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# --------------------------------------------------------------------------


class EnrichmentUseCaseLoggingConstants:
    """
    This class contains logging constants for enrichment use cases.
    """

    AI_ENRICHMENT_RAW_ENRICHMENT_SAVE_ERROR="Error while saving raw enrichment"
    AI_ENRICHMENT_CONVERSATIONAL_DATA_USECASE_INFO="Processing conversational data use case: {use_case_name}"
    
    