from typing import Dict, List

from dmf.model.common.data_access_definition import DataAccessDefinition, DataSourceId
from dmf.model.source_configuration import MappingDefinition, SourceConfiguration, SourceTableSchema
from dmf.model.target_configuration.target_configuration import TargetConfiguration
from dmf.last_processed_line_computer.last_processed_lines import LastProcessedLineCalculator
from dmf.logging import Logger
from dmf.reference_values.reference_values_enricher import ReferenceValuesEnricher
from dmf.transformations.model.transformation_types import Source2TargetIdMapping
from dmf.transformations.processor.base_processor import BaseProcessor
from dmf.transformations.processor.column_expression_builder import ColumnExpressionBuilder
from dmf.transformations.processor.conditions.condition_source_columns_applier import ConditionedSourceColumnsApplier
from dmf.transformations.processor.conditions.id_mapping import ConditionedIdMappingAdjuster
from dmf.transformations.processor.field_values_source_enricher import FieldValuesSourceEnricher
from dmf.transformations.processor.target_processor import TargetProcessor
from dmf.transformations.reader.reader_factory import ReaderFactory
from dmf.transformations.utils.min_date_filter import MinDateFilter
from dmf.utils.dataframe_utils import DataFrameUtils
from dmf.utils.logging_utils import SyntheticId, Timed
from dmf.utils.spark_utils import SparkUtils
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.utils import AnalysisException

from dmf.transformations.reader.reader import Reader
from dmf.transformations.processor.column_selector import ColumnSelector
from dmf.model.internal.target_table_schema_helper import TargetTableSchemaHelper


@SyntheticId
class SourceProcessor(BaseProcessor):
    def __init__(
        self,
        spark: SparkSession,
        config: SourceConfiguration,
        reference_values_enricher: ReferenceValuesEnricher,
    ):
        self._spark: SparkSession = spark
        self.config: SourceConfiguration = config
        if self.config.table_schema is None:
            raise ValueError(f"got config without source schema {self.config}")
        self.df: DataFrame
        self._id_mapping_definitions: Dict[DataSourceId, DataAccessDefinition]
        self._reference_values_enricher = reference_values_enricher
        self._schema: SourceTableSchema = self.config.table_schema
        if self._schema is None:
            raise ValueError(f"got config without source schema {self.config}")
        self.is_empty: bool = False
        self.source_id = config.source_id

    def __str__(self):
        return f"source {self.source_id}"

    def __repr__(self) -> str:
        return f"SourceProcessor[{self.id}][{self.source_id:.30}]"

    @property
    def id_mapping_definitions(self):
        return self._id_mapping_definitions

    @id_mapping_definitions.setter
    def id_mapping_definitions(self, id_mapping_definitions: Dict[DataSourceId, DataAccessDefinition]):
        self._id_mapping_definitions = id_mapping_definitions

    def _preprocess(self) -> None:
        # calculate min date (unrelated to source data! merely the target data)
        min_date = LastProcessedLineCalculator(self._spark).compute_last_processed_line_in_source_table(
            executor=None, source_config=self.config
        )
        # filter source by date
        Logger.debug(f"{self} filtering by min_date: {min_date}")
        self.df = MinDateFilter.filter(
            df=self.df,
            min_date=min_date,
            date_col_name=self._schema.source_modified_date_column_name,
        )

        self.df = ColumnExpressionBuilder.build_column_expressions(self.df, self._schema.columns)
        self.df, extra_literal_columns = FieldValuesSourceEnricher.enrich(self.config, self.df)
        self.df = self._reference_values_enricher.enrich(self.df, self.config.source_to_reference_mappings)
        self.df, extra_conditioned_columns = ConditionedSourceColumnsApplier(
            self._spark,
            self.config,
            self.df,
            self._reference_values_enricher.reference_values_configuration.default_value,
        ).apply()
        try:
            self.df = ColumnSelector.select_specific_columns(
                self.df,
                list(self._schema.columns) + extra_literal_columns + extra_conditioned_columns,
            )
        except AnalysisException as ae:
            if "ambiguous" in str(ae):
                raise Exception(
                    "Multiple fields with same name were found. Use a unique aliases for these fields in the query to resolve the ambigiuity."
                ) from ae
            else:
                raise

    @Timed(Logger)
    def read(self) -> int:
        if not self._read_inner():
            self.is_empty = True
        else:
            self._preprocess()
            self._cache_if_needed()
        return self.is_empty

    def _cache_if_needed(self):
        self.is_empty = DataFrameUtils.is_empty(self.df)
        if not self.is_empty:
            self.df = self.df.cache()
        if self.is_empty:
            Logger.info(f"No rows to process in source table: {self}.")
        else:
            Logger.info(f"Starts processing source table: {self}.")

    def _read_inner(self) -> bool:
        Logger.info(f"{self} reading source table: '{self.config.data_access_definition}'")
        reader: Reader = ReaderFactory.get_instance(self.config.data_access_definition)
        total_cores = SparkUtils.get_runtime_total_spark_pool_size(self._spark)
        source_df = reader.read(self._spark)
        if total_cores and source_df:
            Logger.info(f"{self} repartition to {total_cores} cores")
            self.df = source_df.repartition(total_cores)
        else:
            self.df = source_df

        return reader.validate(df=self.df, data_access_definition=self.config.data_access_definition)

    def process(self) -> List[TargetProcessor]:
        if self.is_empty:
            return []

        if not self.id_mapping_definitions:
            Logger.info(f"{self} no id mapping definitions")

        target_processors = []
        for target_config in self.config.target_configurations:
            target_processor = self._create_target_processor(target_config)
            target_processors.append(target_processor)

        Logger.info(f"{self} process end. returning target processors: {[tp.id for tp in target_processors]}")
        return target_processors

    def _create_target_processor(self, target_config):
        target_id_mappings: List[Source2TargetIdMapping] = self._calc_id_mappings(target_config)
        target_id_mappings, source_ids_with_conditions = ConditionedIdMappingAdjuster.adjust(
            target_config, target_id_mappings
        )
        mapping_table_data_access_definitions: Dict[DataSourceId, DataAccessDefinition] = {}
        for target_id_mapping in target_id_mappings:
            mapping_table_data_access_definitions[
                target_id_mapping.id_mapping_df_name
            ] = self._find_mapping_table_data_access_definitions(target_id_mapping.id_mapping_df_name)

        target_processor = TargetProcessor(
            spark=self._spark,
            target_config=target_config,
            source_schema=self._schema,
            source_df=self.df,
            id_mappings=target_id_mappings,
            source_ids_with_conditions=source_ids_with_conditions,
            id_mapping_table_access_definitions=mapping_table_data_access_definitions,
            parent_id=self.source_id,
        )

        return target_processor

    def _find_mapping_table_data_access_definitions(self, id_mapping_df_name: str) -> DataAccessDefinition:
        for mapping_definition in self.id_mapping_definitions.values():
            if mapping_definition.data_source_id == id_mapping_df_name:
                return mapping_definition

        raise ValueError(f"Adapter mapping definition for table '{id_mapping_df_name}' was not defined")

    def _calc_id_mappings(self, target_config: TargetConfiguration) -> List[Source2TargetIdMapping]:
        src_to_target_id_mappings = []
        already_appended_target_id_column_names = []
        for mapping_definition in self.config.mapping_definitions:
            append = False
            if mapping_definition.target_mapping_table_name == target_config.target_id:
                append = True

            if not append:
                relations_to_mapping_table = TargetTableSchemaHelper.get_relations_pointing_to_table(
                    target_config.table_schema,
                    mapping_definition.target_mapping_table_name,
                )
                has_fk_to_mapping_definition = bool(relations_to_mapping_table)
                if has_fk_to_mapping_definition:
                    append = True

            if append and mapping_definition.target_id_column_name not in already_appended_target_id_column_names:
                src_to_target_id_mappings.append(
                    Source2TargetIdMapping(
                        id_mapping_df_name=self.id_mapping_definitions[
                            mapping_definition.target_mapping_table_name
                        ].data_source_id,
                        source_id_col_name=SourceProcessor._calc_source_id_column_name(mapping_definition),
                        target_id_col_name=mapping_definition.target_id_column_name,
                    )
                )
                already_appended_target_id_column_names.append(mapping_definition.target_id_column_name)
        return src_to_target_id_mappings

    @staticmethod
    def _calc_source_id_column_name(mapping_definition: MappingDefinition) -> str:
        return SourceProcessor.calc_source_id_column_name(mapping_definition.external_id_column_name,
                                                          mapping_definition.internal_id_column_name)

    @staticmethod
    def calc_source_id_column_name(external_id_column_name: str, internal_id_column_name: str) -> str:
        return external_id_column_name or internal_id_column_name

    def validate(self) -> bool:
        self.read()
        if self.is_empty:
            return True
        # TODO - implement validations
        return True

# SIG # Begin Windows Authenticode signature block
# MIIoLAYJKoZIhvcNAQcCoIIoHTCCKBkCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQse8BENmB6EqSR2hd
# JGAGggIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBcTYz7IJAdXgtg
# 2i17/AeRVyo1iHaT2+ZQ37KOqoW546CCDXYwggX0MIID3KADAgECAhMzAAADrzBA
# DkyjTQVBAAAAAAOvMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjMxMTE2MTkwOTAwWhcNMjQxMTE0MTkwOTAwWjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDOS8s1ra6f0YGtg0OhEaQa/t3Q+q1MEHhWJhqQVuO5amYXQpy8MDPNoJYk+FWA
# hePP5LxwcSge5aen+f5Q6WNPd6EDxGzotvVpNi5ve0H97S3F7C/axDfKxyNh21MG
# 0W8Sb0vxi/vorcLHOL9i+t2D6yvvDzLlEefUCbQV/zGCBjXGlYJcUj6RAzXyeNAN
# xSpKXAGd7Fh+ocGHPPphcD9LQTOJgG7Y7aYztHqBLJiQQ4eAgZNU4ac6+8LnEGAL
# go1ydC5BJEuJQjYKbNTy959HrKSu7LO3Ws0w8jw6pYdC1IMpdTkk2puTgY2PDNzB
# tLM4evG7FYer3WX+8t1UMYNTAgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQURxxxNPIEPGSO8kqz+bgCAQWGXsEw
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzUwMTgyNjAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAISxFt/zR2frTFPB45Yd
# mhZpB2nNJoOoi+qlgcTlnO4QwlYN1w/vYwbDy/oFJolD5r6FMJd0RGcgEM8q9TgQ
# 2OC7gQEmhweVJ7yuKJlQBH7P7Pg5RiqgV3cSonJ+OM4kFHbP3gPLiyzssSQdRuPY
# 1mIWoGg9i7Y4ZC8ST7WhpSyc0pns2XsUe1XsIjaUcGu7zd7gg97eCUiLRdVklPmp
# XobH9CEAWakRUGNICYN2AgjhRTC4j3KJfqMkU04R6Toyh4/Toswm1uoDcGr5laYn
# TfcX3u5WnJqJLhuPe8Uj9kGAOcyo0O1mNwDa+LhFEzB6CB32+wfJMumfr6degvLT
# e8x55urQLeTjimBQgS49BSUkhFN7ois3cZyNpnrMca5AZaC7pLI72vuqSsSlLalG
# OcZmPHZGYJqZ0BacN274OZ80Q8B11iNokns9Od348bMb5Z4fihxaBWebl8kWEi2O
# PvQImOAeq3nt7UWJBzJYLAGEpfasaA3ZQgIcEXdD+uwo6ymMzDY6UamFOfYqYWXk
# ntxDGu7ngD2ugKUuccYKJJRiiz+LAUcj90BVcSHRLQop9N8zoALr/1sJuwPrVAtx
# HNEgSW+AKBqIxYWM4Ev32l6agSUAezLMbq5f3d8x9qzT031jMDT+sUAoCw0M5wVt
# CUQcqINPuYjbS1WgJyZIiEkBMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGgwwghoIAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAAOvMEAOTKNNBUEAAAAAA68wDQYJYIZIAWUDBAIB
# BQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIBrt3fjSYl0MAa9YpJ2N4OKg
# VIkbAm3UTJqwsT/1R8aOMEIGCisGAQQBgjcCAQwxNDAyoBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEB
# BQAEggEASExGjlOQeU1RgEfyEXBgYZNy6hbYhuUfgiSvJQ23EHKbsSpDVfUpDAh+
# 04aOr0crv54VQoZqugv1rptlR9RQyAiVWLRU/m75MJS1A5wI4qckod5TL/KXIJRx
# uAyq2SDurCyVO173U4+w+WPzDSI1Clre70AzuCW79Xrff7wGtkSqUhJYa29MBico
# iHUJwr9nOfuqbAa3QTMcl/nfdl3mcie+hbNe5wOg8E2mfVLvz6eKGMoyHsQZEHRC
# IUm30ZRN2ulRrtFxAOwkw9/jMTEIXpiggaYLKzXTWtS5CoCCl20xLplw0a15NRoA
# y+R2O/ALnrt/2SUpx4Vie41UnTLoGKGCF5YwgheSBgorBgEEAYI3AwMBMYIXgjCC
# F34GCSqGSIb3DQEHAqCCF28wghdrAgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFSBgsq
# hkiG9w0BCRABBKCCAUEEggE9MIIBOQIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFl
# AwQCAQUABCBKR346u3PAD3RTCSI/bIJ8LzOj+97wCeq3pHnCI3jD7AIGZr3xE9wo
# GBMyMDI0MDgxNTEzMzYzNi45MzhaMASAAgH0oIHRpIHOMIHLMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1l
# cmljYSBPcGVyYXRpb25zMScwJQYDVQQLEx5uU2hpZWxkIFRTUyBFU046OTIwMC0w
# NUUwLUQ5NDcxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2Wg
# ghHsMIIHIDCCBQigAwIBAgITMwAAAecujy+TC08b6QABAAAB5zANBgkqhkiG9w0B
# AQsFADB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYD
# VQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDAeFw0yMzEyMDYxODQ1
# MTlaFw0yNTAzMDUxODQ1MTlaMIHLMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2Fz
# aGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENv
# cnBvcmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1lcmljYSBPcGVyYXRpb25z
# MScwJQYDVQQLEx5uU2hpZWxkIFRTUyBFU046OTIwMC0wNUUwLUQ5NDcxJTAjBgNV
# BAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2UwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQDCV58v4IuQ659XPM1DtaWMv9/HRUC5kdiEF89YBP6/
# Rn7kjqMkZ5ESemf5Eli4CLtQVSefRpF1j7S5LLKisMWOGRaLcaVbGTfcmI1vMRJ1
# tzMwCNIoCq/vy8WH8QdV1B/Ab5sK+Q9yIvzGw47TfXPE8RlrauwK/e+nWnwMt060
# akEZiJJz1Vh1LhSYKaiP9Z23EZmGETCWigkKbcuAnhvh3yrMa89uBfaeHQZEHGQq
# dskM48EBcWSWdpiSSBiAxyhHUkbknl9PPztB/SUxzRZjUzWHg9bf1mqZ0cIiAWC0
# EjK7ONhlQfKSRHVLKLNPpl3/+UL4Xjc0Yvdqc88gOLUr/84T9/xK5r82ulvRp2A8
# /ar9cG4W7650uKaAxRAmgL4hKgIX5/0aIAsbyqJOa6OIGSF9a+DfXl1LpQPNKR79
# 2scF7tjD5WqwIuifS9YUiHMvRLjjKk0SSCV/mpXC0BoPkk5asfxrrJbCsJePHSOE
# blpJzRmzaP6OMXwRcrb7TXFQOsTkKuqkWvvYIPvVzC68UM+MskLPld1eqdOOMK7S
# bbf2tGSZf3+iOwWQMcWXB9gw5gK3AIYK08WkJJuyzPqfitgubdRCmYr9CVsNOuW+
# wHDYGhciJDF2LkrjkFUjUcXSIJd9f2ssYitZ9CurGV74BQcfrxjvk1L8jvtN7mul
# IwIDAQABo4IBSTCCAUUwHQYDVR0OBBYEFM/+4JiAnzY4dpEf/Zlrh1K73o9YMB8G
# A1UdIwQYMBaAFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMF8GA1UdHwRYMFYwVKBSoFCG
# Tmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY3Jvc29mdCUy
# MFRpbWUtU3RhbXAlMjBQQ0ElMjAyMDEwKDEpLmNybDBsBggrBgEFBQcBAQRgMF4w
# XAYIKwYBBQUHMAKGUGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY2Vy
# dHMvTWljcm9zb2Z0JTIwVGltZS1TdGFtcCUyMFBDQSUyMDIwMTAoMSkuY3J0MAwG
# A1UdEwEB/wQCMAAwFgYDVR0lAQH/BAwwCgYIKwYBBQUHAwgwDgYDVR0PAQH/BAQD
# AgeAMA0GCSqGSIb3DQEBCwUAA4ICAQB0ofDbk+llWi1cC6nsfie5Jtp09o6b6ARC
# pvtDPq2KFP+hi+UNNP7LGciKuckqXCmBTFIhfBeGSxvk6ycokdQr3815pEOaYWTn
# HvQ0+8hKy86r1F4rfBu4oHB5cTy08T4ohrG/OYG/B/gNnz0Ol6v7u/qEjz48zXZ6
# ZlxKGyZwKmKZWaBd2DYEwzKpdLkBxs6A6enWZR0jY+q5FdbV45ghGTKgSr5ECAOn
# LD4njJwfjIq0mRZWwDZQoXtJSaVHSu2lHQL3YHEFikunbUTJfNfBDLL7Gv+sTmRi
# DZky5OAxoLG2gaTfuiFbfpmSfPcgl5COUzfMQnzpKfX6+FkI0QQNvuPpWsDU8sR+
# uni2VmDo7rmqJrom4ihgVNdLaMfNUqvBL5ZiSK1zmaELBJ9a+YOjE5pmSarW5sGb
# n7iVkF2W9JQIOH6tGWLFJS5Hs36zahkoHh8iD963LeGjZqkFusKaUW72yMj/yxTe
# GEDOoIr35kwXxr1Uu+zkur2y+FuNY0oZjppzp95AW1lehP0xaO+oBV1XfvaCur/B
# 5PVAp2xzrosMEUcAwpJpio+VYfIufGj7meXcGQYWA8Umr8K6Auo+Jlj8IeFS6lSv
# KhqQpmdBzAMGqPOQKt1Ow3ZXxehK7vAiim3ZiALlM0K546k0sZrxdZPgpmz7O8w9
# gHLuyZAQezCCB3EwggVZoAMCAQICEzMAAAAVxedrngKbSZkAAAAAABUwDQYJKoZI
# hvcNAQELBQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAw
# DgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24x
# MjAwBgNVBAMTKU1pY3Jvc29mdCBSb290IENlcnRpZmljYXRlIEF1dGhvcml0eSAy
# MDEwMB4XDTIxMDkzMDE4MjIyNVoXDTMwMDkzMDE4MzIyNVowfDELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRp
# bWUtU3RhbXAgUENBIDIwMTAwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoIC
# AQDk4aZM57RyIQt5osvXJHm9DtWC0/3unAcH0qlsTnXIyjVX9gF/bErg4r25Phdg
# M/9cT8dm95VTcVrifkpa/rg2Z4VGIwy1jRPPdzLAEBjoYH1qUoNEt6aORmsHFPPF
# dvWGUNzBRMhxXFExN6AKOG6N7dcP2CZTfDlhAnrEqv1yaa8dq6z2Nr41JmTamDu6
# GnszrYBbfowQHJ1S/rboYiXcag/PXfT+jlPP1uyFVk3v3byNpOORj7I5LFGc6XBp
# Dco2LXCOMcg1KL3jtIckw+DJj361VI/c+gVVmG1oO5pGve2krnopN6zL64NF50Zu
# yjLVwIYwXE8s4mKyzbnijYjklqwBSru+cakXW2dg3viSkR4dPf0gz3N9QZpGdc3E
# XzTdEonW/aUgfX782Z5F37ZyL9t9X4C626p+Nuw2TPYrbqgSUei/BQOj0XOmTTd0
# lBw0gg/wEPK3Rxjtp+iZfD9M269ewvPV2HM9Q07BMzlMjgK8QmguEOqEUUbi0b1q
# GFphAXPKZ6Je1yh2AuIzGHLXpyDwwvoSCtdjbwzJNmSLW6CmgyFdXzB0kZSU2LlQ
# +QuJYfM2BjUYhEfb3BvR/bLUHMVr9lxSUV0S2yW6r1AFemzFER1y7435UsSFF5PA
# PBXbGjfHCBUYP3irRbb1Hode2o+eFnJpxq57t7c+auIurQIDAQABo4IB3TCCAdkw
# EgYJKwYBBAGCNxUBBAUCAwEAATAjBgkrBgEEAYI3FQIEFgQUKqdS/mTEmr6CkTxG
# NSnPEP8vBO4wHQYDVR0OBBYEFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMFwGA1UdIARV
# MFMwUQYMKwYBBAGCN0yDfQEBMEEwPwYIKwYBBQUHAgEWM2h0dHA6Ly93d3cubWlj
# cm9zb2Z0LmNvbS9wa2lvcHMvRG9jcy9SZXBvc2l0b3J5Lmh0bTATBgNVHSUEDDAK
# BggrBgEFBQcDCDAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMC
# AYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBTV9lbLj+iiXGJo0T2UkFvX
# zpoYxDBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20v
# cGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcmwwWgYI
# KwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNydDANBgkqhkiG
# 9w0BAQsFAAOCAgEAnVV9/Cqt4SwfZwExJFvhnnJL/Klv6lwUtj5OR2R4sQaTlz0x
# M7U518JxNj/aZGx80HU5bbsPMeTCj/ts0aGUGCLu6WZnOlNN3Zi6th542DYunKmC
# VgADsAW+iehp4LoJ7nvfam++Kctu2D9IdQHZGN5tggz1bSNU5HhTdSRXud2f8449
# xvNo32X2pFaq95W2KFUn0CS9QKC/GbYSEhFdPSfgQJY4rPf5KYnDvBewVIVCs/wM
# nosZiefwC2qBwoEZQhlSdYo2wh3DYXMuLGt7bj8sCXgU6ZGyqVvfSaN0DLzskYDS
# PeZKPmY7T7uG+jIa2Zb0j/aRAfbOxnT99kxybxCrdTDFNLB62FD+CljdQDzHVG2d
# Y3RILLFORy3BFARxv2T5JL5zbcqOCb2zAVdJVGTZc9d/HltEAY5aGZFrDZ+kKNxn
# GSgkujhLmm77IVRrakURR6nxt67I6IleT53S0Ex2tVdUCbFpAUR+fKFhbHP+Crvs
# QWY9af3LwUFJfn6Tvsv4O+S3Fb+0zj6lMVGEvL8CwYKiexcdFYmNcP7ntdAoGokL
# jzbaukz5m/8K6TT4JDVnK+ANuOaMmdbhIurwJ0I9JZTmdHRbatGePu1+oDEzfbzL
# 6Xu/OHBE0ZDxyKs6ijoIYn/ZcGNTTY3ugm2lBRDBcQZqELQdVTNYs6FwZvKhggNP
# MIICNwIBATCB+aGB0aSBzjCByzELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjElMCMGA1UECxMcTWljcm9zb2Z0IEFtZXJpY2EgT3BlcmF0aW9uczEn
# MCUGA1UECxMeblNoaWVsZCBUU1MgRVNOOjkyMDAtMDVFMC1EOTQ3MSUwIwYDVQQD
# ExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloiMKAQEwBwYFKw4DAhoDFQCz
# cgTnGasSwe/dru+cPe1NF/vwQ6CBgzCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1w
# IFBDQSAyMDEwMA0GCSqGSIb3DQEBCwUAAgUA6mhvlDAiGA8yMDI0MDgxNTEyMTQx
# MloYDzIwMjQwODE2MTIxNDEyWjB2MDwGCisGAQQBhFkKBAExLjAsMAoCBQDqaG+U
# AgEAMAkCAQACAUMCAf8wBwIBAAICEqAwCgIFAOppwRQCAQAwNgYKKwYBBAGEWQoE
# AjEoMCYwDAYKKwYBBAGEWQoDAqAKMAgCAQACAwehIKEKMAgCAQACAwGGoDANBgkq
# hkiG9w0BAQsFAAOCAQEAVoId/SqYi2uI8FU2e2fCbtjs9CfTRUCfBNOfrA+pRnYF
# OkSKmkottGOmKIeuPqBmT0aair2QPP8g/cP6w9bTS+qikW+v282YDsaxLfrwwMyt
# CmsKzs0s5ijlxsvaDhnblnlgdlPgExXYqUAfv7ZHxwKsTxgUu2bbvw2PFM+XJRbF
# y9xDueV6WwWftLCiKLqXbdKlRQQCjZoL5Xs82NKk7O3E6Uec4dYoN1nX+IT2RGw1
# OCjsY1Pomz2fMQku0pPSgcw8bOaJEHeie3fdhFafnU8CnI4oJs4fTeQyVokisByB
# eN/BDjUh4S+N0JHhU2CSF0MO9VoK2xyiMtooU3teLjGCBA0wggQJAgEBMIGTMHwx
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1p
# Y3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAB5y6PL5MLTxvpAAEAAAHn
# MA0GCWCGSAFlAwQCAQUAoIIBSjAaBgkqhkiG9w0BCQMxDQYLKoZIhvcNAQkQAQQw
# LwYJKoZIhvcNAQkEMSIEIJTX4N3iqg2pOcoY6OwFMbEqudtIBuKnhn9ytZWWZHXU
# MIH6BgsqhkiG9w0BCRACLzGB6jCB5zCB5DCBvQQg5TZdDXZqhv0N4MVcz1QUd4Rf
# vgW/QAG9AwbuoLnWc60wgZgwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0Eg
# MjAxMAITMwAAAecujy+TC08b6QABAAAB5zAiBCBq67pL8DlDKAqnMPNJcASIuxv0
# 3F1BKDx66VPk0UxJ0jANBgkqhkiG9w0BAQsFAASCAgA2ELjYtvWbItDHUCh2Bno5
# Scr/Rsjr1wEvPVjON9BgvesLtt2NHcxPpRa8n5TKGhkcF0Ig8u5z3MsxWNBBi1V+
# bSS8kk4oY2VZR96rshO5evC4CmYiWLISq2cAGkXvilsPiMesP6us82KsyY0neNXE
# k6A/pPzBjE6iuUXeSWO8WWXyC2rWC8T0IbYSGGS6tJa8RFcnIb8OJh2KN6GG5iY+
# jgQ9qfmsD/DoeYJAah8RqaOGgrhZC53YfCTXSpVYbLT6ZJX8byLCBB9way+SZe9h
# yXJP1cGh3t6UUcBs4DaNugSiBCI8Xpw0onISIrOLZpF/HtGm2fsAAksDcsk/JNLI
# QPc+3cU0g1gsgaTR7r9lfBhrEFGIZr8Tnhq6yYYVZ7gKWJXANYy+iuHjUlg+IbG7
# v95GNVuRdWdaac2XDoybyKbwcFnNwphcdvuYacD8eNH4We60bRLgPL2sIOrjiRql
# cGkiQBtby63tw56Wp5ZvMixDvei4kK29I5xYKovAfFY+jFyotnyKU2o85FICwcXD
# TFbFuZtXzkSiXK8vomYMOifTDF44WPuOQLwQiLQuEER8xOdOVeaq19znsW4xYIXw
# yXVnAvYMkiC5qhoTAiinUe0D7NtsUAc1w57cJwFplz/ing9NsBX6rN7s/V7lQIBn
# kPCtpZGnIUF4EuDIV4bRXQ==
# SIG # End Windows Authenticode signature block