import json
import os
from datetime import datetime, timezone
import uuid
from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.functions import *
from pyspark.sql.types import (
    StructType, StructField, StringType, IntegerType,
    DoubleType, BooleanType, TimestampType, DecimalType,
    DateType, ArrayType
)
from microsoft.fabric.hls.hds.claims_data_ingestions.json.utils.constants import JSONClaimsIngestionConstants as C
from microsoft.fabric.hls.hds.global_constants.global_constants import GlobalConstants as GC
from microsoft.fabric.hls.hds.global_constants.logging_constants import LoggingConstants as LC
from microsoft.fabric.hls.hds.utils.mssparkutils_client_base import MSSparkUtilsClientBase
from microsoft.fabric.hls.hds.utils.fhir_converter_helper import FHIRConverter
from microsoft.fabric.hls.hds.utils.utils import FolderPath, Utils as CommonUtils
from microsoft.fabric.hls.hds.utils.business_events_ingestion_handler import BusinessEventsIngestion
from microsoft.fabric.hls.hds.structured_stream.delta_table_stream_reader import DeltaTableStreamReader
from microsoft.fabric.hls.hds.services.base_runnable_service import BaseRunnableService
from microsoft.fabric.hls.hds.data_models.execution_metadata import ExecutionMetadata, ExecutionDataType
from microsoft.fabric.hls.hds.claims_data_ingestions.json.utils.json_utils import JSONUtils

class TransformJSONToFHIRNDJSON(BaseRunnableService):
    
    def __init__(self,
                 spark: SparkSession,
                 workspace_name: str,
                 solution_name: str,
                 admin_lakehouse_name: str,
                 inline_params: dict = None,
                 one_lake_endpoint: str = GC.DEFAULT_ONE_LAKE_ENDPOINT,
                 mssparkutils_client: MSSparkUtilsClientBase = None) -> None:
        """
        Args:
            - spark: spark session
            - workspace_name (str): Name of the Fabric Workspace
            - solution_name (str): Name of the HDS-Healthcare data solutions OneLake workload solution
            - admin_lakehouse_name (str): The lakehouse name of where the administration configurations are located
            - inline_params (dict): Inline parameters that will overwrite and take precedence over the parameters in the administration lakehouse configuration
            - one_lake_endpoint (str): The one lake endpoint. Default is `onelake.dfs.fabric.microsoft.com`
            - mssparksutils_client (MSSparkUtilsClientBase): The mssparkutils client
        """     
        self.spark= spark
        self.workspace_name = workspace_name
        self.solution_name = solution_name
        self.one_lake_endpoint = one_lake_endpoint
        self.mssparkutils_client = CommonUtils.get_mssparkutils_client(mssparkutils_client)
        # JSON utilities for JSON extraction and conversion
        self.json_utils = JSONUtils(self.spark)

        super().__init__(
            spark=spark,
            workspace_name=workspace_name,
            solution_name=solution_name,
            admin_lakehouse_name=admin_lakehouse_name,
            inline_params=inline_params,
            one_lake_endpoint=one_lake_endpoint,
            mssparkutils_client=mssparkutils_client
        )
        
    def _setup(self) -> None:

        self.config_files_root_path = FolderPath.get_fabric_workload_files_root_path(
            workspace_name=self.workspace_name,
            one_lake_endpoint=self.one_lake_endpoint,
            solution_name=self.solution_name
        )
        
        self.target_lakehouse_name = self.source_lakehouse_name = self.parameter_service.get_foundation_config_value(GC.BRONZE_LAKEHOUSE_ID_KEY)
        self.config_root_file_path = FolderPath.get_fabric_workload_files_root_path(
            workspace_name=self.workspace_name,
            one_lake_endpoint=self.one_lake_endpoint,
            solution_name=self.solution_name
        )      
        try:
            self.max_records_per_ndjson = int(self.parameter_service.get_activity_config_value(GC.MAX_RECORDS_PER_NDJSON_KEY, C.MAX_RECORDS_PER_NDJSON))
        except Exception as ex:
            self._logger.error(message=str(ex))
            raise
            
        self.config_file_path = self.parameter_service.get_activity_config_value(
            GC.JSON_CONFIG_FILE_PATH_KEY,
            f"{self.config_files_root_path}/{GC.CLAIMS_JSON_FILES_CONFIG_PATH}/{C.JSON_TO_FHIR_MAPPING_FILE_NAME}"
        )
        
        # Load the default mapping config
        self._logger.info(f"Loading default FHIR mapping from: {self.config_file_path}")
        self.default_mapping_config = json.loads(
            self.spark.sparkContext.wholeTextFiles(
                self.config_file_path
            ).collect()[0][1]
        )
          # Load claim types configuration
        self.config_directory = os.path.dirname(self.config_file_path)
        claim_types_config_path = os.path.join(self.config_directory, C.CLAIM_FILEMAPPING_CONFIG_NAME)
        self.claim_types_config = self.json_utils.load_claim_file_mapping_config(claim_types_config_path)
        
        # For now, set the mapping config to the default
        self.mapping_config = self.default_mapping_config
        
        self.checkpoint_path = os.path.join(
            self.parameter_service.get_foundation_config_value(
            GC.CLAIMS_CHECKPOINT_PATH_KEY,
            FolderPath.get_fabric_workload_files_checkpoint_folder_path(
                root_path=self.config_files_root_path,
                checkpoint_folder_name=f"{GC.CLAIMS_INGESTION_FOLDER}"
            )
        ),C.JSON_TO_FHIR_CHECKPOINT_FOLDER)
        self.avro_schema_file_path = self.parameter_service.get_activity_config_value(
            GC.AVRO_SCHEMA_PATH_KEY,
            f'{FolderPath.get_fabric_workload_files_schema_root_folder_path(root_path=self.config_files_root_path)}/{GC.DEFAULT_SILVER_LAKEHOUSE_NAME}'
        )

        self.resource_avro_schema_path = f"{self.avro_schema_file_path}/{C.FHIR_CLAIMS_RES_NAME.lower()}{C.AVRO_SCHEMA_FILE_EXT}"

        self.spark_schema = CommonUtils.load_schema_from_avro_schema(
            self.spark, 
            CommonUtils.load_config_file(
                self.spark, 
                self.resource_avro_schema_path
            )
        )
        
        self.lakehouse_files_root_path = FolderPath.get_fabric_files_path(
            workspace_name=self.workspace_name,
            one_lake_endpoint=self.one_lake_endpoint,
            lakehouse_name=self.source_lakehouse_name
        )
        self.fhir_ndjson_files_root_path = self.parameter_service.get_activity_config_value(
            GC.FHIR_NDJSON_FILES_ROOT_PATH_KEY,
            f"{self.lakehouse_files_root_path}/{GC.PROCESS_FOLDER}/{GC.CLINICAL_FOLDER}"
        )
        self.fhir_convertor = FHIRConverter(
            C.FHIR_CLAIM_ELEMENT,
            self.mapping_config,
            self.spark_schema,
            C.CREATEDDATETIME_COLUMN_NAME
        )
        self._execution_metrics_collector=self.execution_metrics_collector

        self.fhir_namespace = self.parameter_service.get_activity_config_value(GC.FHIR_NAMESPACE_KEY, C.FHIR_NAMESPACE)
        self.business_events_ingestion_service = BusinessEventsIngestion(
                spark = self.spark,
                workspace_name = self.workspace_name,
                one_lake_endpoint = self.one_lake_endpoint,
                lakehouse_name = self.admin_lakehouse_name,
                solution_name = self.solution_name,
                parameter_service = self.parameter_service
                )
        
        self.delta_table_path = self.parameter_service.get_activity_config_value(
            GC.DELTA_TABLE_PATH_KEY,
            FolderPath.get_fabric_tables_path(
                workspace_name=self.workspace_name,
                one_lake_endpoint=self.one_lake_endpoint,
                lakehouse_name=self.source_lakehouse_name            )
        )
        
    def _get_internal_activity_name(self) -> str:
        return GC.JSON_FILES_FHIR_CONVERSION_ACTIVITY_NAME

    def _register_custom_accumulators(self) -> None:
        self.execution_metrics_collector.register_accumulator(
            accumulator_activity_id=self._get_validation_metrics_accumulator_activity_id(),
            initial_state=self._get_validation_metrics_initial_state()
        )
    
    def _setup_execution_metadata(self) -> ExecutionMetadata:
            return ExecutionMetadata(
                sourceType=ExecutionDataType.deltaTable,
                sourcePath=self.delta_table_path,
                targetType=ExecutionDataType.file,
                targetPath=self.fhir_ndjson_files_root_path,
                sourceLakehouseName=self.mssparkutils_client.get_lakehouse(self.source_lakehouse_name).get("displayName"),
                sourceLakehouseIdentifier=self.mssparkutils_client.get_lakehouse(self.source_lakehouse_name).get("id"),
                targetLakehouseName=self.mssparkutils_client.get_lakehouse(self.target_lakehouse_name).get("displayName"),
                targetLakehouseIdentifier=self.mssparkutils_client.get_lakehouse(self.target_lakehouse_name).get("id"),
            )

    def _execute(self, **kwargs) -> None:
        """
        Wrap for the service's core execution logic.
        """
        self.execute_ndjson_generation()

    def execute_ndjson_generation(self):
        """
        Executes the generation of NDJSON (Newline Delimited JSON) from the given Delta table.
        The generated NDJSON is saved to the specified checkpoint location.

        Raises:
            Exception: If an error occurs during the execution.
        """
        try:
            stream_reader = DeltaTableStreamReader(self.spark)
            df = stream_reader.set_up_streaming(
                f"{self.delta_table_path}/{C.JSON_DELTA_TABLE_NAME}"
            )
            query = (df.writeStream.format("delta")
                .trigger(availableNow=True)
                .option("checkpointLocation", self.checkpoint_path)
                .foreachBatch(self._generate_ndjson_and_save)
                .start())

            query.awaitTermination()
            
        except Exception as e:
            message = LC.JSON_SPARK_STREAM_GENERATE_ERR_MSG.format(error_msg=str(e))

            business_event_id = str(uuid.uuid4())
            new_row = self.business_events_ingestion_service.create_new_business_event_row(id=business_event_id, activityName=GC.CLAIMS_JSON_FHIR_CONVERSION_ACTIVITY_NOTEBOOK, 
                                                    targetFilePath= self.fhir_ndjson_files_root_path, 
                                                    targetLakehouseName= GC.DEFAULT_BRONZE_LAKEHOUSE_NAME,
                                                    sourceTableName= C.JSON_DELTA_TABLE_NAME, 
                                                    sourceLakehouseName= GC.DEFAULT_BRONZE_LAKEHOUSE_NAME, severity= GC.ERROR, 
                                                    eventType= GC.CMSCCLF_CLAIMS_FAILED_EXECUTE_NDJSON_GENERATION, message= message, 
                                                    active=True)          
            self.business_events_ingestion_service.insert_business_events([new_row])
            self._logger.error(message)
            raise    

    def _generate_ndjson_and_save(self, df: DataFrame, epoch_id: str):
        total_records = df.count()
        if(total_records>0):
            self._logger.info(
                LC.JSON_RECORDS_NUM_PROCESSED_INFO_MSG.format(  # Updated info message constant
                    records_num=total_records
                )) 
        else:
            # If no records are found, log the information and return
            self._logger.info(LC.JSON_NO_NEW_DATA_FOUND_INFO_MSG)
            return

        self._execution_metrics_accumulator_id=self.get_execution_metrics_accumulator_activity_id()
        if self._execution_metrics_collector:
            source_data_size_bytes = df._jdf.queryExecution().optimizedPlan().stats().sizeInBytes()

            self._execution_metrics_collector.accumulate(
                accumulator_activity_id=self._execution_metrics_accumulator_id,
                metrics={
                    "numSourceRecords": total_records,
                    "numSourceRecordsGranular": {C.JSON_DELTA_TABLE_NAME: total_records},
                    "sourceDataSizeBytes": source_data_size_bytes,
                }
            )
                               
        # Extract file types and group records by file type
        file_types = df.select(C.DATA_FORMAT_COLUMN_NAME).distinct().collect()
        
        for file_type_row in file_types:
            file_type = file_type_row[C.DATA_FORMAT_COLUMN_NAME]
            df_file_type = df.filter(f"{C.DATA_FORMAT_COLUMN_NAME} = '{file_type}'")
              # Load claim type specific FHIR mapping if available
            claim_type_config = self.json_utils.get_claim_type_config(file_type, self.claim_types_config)
            if claim_type_config and "mappingConfig" in claim_type_config:
                # Use claim type specific FHIR mapping
                mapping_config = self.json_utils.load_claim_type_mapping_config(self.config_directory, claim_type_config)
                self._logger.info(f"Using claim type specific FHIR mapping for file type: {file_type}")
            else:
                # Use default FHIR mapping
                message = LC.JSON_FHIR_MAPPING_NOT_FOUND_ERR_MSG.format(file_type=file_type)
                self._logger.error(message)
                business_event_id = str(uuid.uuid4())
                new_row = self.business_events_ingestion_service.create_new_business_event_row(id=business_event_id, activityName=GC.CLAIMS_JSON_FHIR_CONVERSION_ACTIVITY_NOTEBOOK, 
                    targetFilePath=self.fhir_ndjson_files_root_path,
                    targetLakehouseName=GC.DEFAULT_BRONZE_LAKEHOUSE_NAME, 
                    sourceTableName=C.JSON_DELTA_TABLE_NAME, 
                    sourceLakehouseName=GC.DEFAULT_BRONZE_LAKEHOUSE_NAME, 
                    severity=GC.ERROR, eventType=GC.CLAIMS_GENERATE_NDJSON_AND_SAVE_EVENT, 
                    message=message, active=True
                )
                self.business_events_ingestion_service.insert_business_events([new_row])
                return
                
            # Create a FHIR converter with the appropriate mapping config
            fhir_converter = FHIRConverter(
                C.FHIR_CLAIM_ELEMENT,
                mapping_config,
                self.spark_schema,
                C.CREATEDDATETIME_COLUMN_NAME
            )
              
            # Extract and process JSON for this file type
            try:
                df_extracted, resource_jsons = self.json_utils.extract_json(df_file_type)
                distinct_src_systems = df_extracted.select(C.SOURCE_SYSTEM_COLUMN_NAME).distinct()
                distinct_src_systems_list = distinct_src_systems.rdd.map(lambda row: row[0]).collect()
                for source_system in distinct_src_systems_list:
                    self.fhir_namespace = source_system

                    self.json_utils.convert_and_process_json(
                        df_extracted,
                        mapping_config,
                        self.spark_schema,
                        fhir_converter,
                        self.max_records_per_ndjson,
                        self.fhir_namespace,
                        self.fhir_ndjson_files_root_path,
                        self.mssparkutils_client,
                        df_groupby_and_agg_func=self._df_groupby_and_agg  
                    )
            except Exception as e:
                message = LC.JSON_PROCESSING_ERROR_MSG.format(file_type=file_type, error_msg=str(e))
                id = str(uuid.uuid4())
                new_row = self.business_events_ingestion_service.create_new_business_event_row(id=id, activityName=GC.CLAIMS_JSON_FHIR_CONVERSION_ACTIVITY_NOTEBOOK, 
                    targetFilePath=self.fhir_ndjson_files_root_path, sourceTableName=C.JSON_DELTA_TABLE_NAME,sourceFilePath=self.delta_table_path, 
                    sourceLakehouseName=GC.DEFAULT_BRONZE_LAKEHOUSE_NAME, severity=GC.ERROR, eventType=GC.CLAIMS_GENERATE_NDJSON_AND_SAVE_EVENT, 
                    message=message, active=True
                )
                self.business_events_ingestion_service.insert_business_events([new_row])
                self._logger.error(message)
            
            
    @staticmethod    
    def _modify_expr_str_level_based(key: str, level: int, expr_str: str) -> str:
        """
        This method is used to modify expr string based on the nesting level

        Args:
            key (str): element key 
            level (int): nesting level
            expr_str (str): expression string

        Returns:
            str: modified expression string
        """    
        if level == 1:
            return(f"collect_set({expr_str}.alias('json_object')).alias('{key}')")
        else:
            return(f"{expr_str}.alias('{key}')")
        
    def _generate_mappings_expr(self, mapping: dict, spark_schema: StructType, ignore_elements:list=[], level: int =1) -> list:
        """
        This method is used recursively to generate pyspark expressions for aggregations 
        based on mapping config passed

        Args:
            mapping (dict): mapping dictionary for which expressions need to be generated
            spark_schema (StructType): spark schema
            ignore_elements (list, optional): list of elements to be ignored while generating expressions. Defaults to [].
            level (int, optional): nesting level. Defaults to 1.

        Returns:
            list: list of pyspark expression strings
        """        
        mappings_expr = []
        
        for key, value in mapping.items(): 
            if key in ignore_elements:
                mappings_expr.append(f"collect_set(col('{key}')).alias('{key}')")
                continue
            
            schema_for_key = self.fhir_convertor.get_fhir_element_schema(spark_schema, key)
            
            if isinstance(value, dict):
                #if element value is of type dict then recursively call this method 
                # to generate expression for nested elements as well
                child_mappings_expr = FHIRConverter._generate_expr_str(
                    schema_for_key, 
                    value, 
                    self._generate_mappings_expr(value, schema_for_key, ignore_elements, level+1)
                )
                mappings_expr.append(self._modify_expr_str_level_based(key, level, child_mappings_expr))
            elif isinstance(value, list):
                #if element value is of type list then recursively call this method 
                # for each element in the list to generate expression for them as well
                child_mappings = []
                for valueItem in value:
                    child_mappings.append(
                        FHIRConverter._generate_expr_str(
                            schema_for_key, 
                            valueItem, 
                            self._generate_mappings_expr(valueItem, schema_for_key, ignore_elements, level+1)
                        ))
                
                child_mappings_expr = child_mappings[0]
                if key in GC.FHIR_EXTENDED_ELEMENTS or len(value)>1:
                    #This is a handling for special elements like 'identifier' 
                    # which will have multiple nested structures
                    child_mappings = [f"to_json({child_mapping})" for child_mapping in child_mappings]
                    child_mappings_expr = f"array({', '.join(child_mappings)})"
                    
                mappings_expr.append(self._modify_expr_str_level_based(key, level, child_mappings_expr))
            else:
                mappings_expr.append(self._modify_expr_str_level_based(key, level, f"{value}.cast({schema_for_key})"))
        return mappings_expr
         
    def _df_groupby_and_agg(self,
                            df: DataFrame, 
                            fhir_element_name: str, 
                            ignore_elements: list = []) -> DataFrame:
            
        """
        This method is used to do appropriate grouping and aggregation based on parameters passed

        Args:
            - df (Dataframe): the dataframe to be processed
            - fhir_element_name (str): the fhir element on which grouping and aggregation needs to be done
            - ignore_elements (list, optional): list of elements which needs to be ignored while processing. Defaults to [].
        Returns:
            DataFrame: dataframe after group by and aggregation
        """  
        mapping = self.fhir_convertor.get_config_mappings(self.mapping_config, fhir_element_name)
        spark_schema = self.fhir_convertor.get_fhir_element_schema(self.spark_schema, fhir_element_name)
        
        #generate mapping expression for all the elements as defined in the mapping config
        
        mappings_expr =  self._generate_mappings_expr(mapping, spark_schema, ignore_elements)
        df = df.withColumn(
            C.LOOP_EXPLODED_FIELD,
            explode(col(C.LOOP_PARENT_FIELD))
        )

        
        df_agg = df.groupBy(col(C.CLAIM_UNIQUE_IDENTIFIER)).agg(
             *[eval(mapping_expr) for mapping_expr in mappings_expr]
         )  

        for column, value in mapping.items():
            if not isinstance(value, list):
                #if its a 1:1 mapping as per mapping config, 
                #take just the first element from the aggregated list
                #(which ideally should not be the case), we take the first value
                df_agg = df_agg.withColumn(
                    column,
                    when(
                        col(column).isNotNull() & col(column).getItem(0).isNotNull(), 
                        col(column).getItem(0)
                    ).otherwise(None))
            else:
                if len(value) > 1:
                    #this is a handling for special cases like 'identifier' fhir element 
                    #where it can have an array of different fhir structures/elements
                    #here also we try to take the first value
                    df_agg = df_agg.withColumn(column, when(
                        col(column).isNotNull() & col(column).getItem(0).isNotNull(), 
                        col(column).getItem(0)))
                    
          #finally after all aggregations, we combine all the elements into a single struct 
        #named after the fhir element parameter passed  
        mapping = [f"'{key}'" for key in mapping.keys()]
        df_agg = df_agg.withColumn(fhir_element_name, eval(f"struct({', '.join(mapping)})"))
        df_agg = df_agg.select(fhir_element_name)
        return df_agg
